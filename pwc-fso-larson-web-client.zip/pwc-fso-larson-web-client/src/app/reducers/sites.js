import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.CACHE_SITES:
      updatedState[action.id] = action.value
      break
  }

  return updatedState
}
