import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)
  switch (action.type) {
    case A.RECEIVE_APPOINTMENT_INDEXES:
      updatedState = Object.assign({}, currentState, action.appointmentIndexes)
      break
    case A.SORT_APPOINTMENT_INDEXES:
      updatedState = Object.assign({}, action.appointmentIndexes)
      break
    case A.UPDATE_APPOINTMENT_INDEX:
      updatedState[action.appointmentIndexId] = Object.assign(
        updatedState[action.appointmentIndexId],
        action.appointmentIndex
      )
      break
    case A.INDEX_APPOINTMENT:
      updatedState = Object.assign({}, action.appointmentIndexes)
      break
    case A.CLEAR_APPINTMENT_INDEXES:
      updatedState = {}
      break
  }
  return updatedState
}
