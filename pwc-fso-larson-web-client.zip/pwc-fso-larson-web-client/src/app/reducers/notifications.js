import A from '../const/actionTypes'
import { omit } from 'lodash'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)
  switch (action.type) {
    case A.DISMISS_NOTIFICATION:
      updatedState = omit(updatedState, action.notificationId)
      break
    case A.RECEIVE_NOTIFICATIONS:
      let notifications = action.notifications

      let sortedNotificationIds = Object.keys(action.notifications).sort((a, b) => {
        return notifications[a].createdAt > notifications[b].createdAt ? -1 : 1
      })

      let sortedNotifications = {}
      sortedNotificationIds.map(notificationId => {
        sortedNotifications[notificationId] = notifications[notificationId]
      })

      updatedState = Object.assign(
        updatedState,
        sortedNotifications
      )
      break
  }

  return updatedState
}
