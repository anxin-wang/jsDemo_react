import A from '../const/actionTypes'
import _ from 'lodash'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.CACHE_ISSUES:
      updatedState[action.id] = action.value
      return updatedState
    case A.RECEIVE_ISSUES:
      const sortedKeys = _.reverse(Object.keys(action.issues))
      let issues = {}
      sortedKeys.map((sortedKey) => {
        issues[sortedKey] = action.issues[sortedKey]
      })
      return issues
    case A.TOGGLE_EQUIPMENT:
      let updatedEquipment = updatedState[action.issueId].equipment
      if (updatedEquipment[action.equipmentId]) {
        updatedEquipment = _.omit(updatedEquipment, action.equipmentId)
      } else {
        updatedEquipment[action.equipmentId] = true
      }
      updatedState[action.issueId].equipment = updatedEquipment
      return updatedState
    case A.TOGGLE_PART:
      let selectedParts = updatedState[action.issueId].selectedParts || {}
      selectedParts[action.partId] = selectedParts[action.partId] ? null : true
      updatedState[action.issueId] = Object.assign(
        {},
        updatedState[action.issueId],
        { selectedParts: selectedParts }
      )
      return updatedState
    case A.UPDATE_ISSUE:
      updatedState[action.issueId] = Object.assign(
        {},
        updatedState[action.issueId],
        action.issue
      )
      return updatedState
    default:
      return updatedState
  }
}
