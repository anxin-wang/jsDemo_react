import initialState from '../store/initialState'
// import A from '../const/actionTypes'

export default (currentState, action) => {
  return currentState || initialState
}
