import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  switch (action.type) {
    case A.ATTEMPTING_LOGIN:
      return {
        status: 'AWAITING_RESPONSE',
        username: 'guest',
        uid: null,
      }
    case A.LOGOUT:
      return {
        status: 'ANONYMOUS',
        username: 'guest',
        uid: null,
      }
    case A.LOGIN:
      return {
        status: 'LOGGED_IN',
        username: action.username,
        uid: action.uid,
      }
    default:
      return currentState || initialState.auth
  }
}
