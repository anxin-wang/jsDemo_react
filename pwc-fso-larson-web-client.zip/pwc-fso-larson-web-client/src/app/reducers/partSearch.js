import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  switch (action.type) {
    case A.SEARCH_FOR_PART:
      return Object.assign({}, currentState, { term: action.term })
    case A.RECEIVE_PART_RESULTS:
      return Object.assign({}, currentState, { results: action.results })
    default:
      return currentState || initialState.partSearch
  }
}
