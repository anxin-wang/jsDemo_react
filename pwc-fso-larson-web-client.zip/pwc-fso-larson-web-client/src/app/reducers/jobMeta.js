import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.UPDATE_CUSTOMERPONUMBER:
      updatedState.customerPONumber = action.customerPONumber
      return updatedState
    case A.UPDATE_QUOTEDAMOUNT:
      updatedState.quotedAmount = action.quotedAmount
      return updatedState
    case A.UPDATE_NOTTOEXCEEDAMOUNT:
      updatedState.notToExceedAmount = action.notToExceedAmount
      return updatedState
    case A.UPDATE_BILLTYPE:
      updatedState.billType = action.billType
      return updatedState
    case A.UPDATE_BILLTO:
      updatedState.billTo = action.billTo
      return updatedState
    default:
      return currentState || initialState.jobMeta
  }
}
