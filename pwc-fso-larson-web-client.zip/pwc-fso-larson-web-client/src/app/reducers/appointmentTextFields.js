import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  switch (action.type) {
    case A.UPDATE_APPOINTMENTDESCRIPTION_FIELD:
      return Object.assign({}, currentState, { appointmentDescriptionField: action.description })
    case A.UPDATE_APPOINTMENTPHONENUMBER_FIELD:
      return Object.assign({}, currentState, { appointmentPhoneNumberField: action.phoneNumber })
    case A.UPDATE_APPOINTMENTCALLERNAME_FIELD:
      return Object.assign({}, currentState, { appointmentCallerNameField: action.callerName })
    case A.UPDATE_APPOINTMENTISSUEDESCRIPTION_FIELD:
      return Object.assign({}, currentState, { appointmentIssueDescriptionField: action.issueDescription })
    case A.UPDATE_APPOINTMENTADDITIONALNOTES_FIELD:
      return Object.assign({}, currentState, { appointmentAdditionalNotesField: action.additionalNotes })
    case A.INIT_ALL_APPOINTMENT_TEXT_FIELDS:
      let initAppointmentTextFields = {
        appointmentDescriptionField: '',
        appointmentPhoneNumberField: '',
        appointmentCallerNameField: '',
        appointmentIssueDescriptionField: ''
      }
      return Object.assign({}, initAppointmentTextFields)
    default:
      return currentState || initialState.appointmentTextFields
  }
}

