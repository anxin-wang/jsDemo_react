import A from '../const/actionTypes'
import appointmentStatus from '../const/appointmentStatus'
import store from '../store'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)
  switch (action.type) {
    case A.SHOW_SNACKBAR:
      updatedState = action.snackbar
      break
    case A.HIDE_SNACKBAR:
      updatedState = {
        open: false,
      }
      break
    case A.UPDATE_APPOINTMENT:
      const updatedStatus = action.updatedAppointment ? action.updatedAppointment.status : null
      if (updatedStatus === appointmentStatus.ASSIGNED) {
        const appointment = store.getState().appointments[action.appointmentId]
        const legacyId = appointment && appointment.legacyId ? appointment.legacyId : ''
        updatedState = {
          message: 'Appointment ' + legacyId + ' has been assigned.',
          open: true,
          autoHideDuration: 4000,
        }
      }
      break
  }
  return updatedState
}
