import { combineReducers, } from 'redux'
import appBarReducer from './appBar'
import appointmentsReducer from './appointments'
import appointmentsMetaReducer from './appointmentsMeta'
import appointmentIndexesReducer from './appointmentIndexes'
import appointmentTextFieldsReducer from './appointmentTextFields'
import authReducer from './auth'
import cacheIndexReducer from './cacheIndex'
import clientReducer from './client'
import clientsReducer from './clients'
import dialogReducer from './dialog'
import dispatchersReducer from './dispatchers'
import equipmentReducer from './equipment'
import equipmentSearchReducer from './equipmentSearch'
import engineersReducer from './engineers'
import engineerMetaReducer from './engineerMeta'
import issuesReducer from './issues'
import jobsReducer from './jobs'
import mapReducer from './map'
import newIssueReducer from './newIssue'
import notesReducer from './notes'
import notificationsReducer from './notifications'
import officesReducer from './offices'
import partsReducer from './parts'
import partSearchReducer from './partSearch'
import routeParamsReducer from './routeParams'
import searchReducer from './search'
import siteHistoriesReducer from './siteHistories'
import snackbarReducer from './snackbar'
import jobMetaReducer from './jobMeta'
import sitesReducer from './sites'
import { routerReducer, } from 'react-router-redux'

const rootReducer = combineReducers({
  appBar: appBarReducer,
  appointments: appointmentsReducer,
  appointmentsMeta: appointmentsMetaReducer,
  appointmentIndexes: appointmentIndexesReducer,
  auth: authReducer,
  client: clientReducer,
  clients: clientsReducer,
  cacheIndex: cacheIndexReducer,
  dialog: dialogReducer,
  dispatchers: dispatchersReducer,
  equipment: equipmentReducer,
  equipmentSearch: equipmentSearchReducer,
  engineers: engineersReducer,
  engineerMeta: engineerMetaReducer,
  issues: issuesReducer,
  jobs: jobsReducer,
  map: mapReducer,
  newIssue: newIssueReducer,
  notes: notesReducer,
  notifications: notificationsReducer,
  offices: officesReducer,
  parts: partsReducer,
  partSearch: partSearchReducer,
  routing: routerReducer,
  routeParams: routeParamsReducer,
  search: searchReducer,
  siteHistories: siteHistoriesReducer,
  sites: sitesReducer,
  snackbar: snackbarReducer,
  jobMeta: jobMetaReducer,
  appointmentTextFields: appointmentTextFieldsReducer
})

export default rootReducer
