import A from '../const/actionTypes'

export default (currentState, action) => {
  switch (action.type) {
    case A.SELECT_NEW_ISSUE:
      return action.issueId
    case A.INIT_NEW_ISSUE:
      return null
    default:
      return currentState || null
  }
}
