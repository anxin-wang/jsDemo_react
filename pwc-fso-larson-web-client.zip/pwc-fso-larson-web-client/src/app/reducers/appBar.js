import initialState from '../store/initialState'
import A from '../const/actionTypes'
import routeTitles from '../const/routeTitles'

export default (currentState, action) => {
  switch (action.type) {
    case A.LOCATION_CHANGE:
      const pathname = action.payload.pathname
      return {
        title: routeTitles[pathname] || routeTitles['/' + pathname.split('/')[1]],
      }
    default:
      return currentState || initialState.appBar
  }
}
