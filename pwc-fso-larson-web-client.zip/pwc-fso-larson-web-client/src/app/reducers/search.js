import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  switch (action.type) {
    case A.SEARCH_FOR_TERM:
      return Object.assign({}, currentState, {
        term: action.term,
        searching: true,
      })
    case A.RECEIVE_SEARCH_RESULTS:
      return Object.assign({}, currentState, {
        results: action.results,
        searching: null,
      })
    case A.CLEAR_SEARCH:
      return {
        searching: false,
      }
    default:
      return currentState || initialState.search
  }
}
