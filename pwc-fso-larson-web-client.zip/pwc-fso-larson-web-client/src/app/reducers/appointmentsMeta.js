import appointmentStatus from '../const/appointmentStatus'
import A from '../const/actionTypes'
import _ from 'lodash'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.CLEAR_RECENTLY_CREATED:
      updatedState = _.omit(updatedState, 'recentlyCreated')
      break
    case A.CACHE_APPOINTMENTS:
      const status = action.value.status
      if (status === appointmentStatus.ASSIGNED) {
        const timePassed = Date.now() - action.value.assignedAt
        const threshold = 1000 * 10 // 10 seconds
        if (timePassed < threshold) {
          updatedState.recentlyAssigned = action.id
        }
      }
      if (status === appointmentStatus.UNASSIGNED) {
        const timePassed = Date.now() - action.value.createdAt
        const threshold = 1000 * 10 // 10 seconds
        if (timePassed < threshold) {
          updatedState.recentlyCreated = action.id
        }
      }
      break
    case A.REGISTER_MAPS_API:
      updatedState.maps = action.maps
      break
    case A.SET_SORT_ADDRESS:
      updatedState.sortAddress = action.address
      break
    case A.SET_SORT_METHOD:
      updatedState.sortMethod = action.sortMethod
      break
    case A.SET_SORT_FIELD:
      updatedState.orderField = action.orderField
      break
    case A.UPDATE_APPOINTMENT_DETAIL:
      updatedState.toggleAppointmentDetail = !updatedState.toggleAppointmentDetail
      break
    case A.UPDATE_APPOINTMENT_META:
      updatedState = Object.assign(updatedState, action.newMeta)
      break
  }
  return updatedState
}
