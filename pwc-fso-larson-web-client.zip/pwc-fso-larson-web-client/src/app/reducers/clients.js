import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)
  switch (action.type) {
    case A.RECEIVE_CLIENTS:
      updatedState = Object.assign(
        updatedState,
        action.clients
      )
      break
    case A.CACHE_CLIENTS:
      updatedState[action.id] = action.value
      break
  }
  return updatedState
}
