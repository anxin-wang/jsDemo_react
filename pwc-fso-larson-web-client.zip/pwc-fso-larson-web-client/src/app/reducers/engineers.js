import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.CACHE_ENGINEERS:
      updatedState[action.id] = action.value
      break
    case A.RECEIVE_ENGINEERS:
      updatedState = Object.assign(
        updatedState,
        action.engineers
      )
      break
    case A.UPDATE_ENGINEER:
      updatedState[action.engineerId] = Object.assign(
        {},
        updatedState[action.engineerId],
        action.engineer
      )
      break
    default:
      updatedState = updatedState || initialState.engineers
  }
  return updatedState
}
