import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.UPDATE_MAP:
      updatedState = action.map
      return updatedState
    default:
      return currentState || initialState.map
  }
}
