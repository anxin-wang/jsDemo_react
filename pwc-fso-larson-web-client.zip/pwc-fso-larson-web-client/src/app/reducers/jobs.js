import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.CREATE_JOB:
      updatedState[action.jobId] = action.job
      return updatedState
    case A.CACHE_JOBS:
      updatedState[action.id] = action.value
      return updatedState
    case A.UPDATE_JOB:
      updatedState[action.jobId] = Object.assign(
        {},
        updatedState[action.jobId],
        action.job
      )
      return updatedState
    default:
      return currentState || initialState.jobs
  }
}
