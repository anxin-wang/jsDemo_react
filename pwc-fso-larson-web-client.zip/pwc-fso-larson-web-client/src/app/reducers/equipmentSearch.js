import initialState from '../store/initialState'
import A from '../const/actionTypes'

export default (currentState, action) => {
  switch (action.type) {
    case A.SEARCH_FOR_EQUIPMENT:
      return Object.assign({}, currentState, {
        term: action.term,
        issueId: action.issueId,
      })
    case A.RECEIVE_EQUIPMENT_RESULTS:
      return Object.assign({}, currentState, {
        results: action.results,
        issueId: action.issueId,
      })
    default:
      return currentState || initialState.equipmentSearch
  }
}
