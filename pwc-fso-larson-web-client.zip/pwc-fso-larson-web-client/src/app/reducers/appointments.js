import A from '../const/actionTypes'
import _ from 'lodash'

const sortAndLimitRecommendedEngineers = (appointment) => {
  if (appointment && appointment.recommendedEngineers) {
    const recommendedEngineers = appointment.recommendedEngineers
    let sortedEngineerEmails = Object.keys(recommendedEngineers).slice(0)
    sortedEngineerEmails.sort((engineerEmailA, engineerEmailB) => (
      recommendedEngineers[engineerEmailA].score > recommendedEngineers[engineerEmailB].score ? -1 : 1
    ))
    sortedEngineerEmails = sortedEngineerEmails.slice(0, 5)
    let sortedEngineers = {}
    sortedEngineerEmails.map((sortedEngineerEmail) => {
      sortedEngineers[sortedEngineerEmail] = recommendedEngineers[sortedEngineerEmail]
    })
    appointment.recommendedEngineers = sortedEngineers
  }
}

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.CACHE_APPOINTMENTS:
      let appointment = action.value
      sortAndLimitRecommendedEngineers(appointment)
      updatedState[action.id] = appointment
      break
    case A.UNCACHE_APPOINTMENT:
      updatedState = _.omit(updatedState, action.appointmentId)
      break
    case A.UPDATE_APPOINTMENT:
      updatedState[action.appointmentId] = Object.assign(
        {},
        updatedState[action.appointmentId],
        action.appointment
      )
      break
  }

  return updatedState
}
