import A from '../const/actionTypes'

export default (currentState, action) => {
  let updatedState = Object.assign({}, currentState)

  switch (action.type) {
    case A.RECEIVE_OFFICES:
      updatedState = Object.assign(
        updatedState,
        action.offices
      )
  }

  return updatedState
}
