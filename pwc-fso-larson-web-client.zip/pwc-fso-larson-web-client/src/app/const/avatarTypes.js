export default {
  'Jerry': '/images/jerry.png',
  'Jud': '/images/jud.png',
  'Jimmy': '/images/jimmy.png',
  'Joanna': '/images/joanna.png',
  'Janet': '/images/janet.png',
}
