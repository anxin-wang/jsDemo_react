export default {
  appointments: {
    engineers: 'assignedEngineer',
    issues: 'issues',
    jobs: 'jobId',
    sites: 'jobId',
  },
  engineers: {
    appointments: 'assignedAppointments',
  },
  issues: {
    equipment: {
      equipment: true,
      namespace: 'global/',
    },
    notes: {
      partNotes: {
        depth: 2,
      },
    },
    parts: {
      namespace: 'global/',
      recommendedParts: true,
      selectedParts: true,
    },
  },
  jobs: {
    sites: 'siteId',
  },
  sites: {
    clients: 'clientId',
    equipment: 'equipment',
    jobs: 'jobs',
  }
}
