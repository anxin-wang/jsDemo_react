export default {
  '/': 'Sign In',
  '/logout': 'Sign Out',
  '/enterAppointment': 'Support notes',
  '/reviewAppointment': 'Review notes',
  '/viewAppointments': 'Appointments',
  '/site': 'Site',
  '/viewMap': 'Map',
  '/viewTechs': 'Technicians',
  '/viewSites': 'Sites',
  '/search': ' '
}
