export default {
  CLARKSTON: 'Clarkston',
  COLUMBUS: 'Columbus',
  CINCINNATI: 'Cincinnati',
  'FT WAYNE': 'Ft Wayne',
  GAYLORD: 'Gaylord',
  GRAPIDS: 'Grand Rapids',
  COMPLETED: 'COMPLETED',
  INDIANAP: 'Indianapolis',
  SSMARIE: 'Sault Ste. Marie',
  TOLEDO: 'Toledo',
  Unknown: 'Unknown',
}
