import React from 'react'
import HardwareTv from 'material-ui/svg-icons/hardware/tv'
import MapsLocalGasStation from 'material-ui/svg-icons/maps/local-gas-station'
import MapsLocalPrintshop from 'material-ui/svg-icons/maps/local-printshop'
import { palette } from '../theme/Theme.js'

const styles = {
  avatar: {
    color: palette.textColorLight,
    height: 50,
    width: 50,
  },
}

const issueDetails = {
  'VER': {
    avatar: <HardwareTv style={styles.avatar}/>,
    name: 'POS Issue',
  },
  'PD': {
    avatar: <MapsLocalGasStation style={styles.avatar}/>,
    name: 'Pump Issue',
  },
  'PR': {
    avatar: <MapsLocalPrintshop style={styles.avatar}/>,
    name: 'Printer Issue',
  },
}

export default issueDetails
