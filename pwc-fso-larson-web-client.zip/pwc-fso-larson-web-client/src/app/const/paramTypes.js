export default {
  'a': 'appointmentId',
  'e': 'engineerId',
  'j': 'jobId',
  's': 'siteId',
  'r': 'refresh',
}
