export default [
  {
    text: 'TM – Time & Material',
    value: 'TM',
  },
  {
    text: 'COD – Cash on Delivery',
    value: 'COD',
  },
  {
    text: 'MC – Fixed cost contract',
    value: 'MC',
  },
  {
    text: 'CJ – Cost to job',
    value: 'CJ',
  },
]
