export default {
  'officeId1': {
    text: 'Clarkston',
    value: 'Clarkston',
  },
  'officeId2': {
    text: 'Indianapolis',
    value: 'Indianapolis',
  },
  'officeId3': {
    text: 'Gaylord',
    value: 'Gaylord',
  },
  'officeId4': {
    text: 'Cincinnati',
    value: 'Cincinnati',
  },
}
