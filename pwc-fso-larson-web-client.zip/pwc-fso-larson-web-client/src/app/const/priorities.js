export default {
  0: {
    formatted: 'P0',
    text: '0 – Emergency',
  },
  1: {
    formatted: 'P1',
    text: '1 – Service Call',
  },
  2: {
    formatted: 'P2',
    text: '2 – Install',
  },
}
