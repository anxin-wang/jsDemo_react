export default {
  OPEN: 'OPEN',
  CLOSED: 'CLOSED',
  COMPLETE: 'COMPLETE',
}
