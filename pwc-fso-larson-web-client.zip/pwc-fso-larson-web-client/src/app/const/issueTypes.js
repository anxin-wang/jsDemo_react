export default {
  VER: 'VER',
  PD: 'PD',
  PR: 'PR',
  OT: 'OT',
}
