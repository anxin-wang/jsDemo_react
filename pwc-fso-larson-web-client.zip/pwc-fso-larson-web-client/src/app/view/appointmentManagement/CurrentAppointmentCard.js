import React, { Component, } from 'react'
import { Card, CardHeader } from 'material-ui'

class CurrentAppointmentCard extends Component {
  constructor(props) {
    super(props)
  }

  render() {
    let { appointment, appointmentId, site } = this.props
    let { priority, legacyId } = appointment
    let address = site ? site.address : { street: 'Pending', city: 'Pending' }

    return (
      <Card key={appointmentId}>
        <CardHeader
          title={legacyId || 'Pending'}
          subtitle={
            <div>
              <div>{'P' + priority || 'Pending'}</div>
              <div>{address.street + ', ' + address.city}</div>
            </div>
          }
        />
      </Card>
    )
  }
}

export default CurrentAppointmentCard
