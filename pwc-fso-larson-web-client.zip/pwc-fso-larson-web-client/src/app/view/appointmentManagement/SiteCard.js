import React, { Component, } from 'react'
import { Card, CardHeader, } from 'material-ui/Card'
import MapsStoreMallDirectory from 'material-ui/svg-icons/maps/store-mall-directory'

class SiteCard extends Component {
  shouldComponentUpdate(nextProps, nextState) {
    const response = (
      JSON.stringify(this.props.site) !== JSON.stringify(nextProps.site)
    )
    return response
  }

  render() {
    const site = this.props.site
    return (
      <Card
        style={styles.siteCard}
        onClick={() => { this.props.selectSite(this.props.siteID) }}
      >
        <CardHeader
          style={styles.cardText}
          avatar={
            <MapsStoreMallDirectory />
          }
          title={
            <div style={styles.cardHeaderChildren}>
              <div>
                <span>{ site.name }</span>
                <br />
                <span>{ site.address.street + ', ' + site.address.city }</span>
              </div>
            </div>
          }
          style={styles.cardHeader}
          actAsExpander
        />
      </Card>
    )
  }
}

const styles = {
  cardHeaderChildren: {
    fontWeight: 'normal',
  },
  siteCard: {
    display: 'inline-block',
    margin: '0 0 1em',
    width: '100%',
    position: 'relative',
  },
  siteInfo: {
  },
}

export default SiteCard
