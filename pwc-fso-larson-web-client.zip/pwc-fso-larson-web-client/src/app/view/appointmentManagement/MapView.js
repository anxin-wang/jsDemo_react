import React, { Component, PropTypes, } from 'react'
import { connect, } from 'react-redux'
import store from '../../store'
import { Drawer, AppBar, Card, CardHeader, List, ListItem, SelectField, MenuItem, TextField } from 'material-ui'
import FieldEngineerMap from './FieldEngineerMap'
import actions from '../../actions'
import NavigationArrowBack from 'material-ui/svg-icons/navigation/arrow-back'
import GoogleMapConfiguration from '../../configuration/GoogleMap'
import { Avatar } from 'material-ui'
import avatarTypes from '../../const/avatarTypes'
import { palette } from '../../theme/Theme.js'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'
import _ from 'lodash'
import officeLabels from '../../const/engineerOffices'

class MapView extends Component {
  constructor(props) {
    super(props)
    this.selectEngineer = this.selectEngineer.bind(this)
    this.handleChangeSearch = this.handleChangeSearch.bind(this)
    this.handleChangeOffice = this.handleChangeOffice.bind(this)
  }

  componentWillUpdate() {
    const appointment = this.props.appointments[this.getAppointmentId()]
    if (!appointment) {
      firebaseCacheService.prioritize(
        'appointments',
        this.getAppointmentId()
      )
    }
  }

  static contextTypes = {
    router: PropTypes.object.isRequired,
  }

  selectEngineer(engineerId) {
    store.dispatch(actions.routeTo(
      'assignTechView',
      {
        appointmentId: this.getAppointmentId(),
        engineerId,
      }
    ))
  }

  handleChangeSearch(event, value) {
    this.props.updateEngineerMeta({
      nameSearch: value,
    })
  }

  handleChangeOffice(event, index, value) {
    this.props.updateEngineerMeta({
      office: value,
    })
  }

  componentWillMount() {
    Object.keys(this.props.engineers).map(engineerId => {
      this.props.cacheEngineer(engineerId)
    })
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  render() {
    const appointmentId = this.getAppointmentId()
    const { jobs, sites, appointments, engineers, branches, branchKey, searchText } = this.props
    const { jobId, } = appointments[appointmentId] ? appointments[appointmentId] : {}
    const job = jobs[jobId]
    const site = job ? sites[job.siteId] : null
    const address = site ? site.address : {}
    const filteredEngineers = _((branches[branchKey] || {}).engineers).omitBy(function (o) {

      if (!Object.keys(o).length) {
        return {}
      }
      return !(o.firstName.toLowerCase().includes(searchText.toLowerCase()) ||
        o.lastName.toLowerCase().includes(searchText.toLowerCase()))
    }).value()

    return (
      <div>
        <Drawer
          width={350}
          openPrimary
          open
        >
          <AppBar
            title="Assign Tech"
            iconElementLeft={
              <NavigationArrowBack
                style={styles.iconAlert}
                onClick={this.context.router.goBack}
              />
            }
          />
          <Card style={styles.siteInfo}>
            <CardHeader
              title={
                <div style={styles.siteName}>{site ? site.name : ''}</div>
              }
              subtitle={
                <div style={styles.siteAddress}>
                  {address.street}
                  <br />
                  {site ? address.city + ', ' + address.state + ' ' + address.zip : ''}
                </div>
              }
              style={styles.siteInfo}
            />
          </Card>
          {
            branches && <div>
                <div style={styles.filterWrapper}>
                  <SelectField
                    floatingLabelText="Office"
                    value={branchKey}
                    onChange={this.handleChangeOffice}
                    style={styles.filter}
                  >
                    {
                      Object.keys(branches).map(branchId => {
                        const {
                          name
                        } = branches[branchId]
                        const truncatedName = name.split('-')[0]
                        return (
                          <MenuItem value={branchId} primaryText={officeLabels[truncatedName]} key={truncatedName}/>
                        )
                      })
                    }
                  </SelectField>
                  <TextField
                    floatingLabelText="Name"
                    hintText="Search"
                    value={searchText}
                    onChange={this.handleChangeSearch}
                  />
                </div>
              </div>
          }
          <List>
          {
            branches && branches[branchKey] && Object.keys(filteredEngineers).map(engineerId => {
              let {
                firstName, lastName, legacyId, assignedAppointments
              } = engineers[engineerId] || {}

              return (
                <ListItem
                  key={engineerId}
                  style={styles.techCard}
                  onClick={ () => this.selectEngineer(engineerId)}
                >
                  <CardHeader
                    avatar={<Avatar src={avatarTypes[firstName]} />}
                    title={
                      <div>
                        <div style={styles.techName}>
                          {firstName + ' ' + lastName}
                        </div>
                        <div style={styles.techId}>{legacyId}</div>
                      </div>
                    }
                    subtitle={
                      <div>
                        <div style={styles.schedule}>
                          {
                            ((assignedAppointments &&
                            Object.keys(assignedAppointments).length) || 'No') +
                            ((assignedAppointments && Object.keys(assignedAppointments).length === 1 &&
                            ' appointment assigned') || ' appointments assigned')
                          }
                        </div>
                      </div>
                    }
                    style={styles.cardheader}
                  />
                </ListItem>
              )
            })
          }
          </List>
        </Drawer>
        {
          site ? (
            <FieldEngineerMap
              fieldEngineers={filteredEngineers}
              siteAddress={address}
              options={mapOptions}
              zoom={googleMapInitialValue.zoom}
              center={googleMapInitialValue.center}
              bootstrapURLKeys={GoogleMapConfiguration.bootstrapURLKeys}
              coordinates={{}}
              map={this.props.map}
              selectEngineer={this.selectEngineer.bind(this)}
              centerMap = {this.props.centerMap}
            />
          ) : null
        }
      </div>
    )
  }
}

const styles = {
  map: {
    width: '94%',
    height: '100%',
    position: 'fixed',
  },
  iconAlert: {
    marginTop: 12,
    color: palette.textColorLight,
    cursor: 'pointer',
  },
  siteInfo: {
    backgroundColor: palette.primary1Color,
    paddingLeft: 0
  },
  techCard: {
    borderBottom: '0.5px solid ' + palette.borderColor,
  },
  siteName: {
    fontSize: 20,
    marginBottom: 20,
    color: palette.alternateTextColor,
    marginLeft: 15,
  },
  siteAddress: {
    fontSize: 16,
    color: palette.alternateTextColor,
    marginLeft: 15,
  },
  recommended: {
    margin: 15,
    fontSize: 14,
  },
  cardheader: {
    padding: 0,
  },
  techName: {
    float: 'left',
    color: palette.textColor,
    position: 'relative',
    paddingRight: 16
  },
  techId: {
    color: palette.accent3Color,
    fontSize: 14,
    position: 'relative',
    paddingLeft: 16,
    float: 'right'
  },
  specialty: {
    color: palette.primary3Color,
    position: 'relative',
  },
  schedule: {
    color: palette.accent3Color,
    fontSize: 13,
    position: 'relative',
  },
  filter: {
  },
  filterWrapper: {
    padding: '15px',
  },
}

const googleMapInitialValue = {
  center: [
    GoogleMapConfiguration.center.lat,
    GoogleMapConfiguration.center.lng
  ],
  zoom: GoogleMapConfiguration.zoom,
}

const mapOptions = (maps) => {
  return {
    draggableCursor: 'default',
    scrollwheel: false,
    mapTypeId: maps.MapTypeId.ROADMAP,
  }
}

const mapStateToProps = (state) => {

  let officeEngineers = {}
  let engineersWithOffices = {}
  _.each(state.offices, (office, officeKey)=>{
    if (office.engineers) {
      officeEngineers[officeKey] = office
      _.each(office.engineers, (engineer, engineerKey)=>{
        officeEngineers[officeKey].engineers[engineerKey] = state.engineers[engineerKey] || {}
        engineersWithOffices[engineerKey] = true
      })
    }
  })
  officeEngineers['Unknown'] = {
    name: 'Unknown',
    engineers: {}
  }
  _.each(state.engineers, (engineer, engineerKey)=>{
    if (!engineersWithOffices[engineerKey]) {
      officeEngineers['Unknown'].engineers[engineerKey] = engineer
    }
  })

  const appointmentBranch = state.appointments[state.routeParams.appointmentId]
  const appointmentBranchKey = appointmentBranch ? appointmentBranch.officeId : 'Unknown'
  const appointmentBranchName = state.offices[appointmentBranchKey] ?
    state.offices[appointmentBranchKey].name.split('-')[0] : 'Unknown'
  const appointmentOfficeKey = _.findKey(officeEngineers, function (office) {
    return office.name.split('-')[0] === appointmentBranchName
  })

  return {
    appointments: state.appointments,
    jobs: state.jobs,
    map: state.map,
    routeParams: state.routeParams,
    sites: state.sites,
    engineers: state.engineers,
    branches: officeEngineers,
    branchKey: state.engineerMeta.office || appointmentOfficeKey,
    searchText: state.engineerMeta.nameSearch,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    cacheEngineer: (engineerId) => dispatch(actions.cacheEngineer(engineerId)),
    centerMap: (lat, lng) => dispatch(actions.centerMap(lat, lng)),
    updateEngineerMeta: (newMeta) => dispatch(actions.updateEngineerMeta(newMeta)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MapView)
