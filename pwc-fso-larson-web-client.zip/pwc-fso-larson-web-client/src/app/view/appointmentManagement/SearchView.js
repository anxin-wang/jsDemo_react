import React, { Component, } from 'react'
import { connect, } from 'react-redux'
import AppointmentCard from './AppointmentCard'
import SiteCard from './SiteCard'
import actions from '../../actions'
import store from '../../store'
import Subheading from '../../ui/typography/Subheading'
import Headline from '../../ui/typography/Headline'
import CircularProgress from 'material-ui/CircularProgress'

class SearchView extends Component {
  constructor(props, context) {
    super(props, context)
    this.selectAppointment = this.selectAppointment.bind(this)
    this.selectSite = this.selectSite.bind(this)
  }

  selectAppointment(appointmentId) {
    store.dispatch(actions.routeTo(
      'appointment',
      {
        appointmentId
      }
    ))
  }

  selectSite(siteId) {
    store.dispatch(actions.routeTo(
      'site',
      {
        siteId,
      }
    ))
  }

  renderAppointmentResults() {
    let search = this.props.search
    let appointments = this.props.appointments
    let appointmentIds = Object.keys(search.results.appointments)

    return (
      <div style={styles.assignedAppointments}>
        <Headline style={styles.searchHeadline}>Appointment Results</Headline>
        {
          appointmentIds.map((appointmentId) => {
            let appointment = appointments[appointmentId]
            let site = (appointment && appointment.jobId) ? this.props.sites[appointment.jobId] : null
            return appointment ? (
              <AppointmentCard
                appointment={appointment}
                appointmentId={appointmentId}
                key={appointmentId}
                selectAppointment={this.selectAppointment}
                site={site}
              />
            ) : null
          })
        }
      </div>
    )
  }

  renderSiteResults() {
    let search = this.props.search
    let sites = this.props.sites
    let siteIDs = Object.keys(search.results.sites)

    return (
      <div>
        <Headline style={styles.searchHeadline}>Site Results</Headline>
        <div style={styles.unassignedAppointments}>
          {
            siteIDs.map((siteID) => {
              return sites[siteID] ? (
                <SiteCard
                  site={sites[siteID]}
                  siteID={siteID}
                  key={siteID}
                  selectSite={this.selectSite}
                />
              ) : null
            })
          }
        </div>
      </div>
    )
  }

  renderSearchIndicator() {
    return (
      <div>
        <Headline style={styles.searchHeadline}>
          Searching...
        </Headline>
        <br />
        <CircularProgress style={styles.progress} size={0.7}/>
      </div>
    )
  }

  renderNoResults() {
    return (
      <Headline style={styles.searchHeadline}>
        <Subheading>No results found.</Subheading>
      </Headline>
    )
  }

  render() {
    let search = this.props.search

    return (
      <div style={styles.wrapper}>
        {
          search.searching ?
          this.renderSearchIndicator() : null
        }
        {
          (
            !search.searching &&
            search.results &&
            search.results.appointments
          ) ? this.renderAppointmentResults() : null
        }
        {
          !search.searching &&
          search.results && search.results.sites ? this.renderSiteResults() : null
        }
        {
          !search.searching &&
          search.results && (!search.results.appointments && !search.results.sites) ? this.renderNoResults() : null
        }
      </div>
    )
  }
}

const styles = {
  searchHeadline: {
    paddingTop: 30,
    marginTop: 0,
  },
  progress: {
    lineHeight: 0,
    marginLeft: -5,
  },
  unassignedAppointments: {
    columnCount: 2,
    columnGap: '1em',
    MozColumnCount: 2,
    MozColumnGap: '1em',
    WebkitColumnCount: 2,
    WebkitColumnGap: '1em',
    marginTop: 20,
  },
  wrapper: {
    position: 'relative',
    top: 70,
    width: 1000,
  },
}

const mapStateToProps = (state) => {
  return {
    appointments: state.appointments,
    search: state.search,
    sites: state.sites,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchView)
