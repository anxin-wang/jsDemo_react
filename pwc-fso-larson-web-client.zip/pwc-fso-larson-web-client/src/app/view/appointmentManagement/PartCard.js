import React, { Component, } from 'react'
import { Card, CardHeader, CardText } from 'material-ui/Card'
import { palette } from '../../theme/Theme.js'
import moment from 'moment'

class PartCard extends Component {
  hasNotifications() {
    let hasThem = false
    const partNotes = this.props.partNotes
    if (partNotes) {
      hasThem = true
    }
    return hasThem
  }

  render() {
    const { name, number } = this.props.part || {}

    return (
      <Card style={this.hasNotifications() ? styles.cardHasNotifications : styles.card}>
        <CardHeader
          title={name}
          subtitle={
            <div>
              <div style={styles.number}>{number}</div>
            </div>
          }
          actAsExpander
          showExpandableButton={Boolean(this.props.partNotes)}
        />

        {
          this.props.partNotes ?
          Object.keys(this.props.partNotes).map(noteId => {
            const note = this.props.notes[noteId]
            const { dispatchers } = this.props
            const author = Object.keys(dispatchers).find(dispatcher => {
              return dispatchers[dispatcher].userId === note.authorId
            })
            return (
              <CardText key={noteId} style={styles.cardText} expandable>
                <div>{'"' + note.content + '"'}</div>
                <div style={styles.createdAt}>
                  {author && dispatchers[author].name + ', ' + moment(note.createdAt).fromNow()}
                </div>
                <br />
              </CardText>
            )
          }) : null
        }

      </Card>
    )
  }
}

const styles = {
  card: {
    backgroundColor: palette.sidebarBackground,
    boxShadow: '',
    borderTop: '0.5px solid ' + palette.borderColor
  },
  cardHasNotifications: {
    backgroundColor: palette.partCommentBackground,
    boxShadow: '',
    borderTop: '0.5px solid ' + palette.borderColor
  },
  number: {
    width: 140,
    float: 'left',
  },
  floatLeft: {
    float: 'left',
  },
  cardText: {
  },
  createdAt: {
    float: 'right',
    color: palette.accent3Color,
  },
}

export default PartCard
