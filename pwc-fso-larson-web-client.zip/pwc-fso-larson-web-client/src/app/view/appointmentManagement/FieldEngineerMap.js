/*
import React, { PropTypes, Component } from 'react'
import GoogleMap from 'google-map-react'
import Marker from './Marker'
import $ from 'jquery'
import Config from '../../config'

export default class FieldEngineerMap extends Component {
  constructor(props) {
    super(props)

    this.state = {
      bounds: [],
      zoom: props.zoom,
      center: props.center,
      coordinates: props.coordinates,
      height: props.height,
    }
  }

  onSetState(modelName, value) {
    switch (modelName) {
      case 'googleMap':
        if (value.center) {
          this.setState({
            center: value.center,
          })
        }
        if (value.zoom) {
          this.setState({
            zoom: value.zoom,
          })
        }
        break
      default:
    }
  }

  static propTypes = {
    coordinates: PropTypes.object.isRequired,
    options: PropTypes.func.isRequired,
    center: PropTypes.array.isRequired,
    zoom: PropTypes.number.isRequired,
  }

  componentWillUpdate() {
    let { street, city, state, } = this.props.siteAddress
    if (street) {
      let address = encodeURI(street + ', ' + city + ', ' + state)
      this.serverRequest = $.get(
        Config.GOOGLE_GEOLOCATOR_URL + address + '&key=' + Config.API_KEY,
        (result) => {
          this.props.centerMap(
            result.results[0].geometry.location.lat,
            result.results[0].geometry.location.lng
          )
        }
      )
    }
  }

  renderEngineerLocations() {
    return Object.keys(this.props.fieldEngineers).map(engineerId => {
      const location = this.props.map.engineerLocations ? this.props.map.engineerLocations[engineerId] || [] : [0, 0]
      return (
        <Marker
          key={engineerId}
          lat={location[0]}
          lng={location[1]}
          id={'Engineer'}
        />
      )
    })
  }

  render() {
    const center = this.props.map.center
    return (
      <div style={styles.container} id={this.props.id}>
        <GoogleMap
          center={center}
          zoom={this.state.zoom}
          coordinates={this.state.coordinates}
          yesIWantToUseGoogleMapApiInternals
          options={this.props.options}
          bootstrapURLKeys={this.props.bootstrapURLKeys}
          onChildClick={(key) => { this.props.selectEngineer(key)}}
        >
        <Marker
          key={'site'}
          lat={center[0]}
          lng={center[1]}
          id={'site'}
        />
        {this.renderEngineerLocations()}
        </GoogleMap>
      </div>
    )
  }
}

const styles = {
  container: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 350,
    paddingTop: 64
  }
}
*/

import React, { Component, } from 'react'
import UnderConstruction from '../../image/underConstruction.jpg'

export default class FieldEngineerMap extends Component {
  constructor(props, context) {
    super(props, context)
  }

  render() {
    return (
      <div style={styles.outer}>
      </div>
    )
  }
}

const styles = {
  outer: {
    position: 'fixed',
    bottom: '0px',
    top: '42px',
    width: '100%',
    height: '100%',
    backgroundColor: 'white',
    backgroundImage: 'url(/' + UnderConstruction + ')',
    backgroundPosition: '25% 40%',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'contain',
  }
}
