import React, { Component, } from 'react'
import { Card, CardHeader, CardText, CardActions } from 'material-ui/Card'
import FlatButton from 'material-ui/FlatButton'
import issueDetails from '../../const/issueDetails'
import PartCard from './PartCard'
import { palette } from '../../theme/Theme.js'
import Caption from '../../ui/typography/Caption'
import Body from '../../ui/typography/Body'
import moment from 'moment'
import Truncate from 'react-truncate'
import CircularProgress from 'material-ui/CircularProgress'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'

class IssueCard extends Component {
  constructor(props) {
    super(props)
    this.state = {
      expanded: false
    }
    this.setExpandedState = this.setExpandedState.bind(this)
  }

  hasNotifications() {
    const { notes } = this.props
    const issueParts = this.props.issue.selectedParts

    return issueParts && notes && Object.keys(notes).find(noteId => {
      let note = notes[noteId]
      return note.subjectType === 'selectedPart' && Object.keys(issueParts).includes(note.subjectId)
    })
  }

  setExpandedState() {
    this.setState({
      expanded: !this.state.expanded
    })
  }

  renderLoading() {
    return (
      <div>
        <CircularProgress style={styles.progress} size={0.5}/>
      </div>
    )
  }

  equipmentCached(issue, equipment) {
    let cached = true
    if (issue.equipment) {
      Object.keys(issue.equipment).map((equipmentId) => {
        if (!equipment[equipmentId]) {
          firebaseCacheService.prioritize(
            'equipment',
            equipmentId
          )
          cached = false
        }
      })
    }
    return cached
  }

  partsCached(issue, parts) {
    let cached = true
    if (issue.selectedParts) {
      Object.keys(issue.selectedParts).map((partId) => {
        if (!parts[partId]) {
          firebaseCacheService.prioritize(
            'parts',
            partId
          )
          cached = false
        }
      })
    }
    return cached
  }

  notesCached(issue, notes) {
    let cached = true
    if (issue.partNotes) {
      Object.keys(issue.partNotes).map((partId) => {
        Object.keys(issue.partNotes[partId]).map((noteId) => {
          if (!notes[noteId]) {
            firebaseCacheService.prioritize(
              'notes',
              noteId
            )
            cached = false
          }
        })
      })
    }
    return cached
  }

  cardLoaded() {
    let isLoaded = false
    const {
      issue, globalEquipment, parts, notes,
    } = this.props
    if (
      issue &&
      issue.lastModifiedAt &&
      this.partsCached(issue, parts) &&
      this.equipmentCached(issue, globalEquipment) &&
      this.notesCached(issue, notes)
    ) {
      isLoaded = true
    }
    if (!issue || !issue.lastModifiedAt) {
      firebaseCacheService.prioritize(
        'issues',
        this.props.issueId
      )
    }
    return isLoaded
  }

  render() {
    const {
      globalEquipment, parts, notes, createdBy, dispatchers
    } = this.props
    const {
      description, type, equipment, selectedParts, partNotes, lastModifiedAt
    } = this.props.issue || {}
    const { expanded } = this.state
    let equipmentNames = equipment ? Object.keys(equipment).map(equipmentId => {
      return globalEquipment[equipmentId] ? globalEquipment[equipmentId].name : ''
    }).join(', ') : ''
    const avatar = issueDetails[type] ? issueDetails[type].avatar : ''
    const name = issueDetails[type] ? issueDetails[type].name : ''

    return (
      this.cardLoaded() ? (
        <div style={styles.issueContainer}>
          <Card
            expanded={expanded}
            key={this.props.id}
            onExpandChange={this.setExpandedState}
            style={styles.card}
          >
            {
              this.hasNotifications() ? (
                <div style={styles.notificationIndicator}>&#9679;</div>
              ) : null
            }
            <CardHeader
              avatar={avatar}
              title={
                <div style={styles.title}>
                  {name}
                </div>
              }
              subtitle={
                <div style={styles.subtitle}>
                  {
                    expanded ? equipmentNames :
                    <Truncate lines={1}>
                      {equipmentNames}
                    </Truncate>
                  }
                </div>
              }
              style={styles.cardHeader}
              actAsExpander
            />
            <CardText expandable style={styles.issueHeader}>
              <div style={styles.expandedDescription}>{description}</div>
              <Caption style={styles.commentBy}>
                { (createdBy && createdBy.name || 'You') + ', ' + moment(lastModifiedAt).fromNow()}
              </Caption>
              <br />
              <Body style={styles.parts}>
                {selectedParts && 'Related Parts:'}
              </Body>
            </CardText>
            <CardText expandable style={selectedParts && styles.partsCard}>
              {
                selectedParts && Object.keys(selectedParts).map(partId => {
                  const currentPartNotes = partNotes ? partNotes[partId] : null

                  return (
                    <PartCard
                      dispatchers={dispatchers}
                      key={partId}
                      partNotes={currentPartNotes}
                      notes={notes}
                      part={parts[partId]}
                    />
                  )
                })
              }
            </CardText>
            <CardText actAsExpander >
              <div>
                {
                  !expanded ?
                  <Truncate lines={2} ellipsis={'...'} >
                    {description}
                  </Truncate> : ''
                 }
              </div>
              <CardActions style={styles.cardActions}>
                <FlatButton label={expanded ? 'SEE LESS' : 'SEE MORE'} />
              </CardActions>
            </CardText>
          </Card>
        </div>
      ) : this.renderLoading()
    )
  }
}

const styles = {
  issueContainer: {
    padding: 2,
  },
  cardHeader: {
    backgroundColor: palette.primary1Color,
  },
  title: {
    color: palette.alternateTextColor,
  },
  subtitle: {
    color: palette.textColorLight,
    width: 220,
  },
  card: {
    display: 'inline-block',
    margin: '0 0 1em',
    width: '100%',
  },
  cardActions: {
    float: 'right',
    color: palette.accent3Color,
    marginRight: -24,
  },
  notificationIndicator: {
    color: palette.negativeColor,
    fontSize: 20,
    position: 'absolute',
    right: -4,
    top: 1,
    zIndex: 9,
    lineHeight: 0,
    display: 'block',
  },
  issueHeader: {
    paddingBottom: 5,
  },
  parts: {
    marginBottom: 0,
    clear: 'both',
  },
  partsCard: {
    padding: 0,
  },
  commentBy: {
    float: 'right',
  },
  expandedDescription: {
    wordWrap: 'break-word',
  },
}

export default IssueCard
