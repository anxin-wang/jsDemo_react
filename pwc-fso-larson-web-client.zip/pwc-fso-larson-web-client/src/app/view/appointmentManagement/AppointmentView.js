import React, { Component, } from 'react'
import { connect, } from 'react-redux'
import AppointmentHeader from './AppointmentHeader'
import ClientInformation from '../clientManagement/ClientInformation'
import IssueCard from './IssueCard'
import actions from '../../actions'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'
import { Grid, Cell } from 'react-mdl'

const appointmentTypeInfo = true

class AppointmentView extends Component {
  componentWillMount() {
    firebaseCacheService.prioritize(
      'appointments',
      this.getAppointmentId()
    )
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  render() {
    const appointmentId = this.getAppointmentId()
    const {
      appointments, clients, engineers, issues, jobs, location,
      removeAppointmentFromEngineer, removeEngineerFromAppointment, sites, dispatchers
    } = this.props
    const {
      status, recommendedEngineers, createdAt, priority, jobId, type,
      assignedEngineer, callerName, callerPhoneNumber, serviceDescription, createdBy
    } = appointments[appointmentId] || {}
    const job = jobs[jobId] || {}
    const completedAt = job.completedAt ? job.completedAt : null
    const site = job ? sites[job.siteId] : null
    const client = site ? clients[site.clientId] : null
    const caller = {name: callerName, phone: callerPhoneNumber}
    const appointment = appointments[appointmentId] || {}
    const legacyId = appointment && appointment.legacyId ? appointment.legacyId : 'Pending'
    const assignedAt = appointment && appointment.assignedAt ? appointment.assignedAt : null
    const lastModifiedAt = appointment && appointment.lastModifiedAt ? appointment.lastModifiedAt : null
    let dispatcher = Object.keys(dispatchers).find((dispatcher) => {
      return dispatchers[dispatcher].userId === createdBy //TODO: createdBy should be set as dispatcher reference Id
    })
    return (
      <Grid style={styles.wrapper}>
        <Cell col={9}>
          <AppointmentHeader
            serviceDescription={serviceDescription}
            createdBy={dispatchers[dispatcher]}
            appointmentId={appointmentId}
            assignedEngineer={assignedEngineer}
            createdAt={createdAt}
            assignedAt={assignedAt}
            lastModifiedAt={lastModifiedAt}
            legacyId={legacyId}
            engineer={appointment && engineers[appointment.assignedEngineer]}
            priority={priority}
            recommendedEngineers={recommendedEngineers}
            removeEngineerFromAppointment={removeEngineerFromAppointment}
            removeAppointmentFromEngineer={removeAppointmentFromEngineer}
            status={status}
            completedAt={completedAt}
          />
          {
            appointment.issues &&
            Object.keys(appointment.issues).map((issueId) => {
              const issue = issues[issueId]
              const { equipment, parts, notes } = this.props
              return (
                <Cell col={6} key={issueId}>
                  <IssueCard
                    dispatchers={dispatchers}
                    createdBy={dispatchers[dispatcher]}
                    globalEquipment={equipment}
                    parts={parts}
                    notes={notes}
                    issue={issue}
                    issueId={issueId}
                  />
                </Cell>
              )
            })
          }
        </Cell>
        <Cell col={3}>
          <ClientInformation
            appointments={appointments}
            caller={caller}
            client={client}
            engineers={engineers}
            jobs={jobs}
            pathname={location.pathname}
            site={site}
            siteId={job ? job.siteId : null}
            type={type}
            appointmentTypeInfo={appointmentTypeInfo}
          />
        </Cell>
      </Grid>
    )
  }
}

const styles = {
  main: {
  },
  wrapper: {
  }
}

const mapStateToProps = (state) => {
  return {
    appointments: state.appointments,
    clients: state.clients,
    dispatchers: state.dispatchers,
    equipment: state.equipment,
    engineers: state.engineers,
    issues: state.issues,
    jobs: state.jobs,
    notes: state.notes,
    parts: state.parts,
    routeParams: state.routeParams,
    siteHistories: state.siteHistories,
    sites: state.sites,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    removeEngineerFromAppointment: (appointmentId, engineerId) => dispatch(
      actions.removeEngineerFromAppointment(appointmentId, engineerId)
    ),
    removeAppointmentFromEngineer: (appointmentId, engineerId) => dispatch(
      actions.removeAppointmentFromEngineer(appointmentId, engineerId)
    ),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AppointmentView)
