import React, { Component, } from 'react'
import { connect, } from 'react-redux'
import { RaisedButton, Avatar, FlatButton } from 'material-ui'
import actions from '../../actions'
import ActionAccountCirle from 'material-ui/svg-icons/action/account-circle'
import avatarTypes from '../../const/avatarTypes'
import Headline from '../../ui/typography/Headline'
import image from '../../image/header.jpg'
import moment from 'moment'
import priorities from '../../const/priorities'
import store from '../../store'
import appointmentStatus from '../../const/appointmentStatus'

class AppointmentHeader extends Component {
  constructor(props) {
    super(props)

    this.showRemoveTechDialog = this.showRemoveTechDialog.bind(this)
    this.removeEngineer = this.removeEngineer.bind(this)
    this.props.startListeningToOffices()
  }

  showRemoveTechDialog() {
    this.props.showDialog({
      title: 'Are you sure you want to remove the current technician?',
      acceptCallback: this.removeEngineer,
      acceptCaption: 'YES',
      rejectCaption: 'NO',
    })
  }

  removeEngineer() {
    const {
      appointmentId, assignedEngineer,
      removeAppointmentFromEngineer, removeEngineerFromAppointment,
    } = this.props
    removeAppointmentFromEngineer(appointmentId, assignedEngineer)
    removeEngineerFromAppointment(appointmentId, assignedEngineer)
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  getNewAppointment() {
    return this.getAppointmentId() ?
      this.props.appointments[this.getAppointmentId()] || {} : {}
  }

  getNewJob() {
    return this.props.jobs ? this.props.jobs[this.getNewAppointment().jobId] : {}
  }

  getCurrentOffice() {
    return this.props.offices ? this.props.offices[this.getNewAppointment().officeId] : 'N/A'
  }

  render() {
    let {
      appointmentId, createdAt, assignedAt, legacyId, engineer, priority, status,
      serviceDescription, completedAt } = this.props
    engineer = engineer || {}
    let appointmentDescription = this.getNewAppointment().appointmentDescription
    let newJob = this.getNewJob()
    let timePassed

    if (status === appointmentStatus.UNASSIGNED) {
      timePassed = moment(createdAt).fromNow()
    }
    if (status === appointmentStatus.ACKNOWLEDG) {
      timePassed = moment(assignedAt).fromNow()
    }
    if (status === appointmentStatus.COMPLETED) {
      timePassed = moment(completedAt).fromNow()
    }
    const CustomerPONumer = newJob ? newJob.purchaseOrder : 'N/A'
    const QuotedAmount = newJob ? newJob.quotedAmount : 'N/A'
    const Branch = this.getCurrentOffice() ? this.getCurrentOffice().name : 'N/A'
    const NotToExceedAmount = newJob ? newJob.notToExceedAmount : 'N/A'

    return (
      <div style={styles.imgWrapper} className="roboto">
        <div style={styles.backgroundImage}>
          { status === appointmentStatus.UNASSIGNED ?
            <Headline style={styles.headline}>
              <ActionAccountCirle style={styles.notificationAvatar}/>
              {status.toLowerCase()}
            </Headline> :
            <Headline style={styles.assignedHeadline}>
              <p style={styles.legacyId}>{legacyId}</p>
              <Avatar src={avatarTypes[engineer.firstName]} style={styles.notificationAvatar}/>
              {engineer.firstName} {engineer.lastName}
            </Headline>
          }
          <div style={styles.headlineSubText}>
            <span>{ 'P' + (priorities[priority] ? priorities[priority].text + ', ' : '')}</span>
            <span>{
              status === appointmentStatus.UNASSIGNED ?
              'Created ' + timePassed :
              status === appointmentStatus.ACKNOWLEDG ?
              'Assigned ' + timePassed :
              status === appointmentStatus.COMPLETED ?
              'Completed ' + timePassed : null
            }</span>
          </div>
          {
            status === appointmentStatus.ACKNOWLEDG ?
              <RaisedButton
                label="Remove Tech"
                secondary
                style={styles.btn}
                onClick={this.showRemoveTechDialog}
              /> : null
          }
          {
          status === appointmentStatus.UNASSIGNED ?
              <RaisedButton
                label="Assign Tech"
                secondary
                style={styles.btn}
                onClick={() => store.dispatch(actions.routeTo(
                  'mapView',
                  {
                    appointmentId,
                  }
                ))}
              /> : null
          }
          <br />
          <div style={ styles.serviceDescription } className="roboto">
            {appointmentDescription}
          </div>
        </div>
        {
          !this.props.appointmentsMeta.toggleAppointmentDetail ?
          <div style={styles.seeMoreBtn}>
            <FlatButton label="SEE MORE" onClick={() => {
              this.props.toggleAppointmentDetail()
            }}/>
          </div> : null
        }
        {
          this.props.appointmentsMeta.toggleAppointmentDetail ?
          <div style={styles.seeMoreDetailWrapper}>
            <div style={styles.seeMoreDetail}>
              <div style={styles.columnFirst}>
                <div style={styles.infoItem}>
                  <p style={styles.infoItemTitle}>{'Customer PO Numer'}</p>
                  <p style={styles.infoItemContent}>{CustomerPONumer}</p>
                </div>
                <div style={styles.infoItem}>
                  <p style={styles.infoItemTitle}>{'Quoted amount'}</p>
                  <p style={styles.infoItemContent}>{QuotedAmount}</p>
                </div>
                <div style={styles.infoItem}>
                  <p style={styles.infoItemTitle}>{'Additional notes'}</p>
                  <p style={styles.infoItemContent}>
                    {serviceDescription ? serviceDescription : null}
                  </p>
                </div>
              </div>
              <div style={styles.columnSecond}>
                <div style={styles.infoItem}>
                  <p style={styles.infoItemTitle}>{'Branch'}</p>
                  <p style={styles.infoItemContent}>{Branch}</p>
                </div>
                <div style={styles.infoItem}>
                  <p style={styles.infoItemTitle}>{'Not to exceed amount'}</p>
                  <p style={styles.infoItemContent}>{NotToExceedAmount}</p>
                </div>
              </div>
              <div style={styles.seeLessBtn}>
                <FlatButton label="SEE LESS" onClick={() => {
                  this.props.toggleAppointmentDetail()
                }}/>
              </div>
            </div>
          </div> : null
        }
        </div>
    )
  }
}

const styles = {
  assignedHeadline: {
    marginTop: 24,
  },
  backgroundImage: {
    backgroundImage: `url(/${image})`,
    backgroundSize: 'cover',
    paddingLeft: 24,
    paddingRight: 24,
    paddingTop: 38,
    position: 'relative',
  },
  btn: {
    float: 'right',
    marginTop: -50,
  },
  headline: {
    marginTop: 24,
    textTransform: 'capitalize',
  },
  headlineSubText: {
    color: 'gray',
    fontSize: 14,
    marginLeft: 62,
    marginTop: 2,
  },
  imgWrapper: {
    paddingTop: 50,
    overflow: 'auto',
  },
  notificationAvatar: {
    float: 'left',
    marginRight: 20,
    marginTop: -12,
    height: 48,
    width: 48,
  },
  serviceDescription: {
    color: 'black',
    fontSize: 16,
    paddingBottom: 20,
  },
  createdBy: {
    marginTop: 0,
    paddingBottom: 20,
  },
  legacyId: {
    marginLeft: 70,
    marginBottom: 4,
    fontSize: 14,
  },
  seeMoreBtn: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    marginTop: 0,
    textAlign: 'right',
  },
  seeMoreDetailWrapper: {
    position: 'relative',
    top: -10,
  },
  seeMoreDetail: {
    display: 'flex',
    backgroundColor: '#FFFFFF',
    padding: 20,
    boxSizing: 'border-box',
  },
  columnFirst: {
    flex: 1,
  },
  infoItemTitle: {
    fontSize: 12,
    color: '#999999',
    marginBottom: -6,
  },
  infoItemContent: {
    fontSize: 14,
    color: '#333333',
  },
  columnSecond: {
    flex: 3,
  },
  seeLessBtn: {
    position: 'absolute',
    bottom: 4,
    right: 4,
  }
}

const mapStateToProps = (state) => {
  return {
    appointmentsMeta: state.appointmentsMeta,
    routeParams: state.routeParams,
    appointments: state.appointments,
    jobs: state.jobs,
    offices: state.offices,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    showDialog: (dialog) => dispatch(actions.showDialog(dialog)),
    toggleAppointmentDetail: () => dispatch(actions.updateToggleAppointmentDetail()),
    startListeningToOffices: () => dispatch(actions.startListeningToOffices()),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AppointmentHeader)
