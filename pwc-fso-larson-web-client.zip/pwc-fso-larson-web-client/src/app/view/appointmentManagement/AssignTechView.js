import React, { Component, PropTypes, } from 'react'
import { connect, } from 'react-redux'
import { palette } from '../../theme/Theme.js'
import {
  AppBar, Avatar, Card, CardText, Drawer, FloatingActionButton,
} from 'material-ui'
import actions from '../../actions'
import avatarTypes from '../../const/avatarTypes'
import CircularProgress from 'material-ui/CircularProgress'
import ContentAdd from 'material-ui/svg-icons/content/add'
import CurrentAppointmentCard from './CurrentAppointmentCard'
import FieldEngineerMap from './FieldEngineerMap'
import GoogleMapConfiguration from '../../configuration/GoogleMap'
import MapsPlace from 'material-ui/svg-icons/maps/place'
import NavigationArrowBack from 'material-ui/svg-icons/navigation/arrow-back'
import store from '../../store'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'
import appointmentStatus from '../../const/appointmentStatus'

class MapView extends Component {
  constructor(props) {
    super(props)
    this.showAssignTechDialog = this.showAssignTechDialog.bind(this)
    this.assignmentComplete = this.assignmentComplete.bind(this)
  }

  componentWillUpdate() {
    const engineer = this.props.engineers[this.getEngineerId()]
    if (!engineer) {
      firebaseCacheService.prioritize(
        'engineers',
        this.getEngineerId()
      )
    }
    const appointment = this.props.appointments[this.getAppointmentId()]
    if (!appointment) {
      firebaseCacheService.prioritize(
        'appointments',
        this.getAppointmentId()
      )
    }
  }

  static contextTypes = {
    router: PropTypes.object.isRequired,
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  getEngineerId() {
    return this.props.routeParams.engineerId
  }

  showAssignTechDialog() {
    const {
      engineers, appointments
    } = this.props
    const engineerId = this.getEngineerId()
    const appointmentId = this.getAppointmentId()
    const {
      firstName, lastName,
    } = engineers[engineerId] || {}
    const {
      legacyId
    } = appointments[appointmentId] || {}
    this.props.showDialog({
      title: 'Assign ' + firstName + ' ' + lastName +
        ((legacyId && (' to Appt #' +
        legacyId)) || ' to this appointment') + '?',
      content: 'This will send an alert to ' + firstName + ' and change the appointment status to Assigned.',
      acceptCallback: this.assignmentComplete,
      acceptCaption: 'YES',
      rejectCaption: 'NO',
    })
  }

  assignmentComplete() {
    const {
      addAppointmentToEngineer,
      addEngineerToAppointment,
    } = this.props
    const engineerId = this.getEngineerId()
    const appointmentId = this.getAppointmentId()
    addEngineerToAppointment(appointmentId, engineerId)
    addAppointmentToEngineer(appointmentId, engineerId)
    this.props.updateAppointmentMeta({
      appointmentStatus: appointmentStatus.ASSIGNED,
    })
    store.dispatch(actions.routeTo(
      'viewAppointments',
      {
        'refresh': true,
      }
    ))
  }

  renderLoading() {
    return (
      <div>
        <CircularProgress style={styles.progress} size={0.5}/>
      </div>
    )
  }

  render() {
    const {
      jobs, sites, engineers, appointments
    } = this.props
    const engineerId = this.getEngineerId()
    const appointmentId = this.getAppointmentId()
    const {
      firstName, lastName, legacyId, assignedAppointments
    } = engineers[engineerId] || {}
    const { jobId, } = appointments[appointmentId] || {}
    const job = jobs[jobId]
    const site = job ? sites[job.siteId] : null
    const address = site ? site.address : {}
    const selectedEngineers = {}
    selectedEngineers[engineerId] = engineers[engineerId]

    return (
      <div>
        <Drawer
          width={350}
          openPrimary
          open
          containerStyle={styles.container}
        >
          <AppBar
            title="Assign"
            iconElementLeft={
              <NavigationArrowBack
                style={styles.backIcon}
                onClick={this.context.router.goBack}
              />
            }
          />
          <Card style={styles.techInfoHeader}>
            <CardText style={styles.techInfo}>
              <div style={styles.techName}>
                {engineers[engineerId] ? firstName + ' ' + lastName : ''}
                <div style={styles.techId}>{legacyId}</div>
              </div>
              <Avatar src={avatarTypes[firstName]} style={styles.accountIcon}/>
            </CardText>
            <MapsPlace style={styles.mapIcon}/>
          </Card>
          <div style={styles.assignTo}>
            Assign to {legacyId}
          </div>
          <Card>
            <CardText>
              Current appointments:
            </CardText>
          </Card>
          {
            assignedAppointments && Object.keys(assignedAppointments).map(currentAppointmentId => {
              return appointments[currentAppointmentId] ? (
                <CurrentAppointmentCard
                  appointment={appointments[currentAppointmentId]}
                  appointmentId={currentAppointmentId}
                  key={currentAppointmentId}
                  site={jobs[appointments[currentAppointmentId].jobId] &&
                    sites[jobs[appointments[currentAppointmentId].jobId].siteId]
                  }
                />
              ) : null
            })
          }
          <FloatingActionButton
            secondary
            style={styles.fabBtn}
            onTouchTap={this.showAssignTechDialog}
          >
            <ContentAdd />
          </FloatingActionButton>
        </Drawer>
        {
          site ? (
            <FieldEngineerMap
              fieldEngineers={selectedEngineers}
              siteAddress={address}
              options={mapOptions}
              zoom={googleMapInitialValue.zoom}
              center={googleMapInitialValue.center}
              bootstrapURLKeys={GoogleMapConfiguration.bootstrapURLKeys}
              coordinates={{}}
              map={this.props.map}
              centerMap = {this.props.centerMap}
            />
          ) : this.renderLoading()
        }
      </div>
    )
  }
}

const mapOptions = (maps) => {
  return {
    draggableCursor: 'default',
    scrollwheel: false,
    mapTypeId: maps.MapTypeId.ROADMAP,
  }
}

const googleMapInitialValue = {
  center: [
    GoogleMapConfiguration.center.lat,
    GoogleMapConfiguration.center.lng
  ],
  zoom: GoogleMapConfiguration.zoom,
}

const styles = {
  map: {
    width: '94%',
    height: '100%',
    position: 'fixed',
  },
  container: {
    overflow: null,
  },
  fabBtn: {
    zIndex: 9999,
    top: 157,
    right: -25,
    position: 'fixed',
  },
  backIcon: {
    marginTop: 12,
    color: palette.textColorLight,
    cursor: 'pointer',
  },
  accountIcon: {
    height: 75,
    width: 75,
    float: 'right',
    paddingRight: 0,
    color: palette.accent2Color,
  },
  techInfo: {
    backgroundColor: palette.primary1Color,
    marginBottom: 45,
  },
  techInfoHeader: {
    backgroundColor: palette.primary1Color,
    paddingBottom: 15,
  },
  cardHeader: {
    paddingRight: 0,
  },
  techName: {
    fontSize: 25,
    color: palette.alternateTextColor,
    paddingRight: 0,
    float: 'left',
  },
  techId: {
    fontSize: 16,
    color: palette.accent2Color,
    paddingRight: 0,
  },
  assignTo: {
    marginBottom: 10,
    marginLeft: 17,
    marginTop: 10,
    fontSize: 15,
    fontWeight: 500,
  },
  mapIcon: {
    color: palette.accent2Color,
    marginLeft: 20,
  }
}

const mapStateToProps = (state) => {
  return {
    appointments: state.appointments,
    engineers: state.engineers,
    jobs: state.jobs,
    map: state.map,
    routeParams: state.routeParams,
    sites: state.sites,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    addAppointmentToEngineer: (appointmentId, engineerId) => dispatch(
      actions.addAppointmentToEngineer(appointmentId, engineerId)
    ),
    addEngineerToAppointment: (appointmentId, engineerId) => dispatch(
      actions.addEngineerToAppointment(appointmentId, engineerId)
    ),
    centerMap: (lat, lng) => dispatch(actions.centerMap(lat, lng)),
    showDialog: (dialog) => dispatch(actions.showDialog(dialog)),
    updateAppointmentMeta: (newMeta) => dispatch(actions.updateAppointmentMeta(newMeta)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MapView)
