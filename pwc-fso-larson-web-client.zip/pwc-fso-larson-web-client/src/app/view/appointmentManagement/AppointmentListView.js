import React, { Component, PropTypes, } from 'react'
import { connect, } from 'react-redux'
import actions from '../../actions'
import AppointmentCard from './AppointmentCard'
import appointmentStatus from '../../const/appointmentStatus'
import store from '../../store'
import CircularProgress from 'material-ui/CircularProgress'
import GoogleMap from 'google-map-react'
import Config from '../../config'
import GoogleMapConfig from '../../configuration/GoogleMap'
import {Tabs, Tab} from 'material-ui/Tabs'
import scrollmax from 'get-scrollmax-y'
import { SelectField, MenuItem, TextField } from 'material-ui'
import Checkbox from 'material-ui/Checkbox'

class AppointmentListView extends Component {
  constructor(props, context) {
    super(props, context)
    this.selectAppointment = this.selectAppointment.bind(this)
    this.handleChangeSort = this.handleChangeSort.bind(this)
    this.onSetSortAddress = this.onSetSortAddress.bind(this)
  }

  static contextTypes = {
    router: PropTypes.object.isRequired,
  }

  onDataReady() {
    window.onscroll = (event) => {
      if (event.srcElement.scrollingElement.scrollTop >= scrollmax()) {
        this.props.updateAppointmentMeta({
          pageSize: this.props.appointmentsMeta.pageSize + 16
        })
        this.props.cacheReviewedAppointmentIndexes()
      }
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    const {
      appointmentIndexes, appointmentsMeta,
    } = nextProps
    return Object.keys(appointmentIndexes).length <= appointmentsMeta.pageSize
  }

  componentWillUnmount() {
    window.onscroll = null
  }

  selectAppointment(appointmentId) {
    store.dispatch(actions.routeTo(
      'appointment',
      {
        appointmentId,
      }
    ))
  }

  onSortAddressChange(event) {
    this.props.setSortAddress(event.target.value)
  }

  getRefresh() {
    return this.props.routeParams.refresh === 'true'
  }

  openAddressDialog() {
    this.props.showDialog({
      title: 'Distance from address',
      content: <TextField
        hintText="Enter Address"
        onChange={this.onSortAddressChange.bind(this)}
                 fullWidth />,
      acceptCallback: this.onSetSortAddress,
      acceptCaption: 'Confirm',
      rejectCaption: 'Cancel',
    })
  }

  onSetSortAddress() {
  }

  onGoogleApiLoaded(googlemap) {
    this.props.registerMapsAPI(googlemap.maps)
  }

  handleChangeSort(event, index, value) {
    this.props.setSortMethod(value)
    if (value === 'distance') {
      // distance sorting will a different order method
      this.openAddressDialog()
    } else {
      this.props.setOrderMethod(value)
      this.props.cacheReviewedAppointmentIndexes()
    }
  }

  onChangeAppointmentStatusFilter(filter) {
    const sortMethod = this.props.appointmentsMeta.sortMethod === 'distance' &&
      this.props.appointmentsMeta.appointmentStatus ?
      'priority' : this.props.appointmentsMeta.sortMethod
    this.props.setOrderMethod(sortMethod)
    this.props.updateAppointmentMeta({
      appointmentStatus: filter,
      pageSize: 16,
      sortMethod: sortMethod,
    })
    this.props.cacheReviewedAppointmentIndexes()
  }

  onCheckAppointmentType(type, event, isInputChecked) {
    let appointmentType = this.props.appointmentsMeta.appointmentType
    if (type === 'REG') {
      appointmentType['TM'] = isInputChecked
      appointmentType['CJ'] = isInputChecked
      appointmentType['COD'] = isInputChecked
      appointmentType['MC'] = isInputChecked
    } else {
      appointmentType['AH'] = isInputChecked
    }
    this.props.updateAppointmentMeta({
      appointmentType: appointmentType,
    })
    this.props.cacheReviewedAppointmentIndexes()
  }

  componentWillMount() {
    if (this.getRefresh()) {
      this.props.cacheReviewedAppointmentIndexes()
    }
  }

  render() {
    const {
      appointmentIndexes, appointmentsMeta,
    } = this.props

    let initialSelectedTab
    let initialTabValue
    let shouldRenderUnassignedAppointments = false
    let shouldRenderAssignedAppointments = false
    let shouldRenderCompletedAppointments = false
    switch (appointmentsMeta.appointmentStatus) {
      case appointmentStatus.UNASSIGNED:
        shouldRenderUnassignedAppointments = true
        initialSelectedTab = 0
        initialTabValue = appointmentStatus.UNASSIGNED
        break
      case appointmentStatus.ASSIGNED:
        shouldRenderAssignedAppointments = true
        initialSelectedTab = 1
        initialTabValue = appointmentStatus.ASSIGNED
        break
      case appointmentStatus.COMPLETED:
        shouldRenderCompletedAppointments = true
        initialSelectedTab = 2
        initialTabValue = appointmentStatus.COMPLETED
        break
      default:

    }
    const appointmentIndexLength = Object.keys(appointmentIndexes).length
    appointmentIndexLength ? this.onDataReady() : null
    const REGChecked = appointmentsMeta.appointmentType.TM &&
      appointmentsMeta.appointmentType.CJ &&
      appointmentsMeta.appointmentType.COD &&
      appointmentsMeta.appointmentType.MC
    const loading = appointmentsMeta.loading

    return (
      <div style={styles.wrapper}>
        <GoogleMap
          onGoogleApiLoaded={this.onGoogleApiLoaded.bind(this)}
          yesIWantToUseGoogleMapApiInternals
          zoom={GoogleMapConfig.zoom}
          center={GoogleMapConfig.center}
          bootstrapURLKeys={Config.API_KEY} />
        <div style={styles.filterWrapper}>
          <div style={styles.appointmentTypeContainer}>
            <Checkbox
              label="REGULAR"
              style={styles.appointmentType}
              checked={REGChecked}
              onCheck={this.onCheckAppointmentType.bind(this, 'REG')}
            />
            <Checkbox
              label="AFTER HOURS"
              checked={appointmentsMeta.appointmentType.AH}
              style={styles.appointmentType}
              onCheck={this.onCheckAppointmentType.bind(this, 'AH')}
            />

          </div>
          <SelectField
            value={this.props.appointmentsMeta.sortMethod}
            onChange={this.handleChangeSort}
            iconStyle={styles.highPriorityIconStyle}
            style={styles.appointmentType}
            autoWidth
          >
            <MenuItem value={'priority'} primaryText="Highest Priority" />
            <MenuItem value={'activity'} primaryText="Most Recent" />
            <MenuItem value={'distance'} primaryText="Distance from Address" />
          </SelectField>
        </div>

        <Tabs
          onChange={this.onChangeAppointmentStatusFilter.bind(this)}
          initialSelectedIndex={initialSelectedTab}
          tabItemContainerStyle={styles.tabItemContainer}
          inkBarStyle={styles.tabInkBar}
          value={initialTabValue}
          className={'appointmentList'}
        >
          <Tab
            label={appointmentStatus.UNASSIGNED}
            value={appointmentStatus.UNASSIGNED}
          >
            {
              !loading && !appointmentIndexLength ? (
                <div style={styles.loadingContainer}>
                  <img src="/images/empty-data.png" width="403" height="403" />
                </div>
              ) : (<div style={styles.appointmentCardList}>
                {
                  Object.keys(appointmentIndexes).map((appointmentIndexId) => {
                    const appointmentIndex = appointmentIndexes[appointmentIndexId]
                    const appointmentId = appointmentIndex.appointmentId
                    return (
                      <AppointmentCard
                        appointmentId={appointmentId}
                        shouldRender={shouldRenderUnassignedAppointments}
                        key={appointmentStatus.UNASSIGNED + appointmentId}
                        distance={appointmentIndex.distance ? appointmentIndex.distance : null}
                        selectAppointment={this.selectAppointment}
                        appointmentIndex={appointmentIndex}
                        recentlyCreated={appointmentsMeta.recentlyCreated}
                        clearRecentlyCreated={this.props.clearRecentlyCreated}
                      />
                    )
                  })
                }
              </div>
              )
            }
          </Tab>
          <Tab
            label={appointmentStatus.ASSIGNED}
            value={appointmentStatus.ASSIGNED}
          >
            {
              !loading && !appointmentIndexLength ? (
                <div style={styles.loadingContainer}>
                  <img src="/images/empty-data.png" width="403" height="403" />
                </div>
              ) : (<div style={styles.appointmentCardList}>
                {
                  Object.keys(appointmentIndexes).map((appointmentIndexId) => {
                    const appointmentIndex = appointmentIndexes[appointmentIndexId]
                    const appointmentId = appointmentIndex.appointmentId

                    return (
                      <AppointmentCard
                        appointmentId={appointmentId}
                        shouldRender={shouldRenderAssignedAppointments}
                        key={appointmentStatus.ASSIGNED + appointmentId}
                        selectAppointment={this.selectAppointment}
                        appointmentIndex={appointmentIndex}
                        recentlyCreated={appointmentsMeta.recentlyCreated}
                        clearRecentlyCreated={this.props.clearRecentlyCreated}
                      />
                    )
                  })
                }
              </div>
              )
            }
          </Tab>
          <Tab
            label={appointmentStatus.COMPLETED}
            value={appointmentStatus.COMPLETED}
          >
            {
              !loading && !appointmentIndexLength ? (
                <div style={styles.loadingContainer}>
                  <img src="/images/empty-data.png" width="403" height="403" />
                </div>
              ) : (<div style={styles.appointmentCardList}>
                {
                  Object.keys(appointmentIndexes).map((appointmentIndexId) => {
                    const appointmentIndex = appointmentIndexes[appointmentIndexId]
                    const appointmentId = appointmentIndex.appointmentId

                    return (
                      <AppointmentCard
                        appointmentId={appointmentId}
                        shouldRender={shouldRenderCompletedAppointments}
                        key={appointmentStatus.COMPLETED + appointmentId}
                        selectAppointment={this.selectAppointment}
                        appointmentIndex={appointmentIndex}
                        recentlyCreated={appointmentsMeta.recentlyCreated}
                        clearRecentlyCreated={this.props.clearRecentlyCreated}
                      />
                    )
                  })
                }
              </div>
              )
            }
          </Tab>
        </Tabs>
        {
          loading ? (
            <div style={styles.loadingContainer}>
              <CircularProgress style={styles.progress} size={0.7}/>
              <span style={styles.loadingText}>Loading more data...</span>
            </div>
          ) : null
        }
      </div>
      )
  }
}

const styles = {
  filterWrapper: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
    width: '98%',
    marginBottom: '10px',
  },
  progress: {
    marginTop: 40,
  },
  unassignedAppointments: {
    marginTop: 0,
  },
  wrapper: {
    paddingTop: 72,
    marginTop: 50,
    width: '80%',
  },
  appointmentCardList: {
    display: 'flex',
    flexDirection: 'column',
  },
  tabItemContainer: {
    position: 'fixed',
    top: 64,
    marginLeft: '-23%',
    zIndex: 2,
    backgroundColor: '#ffffff',
    color: 'rgba(0, 0, 0, 0.870588)',
  },
  tabInkBar: {
    position: 'fixed',
    top: 112,
    zIndex: 2,
  },
  appointmentTypeContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    flexWrap: 'wrap',
    paddingTop: '13px',
  },
  appointmentType: {
    width: 160,
  },
  loadingContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'baseline',
  },
  loadingText: {
    marginLeft: 10,
  },
  highPriorityIconStyle: {
    fill: 'rgba(90, 90, 90, 1)'
  }
}

const mapStateToProps = (state) => {
  return {
    appointments: state.appointments,
    appointmentsMeta: state.appointmentsMeta,
    appointmentIndexes: state.appointmentIndexes,
    engineers: state.engineers,
    jobs: state.jobs,
    maps: state.maps,
    search: state.search,
    sites: state.sites,
    routeParams: state.routeParams,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    clearRecentlyCreated: () => dispatch(actions.clearRecentlyCreated()),
    setOrderMethod: (orderMethod) => dispatch(actions.setOrderMethod(orderMethod)),
    setSortMethod: (sortMethod) => dispatch(actions.setSortMethod(sortMethod)),
    showDialog: (dialog) => dispatch(actions.showDialog(dialog)),
    setSortAddress: (address) => dispatch(actions.setSortAddress(address)),
    registerMapsAPI: (maps) => dispatch(actions.registerMapsAPI(maps)),
    cacheReviewedAppointmentIndexes: () => dispatch(actions.cacheReviewedAppointmentIndexes()),
    updateAppointmentMeta: (newMeta) => dispatch(actions.updateAppointmentMeta(newMeta)),
    calculateDistances: () => dispatch(actions.calculateDistances()),
    sortAppointments: () => dispatch(actions.sortAppointments()),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AppointmentListView)
