import React, { Component, } from 'react'
import { Card, CardHeader, CardText, Divider, List, } from 'material-ui'
import { RaisedButton } from 'material-ui'
import { connect } from 'react-redux'
import actions from '../../actions'
import { formatZipCode, } from '../../filters/zipCode'
import appointmentTypes from '../../const/appointmentTypes'
import Body from '../../ui/typography/Body'
import Caption from '../../ui/typography/Caption'
import CircularProgress from 'material-ui/CircularProgress'
import filterPhoneNumber from '../../filters/phoneNumber'
import moment from 'moment'
import SiteDetailsItem from '../../ui/global/SiteDetailsItem'
import SiteDetailsBillToItem from '../../ui/global/SiteDetailsBillToItem'
import StaticListItem from '../../ui/global/StaticListItem'
import Subheading from '../../ui/typography/Subheading'
import Title from '../../ui/typography/Title'
import MenuItem from 'material-ui/MenuItem'

const actAsExpander = true
const showExpandableButton = true
const expandable = true
const fullWidth = true
let customerIdNameAddressDataSource = []

class ClientInformation extends Component {
  constructor(props) {
    super(props)
    this.state = {
      billName: 'name',
      billingAddress: 'address',
      nameValue: false,
      addressValue: false,
      customerNameAddress: 'nameAddress',
      displayDefault: true
    }
    this.selectBillingType = this.selectBillingType.bind(this)
    this.handleConfirm = this.handleConfirm.bind(this)
    this.onNewRequest = this.onNewRequest.bind(this)
    this.changeBillInfo = this.changeBillInfo.bind(this)
    this.props.startListeningToClients()
  }

  shouldComponentUpdate(nextProps, nextState) {
    const response = (
      JSON.stringify(this.props.site) !== JSON.stringify(nextProps.site)
    )

    if (nextState.billName || nextState.billingAddress ||
        nextState.customerNameAddress) {
      return true
    }

    return response
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  getNewAppointment() {
    return this.getAppointmentId() ?
      this.props.appointments[this.getAppointmentId()] || {} : {}
  }

  getNewJob() {
    return this.props.jobs ? this.props.jobs[this.getNewAppointment().jobId] : {}
  }

  getbillName() {
    let billToType = this.getNewJob().billToType ? this.getNewJob().billToType : null
    let billTo = this.getNewJob().billTo ? this.getNewJob().billTo : null
    let billName = 'N/A'

    if (billToType === 'client' && billTo) {
      billName = (this.props.clients[billTo] || {}).name
    }
    if (billToType === 'site' && billTo) {
      billName = (this.props.sites[billTo] || {}).name
    }

    return billName
  }

  getbillAddress() {
    let billToType = this.getNewJob().billToType ? this.getNewJob().billToType : null
    let billTo = this.getNewJob().billTo ? this.getNewJob().billTo : null
    let billAddress = 'N/A'

    if (billToType === 'client' && billTo) {
      let currentClient = this.props.clients[billTo]
      if (currentClient) {
        billAddress = currentClient.address.street + ', ' +
                    currentClient.address.city + ', ' + currentClient.address.state +
                    ', ' + currentClient.address.zip
      }
    }

    if (billToType === 'site' && billTo) {
      let currentSite = this.props.sites[billTo]
      if (currentSite) {
        billAddress = currentSite.address.street + ', ' +
                    currentSite.address.city + ', ' + currentSite.address.state +
                    ', ' + currentSite.address.zip
      }
    }

    return billAddress
  }

  selectBillingType(value) {
    let billName = 'N/A'
    let billingAddress = 'N/A'
    let newValue = value.split(' – ')[0]
    let jobId = Object.keys(this.props.jobs)[0]

    this.props.updateAppointment(
      this.getAppointmentId(),
      {
        type: newValue
      }
    )

    if (newValue === 'TM') {
      if (this.props.jobs[jobId]['billType'] === 'site') {
        // let siteId = this.props.jobs.billTo
        if (this.props.site.name) { billName = this.props.site.name }
        if (this.props.site.address.street) { billingAddress = this.props.site.address.street }
      }
      if (this.props.jobs[jobId]['billType'] === 'client') {
        // let clientId = this.props.jobs.billTo
        if (this.props.client.name) { billName = this.props.client.name }
        if (this.props.client.address.street) { billingAddress = this.props.client.address.street }
      }
      this.setState({billName: billName})
      this.setState({billingAddress: billingAddress})
    } else {
      this.setState({billName: 'name'})
      this.setState({billingAddress: 'address'})
      this.setState({displayDefault: true})
    }
  }

  handleConfirm() {
    let customerNameAddress = this.state.customerNameAddress
    let customerNameAddressArr = customerNameAddress.split('/')
    let clientId = ''
    let billType = 'client'

    this.setState({billName: customerNameAddressArr[0]})
    this.setState({billingAddress: customerNameAddressArr[1]})
    this.setState({displayDefault: false})

    customerIdNameAddressDataSource.map((data, index) => {
      if (data.text === customerNameAddress) {
        clientId = data.clientId
      }
    })

    let currentJobId = this.getNewAppointment() ? this.getNewAppointment().jobId : null
    if (currentJobId) {
      this.props.updateJob(currentJobId, {billToType: billType, billTo: clientId})
    }
  }

  onNewRequest(chosenRequest, index) {
    if (chosenRequest.text) {
      this.setState({customerNameAddress: chosenRequest.text})
    }
  }

  changeBillInfo() {
    let clientsInfo = this.props.clients
    let clientKeysArr = Object.keys(clientsInfo)
    let customerNameAddressDataSource = []
    clientKeysArr.map((key, index) => {
      if (clientsInfo[key]['name'] && clientsInfo[key]['address']['street']) {
        customerNameAddressDataSource.push(
          {
            text: clientsInfo[key]['name'] + '/' + clientsInfo[key]['address']['street'],
            value: (
              <MenuItem
                primaryText={clientsInfo[key]['name']}
                secondaryText={clientsInfo[key]['address']['street']}
              />
            )
          }
        )
        customerIdNameAddressDataSource.push(
          {
            clientId: key,
            text: clientsInfo[key]['name'] + '/' + clientsInfo[key]['address']['street'],
          }
        )
      }
    })
    this.props.showDialog({
      title: 'What is the customer name/address?',
      acceptCaption: 'Confirm',
      acceptCallback: this.handleConfirm,
      autoComplete: {
        hintText: 'search by customer name/address',
        dataSource: customerNameAddressDataSource,
        onNewRequest: this.onNewRequest,
        fullWidth: fullWidth,
      }
    })
  }

  renderSiteInformation() {
    const {
      appointments, caller, engineers,
      jobs, pathname, site, siteId
    } = this.props
    const address = site ? site.address : {}
    let newAppointmentType = 'N/A'
    appointmentTypes.map((type, index) => {
      if (type.value === this.getNewAppointment().type) {
        newAppointmentType = type.text
      }
    })
    return (
      <div>
        <Title>
          {site.name}
        </Title>
        <div>
          <Body style={styles.body}>
            {address.street}
            <br />
            {address.city + ', ' + address.state + ' ' + formatZipCode(address.zip)}
          </Body>
        </div>
        <SiteDetailsItem
          secondaryText="Site Contact"
          primaryText={site && site.contactName || 'N/A'}
        />
        <SiteDetailsItem
          secondaryText="Site Phone"
          primaryText={site && filterPhoneNumber.displayPhoneNumber(site.phoneNumber) || 'N/A'}
        />
        <SiteDetailsItem
          primaryText={
            <div>
              <div>{this.props.client ? this.props.client.salesperson : 'N/A'}</div>
              <div style={styles.salespersonNumber}>
                {this.props.client ? this.props.client.number : 'N/A'}
              </div>
            </div>
          }
          secondaryText="Salesperson"
        />
        <Divider style={styles.dividerNoMargin}/>
        <div>
          <Card style={styles.infoStyle}>
            <CardHeader
            title="Customer Name"
            subtitle={this.props.client ? this.props.client.name : 'N/A'}
            titleStyle={styles.titleStyle}
            style={styles.headerStyle}
            subtitleStyle={styles.subtitleStyle}
            textStyle={styles.textStyle}
            actAsExpander={actAsExpander}
            showExpandableButton={showExpandableButton}
          />
          <CardText style={styles.cardText} expandable={expandable}>
            <SiteDetailsItem
              secondaryText="Customer Address"
              primaryText={this.props.client ? this.props.client.address.street +
               ', ' + this.props.client.address.city + ', ' + this.props.client.address.state +
                ', ' + this.props.client.address.zip : 'N/A'}
            />
            <SiteDetailsItem
              secondaryText="Contact Info"
              primaryText={this.props.client ?
                filterPhoneNumber.displayPhoneNumber(this.props.client.phoneNumber) : 'N/A'}
            />
          </CardText>
          </Card>
        </div>
        <Divider style={styles.divider}/>
        { this.props.appointmentTypeInfo ?

            <div>
              <SiteDetailsBillToItem
                secondaryText="Appointment Type"
                selectBillingType={this.selectBillingType}
                appointmentType={newAppointmentType ? newAppointmentType : 'N/A'}
              />
              <Divider style={styles.divider}/>
              <Card style={styles.infoStyle}>
                { newAppointmentType === 'TM – Time & Material' && this.state.displayDefault ?
                    <CardHeader
                      title="Bill Name"
                      titleStyle={styles.titleStyle}
                      subtitle={this.getbillName() ? this.getbillName() : 'N/A'}
                      subtitleStyle={styles.subtitleStyle}
                      textStyle={styles.textStyle}
                      style={styles.headerStyle}
                      actAsExpander={actAsExpander}
                      showExpandableButton={showExpandableButton}
                    /> :
                    <CardHeader
                      title="Bill Name"
                      titleStyle={styles.titleStyle}
                      subtitle={this.state.billName === 'name' ? 'N/A' : this.state.billName}
                      subtitleStyle={styles.subtitleStyle}
                      textStyle={styles.textStyle}
                      style={styles.headerStyle}
                      actAsExpander={actAsExpander}
                      showExpandableButton={showExpandableButton}
                    />
                }
                { newAppointmentType === 'TM – Time & Material' && this.state.displayDefault ?
                    <CardText style={styles.cardText} expandable={expandable}>
                      <SiteDetailsItem
                        secondaryText="Billing Address"
                        primaryText={this.getbillAddress() ? this.getbillAddress() : 'N/A'}
                      />
                      <RaisedButton
                        label="Change"
                        secondary
                        disabled={this.getNewAppointment().type !== 'TM'}
                        onClick={this.changeBillInfo} />
                    </CardText> :
                    <CardText style={styles.cardText} expandable={expandable}>
                      <SiteDetailsItem
                        secondaryText="Billing Address"
                        primaryText={this.state.billingAddress === 'address' ? 'N/A' : this.state.billingAddress}
                      />
                      <RaisedButton
                        label="Change"
                        secondary
                        disabled={this.getNewAppointment().type !== 'TM'}
                        onClick={this.changeBillInfo} />
                    </CardText>
                  }
              </Card>
            </div> : null
        }
        {caller &&
          <div>
            <Divider style={styles.divider}/>
            <SiteDetailsItem
              primaryText={caller && caller.name || ''}
              secondaryText="Caller Name"
              autoHide={1}
            />
            <SiteDetailsItem
              primaryText={caller && filterPhoneNumber.displayPhoneNumber(caller.phone) || ''}
              secondaryText="Caller Phone"
              autoHide={1}
            />
          </div>
        }
        {
          pathname === '/enterAppointment' ?
          <div>
            <Divider style={styles.divider}/>
            <Caption style={styles.siteHistory}>Site History</Caption>
            { Object.keys(jobs).map((jobId) => {
              const job = jobs[jobId]
              const appointmentIds = job && job.appointments

              return job && job.siteId === siteId ? (
                <Card style={styles.historyCard} key={jobId}>
                  <CardHeader
                    style={styles.expandableHeader}
                    title={job.legacyId || 'Pending'}
                    actAsExpander
                    showExpandableButton
                  />
                  <CardText expandable style={styles.expandableText}>
                    <List>
                      <StaticListItem
                        primaryText={job.type || 'Call Type'}
                        secondaryText="Type of Call"
                      />
                      { Object.keys(appointmentIds).map((appointmentId, index) => {
                        const appointment = appointments[appointmentId]

                        return appointment ? (
                          <div key={appointmentId}>
                            { index === 0 ? (
                              <div>
                                <Subheading>Appointments</Subheading>
                                <Divider/>
                              </div>
                            ) : <Divider/> }
                            <StaticListItem
                              primaryText={appointment.legacyId || 'Pending'}
                              secondaryText="Service Call ID"
                            />
                            <StaticListItem
                              primaryText={appointment.status || 'Appointment Status'}
                              secondaryText="Status of Appointment"
                            />
                            <StaticListItem
                              primaryText={appointment.type || 'Type of Problem'}
                              secondaryText="Type of Problem"
                            />
                            <StaticListItem
                              primaryText={appointment.serviceDescription || 'Service Description'}
                              secondaryText="Service Description"
                            />
                          </div>
                        ) : null
                      })}
                    </List>
                  </CardText>
                </Card>
              ) : null
            })}
          </div> : null
        }
        {
          site.notes && Object.keys(site.notes).length ?
          <div>
            <Divider style={styles.divider}/>
            <Caption style={styles.siteHistory}>Past Engineer Notes</Caption>
            { site.notes ? Object.keys(site.notes).map(noteId => {
              const note = site.notes[noteId]
              const engineer = engineers[note.authorId]
              const engineerName = engineer && engineer.firstName + ' ' +
                engineer.lastName + ' (' + engineer.legacyId + ')'

              return (
                <Card style={styles.historyCard} key={noteId}>
                  <CardHeader
                    style={styles.expandableHeader}
                    title={note.writtenAt ?
                      moment(note.writtenAt).format('MM/DD/YYYY') :
                      '10/01/2016'
                    }
                    actAsExpander
                    showExpandableButton
                  />
                  <CardText expandable style={styles.expandableText}>
                    <StaticListItem
                      primaryText={note.content || 'Replaced pump under warranty'}
                      secondaryText={engineerName || ''}
                    />
                  </CardText>
                </Card>
              )
            }) : null
            }
          </div> : null
        }
      </div>
    )
  }

  renderLoading() {
    return (
      <div>
        <CircularProgress style={styles.progress} size={0.5}/>
      </div>
    )
  }

  render() {
    return (
      <div style={styles.sideBar}>
        {
          this.props.site ? this.renderSiteInformation() : this.renderLoading()
        }
      </div>
    )
  }
}

const styles = {
  divider: {
    height: 1,
    marginTop: 30,
    marginBottom: 30,
  },
  dividerNoMargin: {
    marginTop: 0
  },
  expandableHeader: {
    paddingTop: 0,
    paddingLeft: 0,
    paddingRight: 0,
    marginTop: -10,
    fontWeight: 400,
  },
  expandableText: {
    paddingTop: 5,
    paddingLeft: 0,
    paddingRight: 0,
  },
  historyCard: {
    backgroundColor: 'transparent',
    marginBottom: 20,
    boxShadow: 0,
    zDepth: 0,
  },
  notesDetail: {
    fontSize: 15,
    lineHeight: '26px',
  },
  sideBar: {
    padding: 32,
    paddingTop: 55,
  },
  siteHistory: {
    marginBottom: 16,
    textTransform: 'initial',
  },
  infoStyle: {
    backgroundColor: '#EEEEEE',
    boxShadow: 'rgba(0, 0, 0, 0)'
  },
  titleStyle: {
    color: 'rgb(117, 117, 117)',
    fontSize: '12px'
  },
  textStyle: {
    paddingRight: 0,
    paddingTop: 20
  },
  headerStyle: {
    padding: 0,
    display: 'flex'
  },
  cardText: {
    padding: 0
  },
  subtitleStyle: {
    fontWeight: 400,
    color: 'rgb(0, 0, 0)'
  },
  salespersonNumber: {
    fontSize: '12px',
    color: '#030303'
  }
}

const mapStateToProps = (state) => {
  return {
    clients: state.clients,
    routeParams: state.routeParams,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    startListeningToClients: () => dispatch(actions.startListeningToClients()),
    showDialog: (dialog) => dispatch(actions.showDialog(dialog)),
    updateAppointment: (appointmentId, appointment) => dispatch(
      actions.updateAppointment(appointmentId, appointment)
    ),
    updateJob: (jobId, job) => dispatch(actions.updateJob(jobId, job)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ClientInformation)
