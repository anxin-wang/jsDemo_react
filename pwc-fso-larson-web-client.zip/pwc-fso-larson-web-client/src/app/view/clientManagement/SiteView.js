import React, { Component, } from 'react'
import { FlatButton, } from 'material-ui'
import { connect, } from 'react-redux'
import actions from '../../actions'
import AppointmentCard from '../appointmentManagement/AppointmentCard'
import ClientInformation from './ClientInformation'
import ContentAdd from 'material-ui/svg-icons/content/add'
import FloatingActionButton from 'material-ui/FloatingActionButton'
import store from '../../store'
import Subheading from '../../ui/typography/Subheading'
import Theme from '../../theme/Theme.js'
import { Grid, Cell } from 'react-mdl'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'

class SiteView extends Component {
  constructor(props, context) {
    super(props, context)
    this.handleCreateAppointment = this.handleCreateAppointment.bind(this)
    this.selectAppointment = this.selectAppointment.bind(this)
  }

  handleCreateAppointment(jobId) {
    store.dispatch(actions.routeTo(
      'enterAppointment',
      {
        jobId: jobId,
        siteId: this.getSiteId(),
      }
    ))
  }

  getSiteId() {
    return this.props.routeParams.siteId
  }
  componentWillMount() {
    this.props.getJobsBySiteId(this.getSiteId())
  }

  componentWillUpdate() {
    const site = this.props.sites[this.getSiteId()]
    if (!site) {
      firebaseCacheService.prioritize(
        'sites',
        this.getSiteId()
      )
    }
  }

  selectAppointment(appointmentId) {
    store.dispatch(actions.routeTo(
      'appointment',
      {
        appointmentId,
      }
    ))
  }

  render() {
    const { appointments, engineers, jobs, location, appointmentIndexes } = this.props
    const siteId = this.getSiteId()
    const site = this.props.sites[siteId]
    const client = site ? this.props.clients[site.clientId] : {}
    let siteHasJobs = false
    return (
      <Grid>
        <FloatingActionButton
          style={styles.fab}
          secondary
          onClick={() => { this.handleCreateAppointment(null) }}
        >
          <ContentAdd />
        </FloatingActionButton>
        <Cell col={9}>
          <div style={styles.siteHistory}>
            {
              jobs && Object.keys(jobs).map((jobId) => {
                const job = jobs[jobId]
                return job && job.siteId === siteId && job.status !== 'CLOSED' &&
                job.appointments && Object.keys(job.appointments).length ? (
                  <div key={jobId} style={styles.unassignedAppointments}>
                    <div style={styles.appointmentListHeader}>
                      <Subheading
                        style={styles.appointmentIdHeading}>
                        { job.legacyId ? 'Call ' + job.legacyId : 'Pending' }
                      </Subheading>
                      <FlatButton
                        label="Add Appointment to Call"
                        icon={<ContentAdd />}
                        onClick={() => { this.handleCreateAppointment(jobId) }}
                        primary
                        style={styles.createNewAppointment}
                      />
                    </div>
                    {
                      job.appointments && Object.keys(jobs[jobId].appointments).map((appointmentId) => {
                        let appointment = appointments[appointmentId]
                        let appointmentIndex = appointmentIndexes[appointmentId]
                        appointment ? (siteHasJobs = true) : null
                        return appointment && appointment.status !== 'COMPLETED' && appointmentIndex ? (
                          <AppointmentCard
                            style={styles.appointmentCard}
                            appointmentId={appointmentId}
                            appointmentIndex={appointmentIndex}
                            engineer={engineers[appointment.assignedEngineer]}
                            job={job}
                            key={appointmentId}
                            selectAppointment={this.selectAppointment}
                            site={site}
                            shouldRender
                          />
                        ) : null
                      })
                    }
                  </div>
                ) : null
              })
            }
            { !siteHasJobs ? <img src={ '/images/empty-state.png' } style={styles.emptyState}/> : null }
          </div>
        </Cell>
        <Cell col={3}>
          <ClientInformation
            appointments={appointments}
            client={client}
            jobs={jobs}
            site={site}
            siteId={siteId}
            pathname={location.pathname}
            engineers={engineers}
          />
        </Cell>
      </Grid>
    )
  }
}

const styles = {
  appointmentListHeader: {
    overflow: 'hidden',
    marginTop: 25,
  },
  emptyState: {
    height: '58%',
    marginLeft: '17%',
    width: '58%',
  },
  appointmentIdHeading: {
    float: 'left',
  },
  createNewAppointment: {
    float: 'right',
    marginTop: 8,
    color: Theme.palette.textColorSoft,
    letterSpacing: 1,
    paddingRight: 0,
  },
  fab: {
    backgroundColor: Theme.palette.accent1Color,
    marginTop: 35,
    right: 306,
    position: 'fixed',
    zIndex: 1200,
  },
  header: {
    height: 120,
    paddingLeft: 64,
    position: 'relative',
    width: 'auto',
  },
  main: {
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
    width: 'auto',
    marginRight: 0,
  },
  sideBar: {
    backgroundColor: Theme.palette.sidebarBackground,
    float: 'right',
    height: 'auto',
    paddingTop: 24,
    paddingLeft: 24,
    position: 'relative',
    right: 0,
    width: 400,
    top: 0,
  },
  siteHistory: {
    marginTop: 100,
  },
  wrapper: {
    display: 'flex',
    flexDirection: 'row',
    marginLeft: 64,
    position: 'relative',
    zIndex: 0,
  },
}

const mapStateToProps = (state) => {
  return {
    appointmentIndexes: state.appointmentIndexes,
    appointments: state.appointments,
    clients: state.clients,
    engineers: state.engineers,
    jobs: state.jobs,
    routeParams: state.routeParams,
    sites: state.sites,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    getJobsBySiteId: (siteId) => dispatch(actions.getJobsBySiteId(siteId)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SiteView)
