import React, { Component, } from 'react'
import { connect, } from 'react-redux'
import { withRouter, } from 'react-router'
import withWidth from 'material-ui/utils/withWidth'
import RaisedButton from 'material-ui/RaisedButton'
import Title from '../../ui/typography/Title'
import actions from '../../actions'

class LoginView extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      error: false,
      errorMessage: '',
    }
  }

  render() {
    return (
      <div style={styles.wrapper}>
        <Title style={styles.title}>Welcome! Sign in:</Title>
        <div>
          <RaisedButton label="Sign in with Google" primary onTouchTap={this.props.attemptLogin} /><br/><br/>
          <br/>
          <h3 className="errorMessage">{this.state.errorMessage}</h3>
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return { auth: state.auth, }
}

const mapDispatchToProps = (dispatch) => {
  return {
    attemptLogin: () => dispatch(actions.attemptLogin()),
  }
}

const styles = {
  title: {
    paddingTop: 100,
    textTransform: 'initial',
  },
  wrapper: {
    marginTop: -16,
    paddingLeft: 30,
  },
}

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withWidth()(LoginView)))
