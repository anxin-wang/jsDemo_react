import React, { Component, } from 'react'
import RaisedButton from 'material-ui/RaisedButton'
import { connect, } from 'react-redux'
import actions from '../../actions'

class LogoutView extends Component {
  render() {
    return (
      <div>
        <RaisedButton
          label="Sign Out"
          style={styles.button}
          primary onTouchTap={this.props.logout}
        />
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return { auth: state.auth, }
}

const mapDispatchToProps = (dispatch) => {
  return {
    logout: () => dispatch(actions.logout()),
  }
}

const styles = {
  button: {
    marginLeft: 30,
    marginRight: 100,
    marginTop: 95,
  },
}

export default connect(mapStateToProps, mapDispatchToProps)(LogoutView)
