import React, { Component } from 'react'
import { AutoComplete, Card, CardHeader,
  Checkbox, IconButton, MenuItem } from 'material-ui'
import Search from 'material-ui/svg-icons/action/search'
import StaticListItem from '../../ui/global/StaticListItem'
import PartResult from './PartResult'
import _ from 'lodash'

class RecommendedParts extends Component {
  constructor(props, context) {
    super(props, context)

    this.handleAddPart = this.handleAddPart.bind(this)
    this.handlePartSearch = this.handlePartSearch.bind(this)
    this.handlePartSelect = this.handlePartSelect.bind(this)
    this.isPartSelected = this.isPartSelected.bind(this)
  }

  handleAddPart(selected, index, issue) {
    const partId = Object.keys(this.props.partSearch.results || {})[index]
    if (!issue.selectedParts || !issue.selectedParts[partId]) {
      this.handlePartSelect(partId, this.props.issueId)
    }
    this.props.searchForPart('', this.props.issueId)
  }

  handlePartSearch(searchText) {
    this.props.searchForPart(searchText, this.props.issueId)
  }

  handlePartSearchEnter(event) {
    if (event.keyCode === 13) {
      event.preventDefault()
      event.target.blur()
    }
  }

  handlePartSelect(partId, issueId) {
    this.props.togglePart(partId, issueId)
  }

  isPartSelected(partId, issue) {
    return issue.selectedParts && issue.selectedParts[partId]
  }

  findRecommendedPart(recommendedPart, parts) {
    let selectedPartIndex = parts.findIndex((part) => {
      return part.number === recommendedPart.partNumber
    })

    return parts[selectedPartIndex]
  }

  shouldComponentUpdate(nextProps, nextState) {
    const response = (
      JSON.stringify(this.props.parts) !== JSON.stringify(nextProps.parts) ||
      JSON.stringify(this.props.issue.selectedParts) !== JSON.stringify(nextProps.issue.selectedParts) ||
      JSON.stringify(this.props.recommendedParts) !== JSON.stringify(nextProps.recommendedParts)
    )
    return response
  }

  renderPartsSearch(searchResult) {
    //let searchResult = this.props.partSearch.results
    return Object.keys(searchResult).map(key => {
      let part = searchResult[key]
      return {
        text: part.number,
        value: (
          <MenuItem>
            <PartResult
              part={part}
            />
          </MenuItem>
        )
      }
    })
  }

  render() {
    const issue = this.props.issue
    const issueId = this.props.issueId
    const parts = this.props.parts
    const recommendedParts = this.props.recommendedParts || {}
    const selectedParts = issue.selectedParts || {}
    const partsToDisplay = _.union(Object.keys(recommendedParts), Object.keys(selectedParts))
    const term = this.props.partSearch.issueId === this.props.issueId ? this.props.partSearch.term : ''

    return (
      <div>
        <CardHeader
          title={'Suggest recommended parts'}
        />
        { partsToDisplay.map((partId, index) => {
          const part = parts[partId]
          return part ? (
            <Checkbox
              label={
                <div>
                  <StaticListItem
                    primaryText={part.name}
                    secondaryText={part.number}
                  />
                </div>
              }
              iconStyle={styles.checkboxIcon}
              labelPosition="left"
              onCheck={() => { this.handlePartSelect(partId, issueId)}}
              style={styles.checkbox}
              defaultChecked={this.isPartSelected(partId, issue) || false}
              key={index}
            />
          ) : null
        })}
        <Card style={styles.searchPartWrapper}>
          <IconButton
            tooltip="search"
            style={styles.searchIcon}
          >
            <Search />
          </IconButton>
          <AutoComplete
            anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
            targetOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            dataSource={this.renderPartsSearch(this.props.partSearch.results)}
            filter={AutoComplete.noFilter}
            hintText="Add a part not suggested here"
            listStyle={styles.autoComplete}
            name="partSearch"
            onKeyDown={this.handlePartSearchEnter}
            onNewRequest={(selected, index) => this.handleAddPart(selected, index, issue)}
            onUpdateInput={this.handlePartSearch}
            searchText={term}
            style={styles.searchPartInput}
            underlineShow={false}
            textFieldStyle={styles.textField}
          />
        </Card>
      </div>
    )
  }
}

const styles = {
  autoComplete: {
    width: 502,
  },
  checkboxIcon: {
    paddingTop: 7,
  },
  searchIcon: {
    float: 'left',
    paddingLeft: 10,
    paddingTop: 12,
  },
  searchPartInput: {
    paddingLeft: 10,
  },
  searchPartWrapper: {
    margin: 20,
  },
  textField: {
    width: 500,
  },
}

export default RecommendedParts
