import React, {Component, } from 'react'
import {connect, } from 'react-redux'
import {
  AutoComplete, Card, CardHeader, Checkbox, FlatButton,
  IconButton, Paper, TextField
} from 'material-ui'
import actions from '../../actions'
import AddCircle from 'material-ui/svg-icons/content/add-circle'
import Issue from './Issue'
import Caption from '../../ui/typography/Caption'
import ClientInformation from '../clientManagement/ClientInformation'
import ContentAdd from 'material-ui/svg-icons/content/add'
import EquipmentWarranty from './EquipmentWarranty'
import filterPhoneNumber from '../../filters/phoneNumber'
import HardwareTv from 'material-ui/svg-icons/hardware/tv'
import MapsLocalGasStation from 'material-ui/svg-icons/maps/local-gas-station'
import MapsLocalPrintshop from 'material-ui/svg-icons/maps/local-printshop'
import RecommendedParts from './RecommendedParts'
import {renderEquipmentSearch} from '../callManagement/EquipmentResult'
import Search from 'material-ui/svg-icons/action/search'
import StaticListItem from '../../ui/global/StaticListItem'
import store from '../../store'
import A from '../../const/actionTypes'
import Subheading from '../../ui/typography/Subheading'
import Theme from '../../theme/Theme.js'
import issueTypes from '../../const/issueTypes'
import {Grid, Cell} from 'react-mdl'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'

class EnterAppointmentView extends Component {
  constructor(props, context) {
    super(props, context)

    this.handleAddAnotherIssue = this.handleAddAnotherIssue.bind(this)
    this.handleAddEquipment = this.handleAddEquipment.bind(this)
    this.handleEquipmentSelect = this.handleEquipmentSelect.bind(this)
    this.handleEquipmentSearch = this.handleEquipmentSearch.bind(this)
    this.isEquipmentAdded = this.isEquipmentAdded.bind(this)
    this.onCallerNameChange = this.onCallerNameChange.bind(this)
    this.onCallerPhoneNumberChange = this.onCallerPhoneNumberChange.bind(this)
    this.onProblemChange = this.onProblemChange.bind(this)
    this.onAppointmentDescriptionChange = this.onAppointmentDescriptionChange.bind(this)
    this.setAuthenticated = this.setAuthenticated.bind(this)
    this.state = {
      firebaseData: [],
    }
  }

  componentWillMount() {
    store.dispatch({
      type: A.INIT_NEW_ISSUE,
    })
    store.dispatch({
      type: A.INIT_ALL_APPOINTMENT_TEXT_FIELDS,
    })
  }

  componentWillUpdate() {
    const site = this.props.sites[this.getSiteId()]
    if (!site) {
      firebaseCacheService.prioritize(
        'sites',
        this.getSiteId()
      )
    }
    const job = this.props.jobs[this.getJobId()]
    if (!job && this.getJobId()) {
      firebaseCacheService.prioritize(
        'jobs',
        this.getJobId()
      )
    }
    const appointment = this.props.appointments[this.getAppointmentId()]
    if (!appointment && this.getAppointmentId()) {
      firebaseCacheService.prioritize(
        'appointments',
        this.getAppointmentId(),
        'dispatcherApp/'
      )
    }
    this.checkIfReadyToReview()
  }

  getSiteId() {
    return this.props.routeParams.siteId
  }

  getJobId() {
    return this.props.routeParams.jobId
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  componentWillUnmount() {
    this.props.hideSnackbar()
  }

  handleEquipmentSearch(searchText) {
    this.props.searchForEquipment(searchText, this.getNewIssue().id)
  }

  handleAddAnotherIssue() {
    this.props.createNewIssue()
    this.refs.newIssueDetails.getInputNode().value = ''
  }

  handleAddEquipment(chosenRequest, index) {
    const results = this.props.equipmentSearch.results || {}
    const equipmentId = Object.keys(results)[index]
    equipmentId && this.handleEquipmentSelect(equipmentId)
    this.props.searchForEquipment('', this.props.newIssue)
  }

  handleEquipmentSearchEnter(event) {
    if (event.keyCode === 13) {
      event.preventDefault()
      event.target.blur()
    }
  }

  hasProblem() {
    return Object.keys(this.getNewAppointment().issues || {})
        .findIndex((issueId) => this.props.issues[issueId] && Boolean(this.props.issues[issueId].description)) >= 0
  }

  hasIssueType() {
    return Object.keys(this.getNewAppointment().issues || {})
        .findIndex((issueId) => this.props.issues[issueId] && Boolean(this.props.issues[issueId].type)) >= 0
  }

  hasCallerInfo() {
    return Boolean(this.getNewAppointment().callerName) && Boolean(this.getNewAppointment().callerPhoneNumber)
  }

  checkIfReadyToReview() {
    if (
      this.hasProblem() &&
      this.hasIssueType() &&
      this.hasCallerInfo() && !this.props.snackbar.open
    ) {
      this.props.showSnackbar({
        message: 'Next: Review this appointment',
        action: 'Review',
        onActionTouchTap: this.props.reviewAppointment,
        sticky: true,
      })
    }
    if (
      (
        !this.hasProblem() || !this.hasIssueType() || !this.hasCallerInfo()
      ) &&
      this.props.snackbar.open
    ) {
      this.props.hideSnackbar()
    }
  }

  handleEquipmentSelect(equipmentId) {
    this.props.toggleEquipment(
      equipmentId,
      this.getNewIssue(),
      this.props.newIssue
    )
  }

  isEquipmentAdded(equipmentId) {
    return Boolean(this.getNewIssue().equipment && this.getNewIssue().equipment[equipmentId])
  }

  onCallerNameChange(event) {
    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        callerName: event.target.value
      }
    )
  }

  onCallerPhoneNumberChange(event) {
    let phoneNumber = event.target.value.replace(/\D/g, '')

    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        callerPhoneNumber: phoneNumber,
      }
    )
  }

  onAppointmentDescriptionChange(event) {
    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        appointmentDescription: event.target.value
      }
    )
  }

  onUpdateCallerPhoneNumberFieldChange(event) {
    let phoneNumber = event.target.value.replace(/\D/g, '')
    this.props.updateAppointmentPhoneNumberField(phoneNumber)
  }

  onUpdateAppointmentDescriptionFieldChange(event) {
    this.props.updateAppointmentDescriptionField(event.target.value)
  }

  onUpdateAppointmentCallerNameFieldChange(event) {
    this.props.updateAppointmentCallerNameField(event.target.value)
  }

  onUpdateAppointmentIssueDescriptionFieldChange(event) {
    this.props.updateAppointmentIssueDescriptionField(event.target.value)
  }

  onProblemChange(event) {
    if (this.updateTimeout) {
      clearTimeout(this.updateTimeout)
    }
    let description = event.target.value

    this.updateTimeout = setTimeout(
      () => {
        this.props.updateNewIssue(
          this.props.newIssue,
          {
            description,
          }
        )
      }, 960
    )
  }

  onSelectIssueType(type) {
    this.props.updateNewIssue(
      this.props.newIssue,
      {
        type,
      }
    )
  }

  setAuthenticated(googleAuthenticated) {
    this.state.authenticated = googleAuthenticated
    this.setState({authenticated: this.state.authenticated, })
  }

  setFirebaseResults(firebaseResults) {
    for (let i = 0; i < firebaseResults.length; i++) {
      this.state.firebaseData.push(firebaseResults[i])
    }

    this.setState({
      firebaseData: this.state.firebaseData,
    })
  }

  getIconStyle(issueType) {
    return this.getNewIssue().type === issueType ? styles.selectedIcon : null
  }

  findEquipment(equipmentId) {
    return this.props.equipment.find((equipment) => equipment.id === equipmentId)
  }

  getNewIssue() {
    return this.props.newIssue ? this.props.issues[this.props.newIssue] || {} : {}
  }

  getNewAppointment() {
    return this.getAppointmentId() ?
    this.props.appointments[this.getAppointmentId()] || {} : {}
  }

  render() {
    let newIssue = this.getNewIssue()
    const {appointments, jobs, location, engineers} = this.props
    const siteId = this.getSiteId()
    const site = this.props.sites[siteId]
    const client = site ? this.props.clients[site.clientId] : {}
    const equipmentIds = Object.assign({}, site ? site.equipment : null, newIssue.equipment)
    const term = this.props.equipmentSearch.issueId === this.props.newIssue ? this.props.equipmentSearch.term : ''

    return (
      <Grid>
        <Cell col={9} style={styles.main}>
          <Subheading style={styles.title}>Who are you speaking with?</Subheading>
          <Paper style={styles.paper}>
            <TextField
              floatingLabelText="Caller name"
              onBlur={this.onCallerNameChange}
              onChange={this.onUpdateAppointmentCallerNameFieldChange.bind(this)}
              value={this.props.appointmentTextFields.appointmentCallerNameField ||
                this.getNewAppointment().callerName || ''}
            />
            <TextField
              floatingLabelText="Caller phone number"
              onBlur={this.onCallerPhoneNumberChange}
              onChange={this.onUpdateCallerPhoneNumberFieldChange.bind(this)}
              value={ filterPhoneNumber.formatPhoneNumber(
                this.props.appointmentTextFields.appointmentPhoneNumberField) ||
              filterPhoneNumber.formatPhoneNumber(this.getNewAppointment().callerPhoneNumber)}
              style={styles.callerPhoneNumber}
            />
          </Paper>
          {
            newIssue.type ? (
              <FlatButton
                label="Add Another Issue"
                icon={<AddCircle style={styles.addCircle}/>}
                onClick={this.handleAddAnotherIssue}
                primary
                style={styles.createNewIssue}
              />
            ) : null
          }
          <Subheading style={styles.issuePrompt}>Describe the issue:</Subheading>
          <Paper style={styles.paper}>
            <TextField
              floatingLabelText="Details and notes"
              fullWidth
              multiLine
              onBlur={this.onProblemChange}
              onChange={this.onUpdateAppointmentIssueDescriptionFieldChange.bind(this)}
              value={this.props.appointmentTextFields.appointmentIssueDescriptionField || ''}
              ref="newIssueDetails"
            />
          </Paper>
          <Paper style={styles.paper}>
            <Caption style={styles.caption}>Type of issue</Caption>
            <div style={styles.issueTypes}>
              <IconButton
                iconStyle={ this.getIconStyle(issueTypes['VER']) }
                onClick={() => this.onSelectIssueType(issueTypes['VER'])}
                tooltip="POS"
              >
                <HardwareTv />
              </IconButton>
              <IconButton
                iconStyle={ this.getIconStyle(issueTypes.PR) }
                onClick={() => this.onSelectIssueType(issueTypes.PR)}
                tooltip="Printer"
              >
                <MapsLocalPrintshop />
              </IconButton>
              <IconButton
                iconStyle={ this.getIconStyle(issueTypes.PD) }
                onClick={() => this.onSelectIssueType(issueTypes.PD)}
                tooltip="Pump"
              >
                <MapsLocalGasStation />
              </IconButton>
              <IconButton
                iconStyle={ this.getIconStyle(issueTypes.OT) }
                onClick={() => this.onSelectIssueType(issueTypes.OT)}
                tooltip="Other issue"
              >
                <ContentAdd />
              </IconButton>
            </div>
          </Paper>
          {
            newIssue.type ? (
              <Card style={styles.equipmentCard}>
                <CardHeader
                  title={'Confirm Equipment'}
                  subtitle={'Suggested equipment based on site data'}
                />
                { Object.keys(equipmentIds).map(equipmentId => {
                  let equipment = this.props.equipment[equipmentId]

                  return (
                    <Checkbox
                      label={
                        <div>
                          <StaticListItem
                            primaryText={equipment.name}
                            secondaryText={'Model: ' + equipment.modelNumber +
                            ' Manufacturer: ' + equipment.manufacturer}
                          />
                          <div style={styles.equipmentWarranty}>
                            <EquipmentWarranty
                              equipment={equipment}
                            />
                          </div>
                        </div>
                      }
                      iconStyle={styles.checkboxIcon}
                      labelPosition="left"
                      onCheck={() => {
                        this.handleEquipmentSelect(equipmentId)
                      }}
                      style={styles.checkbox}
                      defaultChecked={this.isEquipmentAdded(equipmentId)}
                      key={equipmentId}
                    />
                  )
                })}
                <Card style={styles.searchEquipmentWrapper}>
                  <IconButton
                    tooltip="search"
                    style={styles.searchIcon}
                  >
                    <Search />
                  </IconButton>
                  <AutoComplete
                    searchText={term}
                    dataSource={renderEquipmentSearch(this.props.equipmentSearch.results)}
                    hintText="Search equipment"
                    name="equipmentSearch"
                    filter={AutoComplete.noFilter}
                    onKeyDown={this.handleEquipmentSearchEnter}
                    onUpdateInput={this.handleEquipmentSearch}
                    onNewRequest={this.handleAddEquipment}
                    style={styles.searchEquipmentInput}
                    underlineShow={false}
                    listStyle={styles.autoComplete}
                    textFieldStyle={styles.textField}
                  />
                </Card>
              </Card>
            ) : null
          }
          {
            (
              newIssue.recommendedParts &&
              newIssue.type &&
              newIssue.description
            ) ? (
              <Card style={styles.recommendedPartsCard}>
                <RecommendedParts
                  issue={newIssue}
                  issueId={this.props.newIssue}
                  parts={this.props.parts}
                  partSearch={this.props.partSearch}
                  recommendedParts={newIssue.recommendedParts}
                  searchForPart={this.props.searchForPart}
                  togglePart={this.props.togglePart}
                />
              </Card>
            ) : null
          }
          { this.getNewAppointment().issues ? (
            <div>
              { Object.keys(this.getNewAppointment().issues).map((issueId) => {
                const issue = this.props.issues[issueId]
                return issueId !== this.props.newIssue ? (
                  <Issue
                    issue={issue}
                    issueId={issueId}
                    equipment={this.props.equipment}
                    equipmentSearch={this.props.equipmentSearch}
                    key={issueId}
                    parts={this.props.parts}
                    partSearch={this.props.partSearch}
                    recommendedParts={[]}
                    searchForEquipment={this.props.searchForEquipment}
                    searchForPart={this.props.searchForPart}
                    site={this.props.sites[this.getSiteId()]}
                    toggleEquipment={this.props.toggleEquipment}
                    togglePart={this.props.togglePart}
                    updateNewIssue={this.props.updateNewIssue}
                  />
                ) : null
              })}
            </div>
          ) : null }
          <Subheading style={styles.title}>Describe the appointment:</Subheading>
          <Paper style={styles.paper}>
            <TextField
              floatingLabelText="Appointment description"
              fullWidth
              multiLine
              onChange={this.onUpdateAppointmentDescriptionFieldChange.bind(this)}
              onBlur={this.onAppointmentDescriptionChange.bind(this)}
              value={this.props.appointmentTextFields.appointmentDescriptionField ||
                this.getNewAppointment().appointmentDescription || ''}
            />
          </Paper>
        </Cell>
        <Cell col={3}>
          <ClientInformation
            appointments={appointments}
            client={client}
            jobs={jobs}
            site={site}
            siteId={siteId}
            pathname={location.pathname}
            engineers={engineers}
          />
        </Cell>
      </Grid>
    )
  }
}

const styles = {
  addCircle: {
    marginLeft: 0,
  },
  autoComplete: {
    width: 502,
  },
  callerPhoneNumber: {
    marginLeft: 40,
  },
  caption: {
    paddingTop: 10,
  },
  checkboxIcon: {
    paddingTop: 7,
  },
  createNewIssue: {
    marginBottom: 5,
    marginTop: 5,
    width: 210,
  },
  equipmentCard: {
    paddingBottom: 5,
    display: 'none',
  },
  equipmentWarranty: {
    marginTop: -12,
  },
  issuePrompt: {
    marginBottom: 14,
    textTransform: 'initial',
  },
  issueTypes: {
    marginLeft: -8,
  },
  main: {
    display: 'flex',
    flexDirection: 'column',
    marginTop: 70,
    paddingRight: 40,
  },
  paper: {
    marginBottom: 16,
    padding: 16,
    paddingTop: 4,
  },
  recommendedPartsCard: {
    marginBottom: 100,
    marginTop: 15,
    paddingBottom: 5,
  },
  searchEquipmentInput: {
    paddingLeft: 10,
  },
  searchEquipmentWrapper: {
    margin: 20,
    marginTop: 4,
  },
  searchIcon: {
    float: 'left',
    paddingLeft: 10,
    paddingTop: 12,
  },
  selectedIcon: {
    color: Theme.palette.pickerHeaderColor,
  },
  textField: {},
  title: {
    marginTop: 24,
    textTransform: 'initial',
  },
  displayNone: {
    display: 'none',
  },
}

const mapStateToProps = (state) => {
  return {
    appointments: state.appointments,
    clients: state.clients,
    engineers: state.engineers,
    equipment: state.equipment,
    equipmentSearch: state.equipmentSearch,
    issues: state.issues,
    jobs: state.jobs,
    newIssue: state.newIssue,
    parts: state.parts,
    partSearch: state.partSearch,
    routeParams: state.routeParams,
    sites: state.sites,
    snackbar: state.snackbar,
    appointmentTextFields: state.appointmentTextFields,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    createNewIssue: (issue) => dispatch(actions.createNewIssue(issue)),
    hideSnackbar: () => dispatch(actions.hideSnackbar()),
    reviewAppointment: () => dispatch(actions.reviewAppointment()),
    searchForEquipment: (term, issueId) => dispatch(actions.searchForEquipment(term, issueId)),
    searchForPart: (term, issueId) => dispatch(actions.searchForPart(term, issueId)),
    showSnackbar: (snackbar) => dispatch(actions.showSnackbar(snackbar)),
    toggleEquipment: (equipment, issue, issueId) => dispatch(actions.toggleEquipment(equipment, issue, issueId)),
    togglePart: (partId, issueId) => dispatch(actions.togglePart(partId, issueId)),
    updateNewIssue: (issueId, issue) => dispatch(actions.updateNewIssue(issueId, issue)),
    updateNewAppointment: (appointmentId, appointment) => dispatch(
      actions.updateNewAppointment(appointmentId, appointment)
    ),
    updateAppointmentDescriptionField: (description) => dispatch(
      actions.updateAppointmentDescriptionField(description)
    ),
    updateAppointmentPhoneNumberField: (phoneNumber) => dispatch(
      actions.updateAppointmentPhoneNumberField(phoneNumber)
    ),
    updateAppointmentCallerNameField: (callerName) => dispatch(
      actions.updateAppointmentCallerNameField(callerName)
    ),
    updateAppointmentIssueDescriptionField: (description) => dispatch(
      actions.updateAppointmentIssueDescriptionField(description)
    ),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(EnterAppointmentView)
