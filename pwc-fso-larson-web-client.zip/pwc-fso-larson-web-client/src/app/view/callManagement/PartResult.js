import React, { Component } from 'react'
import { ListItem } from 'material-ui'

class PartResult extends Component {
  render() {
    const part = this.props.part

    return (
      <div>
        <ListItem
          primaryText={part.name}
          secondaryText={part.number}
          disabled
        />
      </div>
    )
  }
}

export default PartResult
