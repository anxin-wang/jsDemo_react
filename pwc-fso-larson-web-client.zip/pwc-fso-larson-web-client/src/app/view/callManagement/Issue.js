import React, {Component} from 'react'
import {Card, CardHeader, Checkbox, IconButton, Paper, TextField, AutoComplete} from 'material-ui'
import Caption from '../../ui/typography/Caption'
import ContentAdd from 'material-ui/svg-icons/content/add'
import EquipmentWarranty from './EquipmentWarranty'
import HardwareTv from 'material-ui/svg-icons/hardware/tv'
import MapsLocalGasStation from 'material-ui/svg-icons/maps/local-gas-station'
import MapsLocalPrintshop from 'material-ui/svg-icons/maps/local-printshop'
import {renderEquipmentSearch} from '../callManagement/EquipmentResult'
import RecommendedParts from './RecommendedParts'
import Search from 'material-ui/svg-icons/action/search'
import StaticListItem from '../../ui/global/StaticListItem'
import Theme from '../../theme/Theme.js'
import issueTypes from '../../const/issueTypes'
import { Grid, Cell } from 'react-mdl'

class Issue extends Component {
  constructor(props, context) {
    super(props, context)

    this.handleAddEquipment = this.handleAddEquipment.bind(this)
    this.handleEquipmentSearch = this.handleEquipmentSearch.bind(this)
    this.handleEquipmentSelect = this.handleEquipmentSelect.bind(this)
    this.isEquipmentAdded = this.isEquipmentAdded.bind(this)
    this.onProblemChange = this.onProblemChange.bind(this)
  }

  handleEquipmentSearch(searchText) {
    this.props.searchForEquipment(searchText, this.props.issue.id)
  }

  handleAddEquipment(chosenRequest, index) {
    const results = this.props.equipmentSearch.results || {}
    const equipmentId = Object.keys(results)[index]
    equipmentId && this.handleEquipmentSelect(equipmentId)
    this.props.searchForEquipment('', this.props.issue.id)
  }

  isEquipmentAdded(equipmentId) {
    return Boolean(this.props.issue.equipment && this.props.issue.equipment[equipmentId])
  }

  handleEquipmentSearchEnter(event) {
    if (event.keyCode === 13) {
      event.preventDefault()
      event.target.blur()
    }
  }

  handleEquipmentSelect(equipmentId) {
    this.props.toggleEquipment(
      equipmentId,
      this.props.issue,
      this.props.issueId
    )
  }

  onProblemChange(event) {
    if (this.updateTimeout) {
      clearTimeout(this.updateTimeout)
    }
    let description = event.target.value
    this.updateTimeout = setTimeout(
      () => {
        this.props.updateNewIssue(
          this.props.issueId,
          {
            description,
          }
        )
      }, 960
    )
  }

  shouldComponentUpdate(nextProps, nextState) {
    const response = Boolean(this.props.issue) && (
        JSON.stringify(this.props.issue) !== JSON.stringify(nextProps.issue) ||
        JSON.stringify(this.props.parts) !== JSON.stringify(nextProps.parts) ||
        (
          JSON.stringify(this.props.equipmentSearch) !== JSON.stringify(nextProps.equipmentSearch) &&
          this.props.equipmentSearch.issueId === this.props.issue.id
        ) ||
        JSON.stringify(this.props.partSearch) !== JSON.stringify(nextProps.partSearch) ||
        this.selectedParts !== JSON.stringify(this.props.issue.selectedParts)
      )
    this.selectedParts = this.props.issue ? JSON.stringify(this.props.issue.selectedParts) : null
    return response
  }

  onSelectProblemType(type) {
    this.props.updateNewIssue(
      this.props.issueId,
      {
        type,
      }
    )
  }

  getIconStyle(
    problemType,
    issue
  ) {
    return issue.type === problemType ? styles.selectedIcon : null
  }

  render() {
    const issue = this.props.issue
    const equipmentIds = Object.assign(
      {},
      this.props.site ? this.props.site.equipment : {},
      issue ? issue.equipment : {}
    )
    const term = this.props.equipmentSearch.issueId === this.props.issueId ? this.props.equipmentSearch.term : ''

    return issue ? (
      <Grid style={styles.grid}>
        <Cell col={12} style={styles.main} key={issue.id}>
          <Paper style={styles.paper}>
            <TextField
              floatingLabelText="Details and notes"
              multiLine
              fullWidth
              defaultValue={issue.description}
              onChange={this.onProblemChange}
            />
            <div>
              <Caption style={styles.caption}>Type of problem</Caption>
              <div style={styles.problemTypes}>
                <IconButton
                  iconStyle={ this.getIconStyle(issueTypes['VER'], issue) }
                  onClick={() => this.onSelectProblemType(issueTypes['VER'])}
                  tooltip="POS"
                >
                  <HardwareTv />
                </IconButton>
                <IconButton
                  iconStyle={ this.getIconStyle(issueTypes.PR, issue) }
                  onClick={() => this.onSelectProblemType(issueTypes.PR)}
                  tooltip="Printer"
                >
                  <MapsLocalPrintshop />
                </IconButton>
                <IconButton
                  iconStyle={ this.getIconStyle(issueTypes.PD, issue) }
                  onClick={() => this.onSelectProblemType(issueTypes.PD)}
                  tooltip="Pump"
                >
                  <MapsLocalGasStation />
                </IconButton>
                <IconButton
                  iconStyle={ this.getIconStyle(issueTypes.OT, issue) }
                  onClick={() => this.onSelectProblemType(issueTypes.OT)}
                  tooltip="Other issue"
                >
                  <ContentAdd />
                </IconButton>
              </div>
            </div>
            {
              issue.type ? (
                <div style={styles.equipmentCard}>
                  <CardHeader style={styles.displayNone}
                    title={'Confirm Equipment'}
                    subtitle={'Suggested equipment based on site data'}
                  />
                  {
                    Object.keys(equipmentIds).map(equipmentId => {
                      let equipment = this.props.equipment[equipmentId]
                      return equipment ? (
                        <Checkbox
                          label={
                            <div>
                              <StaticListItem
                                primaryText={equipment.name}
                                secondaryText={'Model: ' + equipment.modelNumber +
                                ' Manufacturer: ' + equipment.manufacturer}
                              />
                              <div style={styles.equipmentWarranty}>
                                <EquipmentWarranty
                                  equipment={equipment}
                                />
                              </div>
                            </div>
                          }
                          iconStyle={styles.checkboxIcon}
                          key={equipmentId}
                          labelPosition="left"
                          onCheck={() => {
                            this.handleEquipmentSelect(equipmentId)
                          }}
                          defaultChecked={this.isEquipmentAdded(equipmentId)}
                          style={styles.checkbox}
                        />
                      ) : null
                    })
                  }
                  <Card style={styles.searchEquipmentWrapper}>
                    <IconButton
                      tooltip="search"
                      style={styles.searchIcon}
                    >
                      <Search />
                    </IconButton>
                    <AutoComplete
                      searchText={term}
                      dataSource={renderEquipmentSearch(this.props.equipmentSearch.results)}
                      hintText="Search equipment"
                      name="equipmentSearch"
                      filter={AutoComplete.noFilter}
                      onKeyDown={this.handleEquipmentSearchEnter}
                      onUpdateInput={this.handleEquipmentSearch}
                      onNewRequest={this.handleAddEquipment}
                      style={styles.searchEquipmentInput}
                      underlineShow={false}
                      listStyle={styles.autoComplete}
                      textFieldStyle={styles.textField}
                    />
                  </Card>
                </div>
              ) : null
            }
          </Paper>
          {
            (
              issue.recommendedParts &&
              issue.type &&
              issue.description
            ) ? (
              <Card style={styles.recommendedPartsCard}>
                <RecommendedParts
                  issue={this.props.issue}
                  issueId={this.props.issueId}
                  parts={this.props.parts}
                  partSearch={this.props.partSearch}
                  recommendedParts={issue.recommendedParts}
                  searchForPart={this.props.searchForPart}
                  togglePart={this.props.togglePart}
                />
              </Card>
            ) : null
          }
        </Cell>
      </Grid>
    ) : null
  }
}

const styles = {
  caption: {
    paddingTop: 16,
  },
  buttons: {
    float: 'right',
    marginTop: 15,
  },
  checkboxIcon: {
    paddingTop: 7,
  },
  divider: {
    marginTop: 32,
    marginBottom: 32,
  },
  equipmentCard: {
    backgroundColor: 'inherit',
    marginTop: 15,
    display: 'none',
  },
  equipmentWarranty: {
    marginTop: -12,
  },
  grid: {
    marginRight: -16,
    padding: 0,
  },
  historyCard: {
    marginBottom: 20,
  },
  main: {
    margin: 0,
    marginTop: 20,
  },
  paper: {
    padding: 16,
    paddingTop: 0,
  },
  problemTypes: {
    display: 'flex',
    flexDirection: 'row',
    marginLeft: -8,
  },
  recommendedPartsCard: {
    paddingBottom: 5,
    marginBottom: 100,
    marginTop: 15,
  },
  searchEquipmentInput: {
    paddingLeft: 10,
  },
  searchEquipmentWrapper: {
    margin: 20,
  },
  searchIcon: {
    float: 'left',
    paddingLeft: 10,
    paddingTop: 12,
  },
  sideBar: {
    backgroundColor: Theme.palette.sidebarBackground,
    height: 'auto',
    padding: 24,
    right: 0,
    top: 0,
  },
  siteHistory: {
    marginBottom: 24,
    textTransform: 'initial',
  },
  selectedIcon: {
    color: Theme.palette.pickerHeaderColor,
  },
  textField: {
    width: 470,
  },
  autoComplete: {
    width: 470,
  },
  displayNone: {
    display: 'none',
  },
}

export default Issue
