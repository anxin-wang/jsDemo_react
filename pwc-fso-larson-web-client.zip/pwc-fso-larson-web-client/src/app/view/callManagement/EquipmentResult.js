import React, { Component } from 'react'
import { ListItem, MenuItem} from 'material-ui'
import EquipmentWarranty from './EquipmentWarranty'

export class EquipmentResult extends Component {
  render() {
    const equipment = this.props.equipment

    return (
      <div>
        <ListItem
          primaryText={equipment.name}
          secondaryText={'Model: ' + equipment.modelNumber + ' Manufacturer: ' + equipment.manufacturer}
          disabled
        />
        <EquipmentWarranty
          equipment={equipment}
        />
      </div>
    )
  }
}

export function renderEquipmentSearch(equipmentResults) {
  return Object.keys(equipmentResults).map(key => {
    let equipment = equipmentResults[key]
    return {
      text: equipment.modelNumber,
      value: (
        <MenuItem>
          <EquipmentResult
            equipment={equipment}
          />
        </MenuItem>
      )
    }
  })
}

