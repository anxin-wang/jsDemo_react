import React, { Component } from 'react'
import Theme from '../../theme/Theme.js'
import ReportProblem from 'material-ui/svg-icons/action/report-problem'
import W from '../../const/warrantyStates'
import moment from 'moment'

class EquipmentWarranty extends Component {
  render() {
    const equipment = this.props.equipment
    const warrantyWarning = equipment.warrantyState === W.SOON_TO_EXPIRE ?
      'Warranty expires on ' + moment(equipment.expires).format('MM/DD/YY') : equipment.warrantyState === W.EXPIRED ?
      'Warranty has expired' : ''
    const warrantyStyle = equipment.warrantyState === W.SOON_TO_EXPIRE ?
      styles.warning : equipment.warrantyState === W.EXPIRED ?
      styles.alert : styles.noStress

    return (
      <div style={styles.warranty}>
        <div>
          <ReportProblem style={warrantyStyle}/>
        </div>
        <div style={styles.warrantyText}>
          { warrantyWarning }
        </div>
      </div>
    )
  }
}

const styles = {
  noStress: {
    display: 'none',
  },
  warning: {
    color: Theme.palette.warningColor,
    height: 16,
  },
  alert: {
    color: Theme.palette.negativeColor,
    height: 16,
  },
  warrantyText: {
    marginTop: -4,
    color: Theme.palette.textColorSoft,
  },
  warranty: {
    display: 'flex',
    flexDirection: 'row',
    position: 'absolute',
    bottom: -4,
    left: 150,
    fontSize: 14,
  },
}

export default EquipmentWarranty
