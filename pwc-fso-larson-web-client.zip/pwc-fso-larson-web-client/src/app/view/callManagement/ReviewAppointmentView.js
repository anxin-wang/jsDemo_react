import React, { Component, } from 'react'
import {
  CardHeader, MenuItem, Paper, RaisedButton, SelectField, TextField
} from 'material-ui'
import { formatZipCode, } from '../../filters/zipCode'
import { connect, } from 'react-redux'
import actions from '../../actions'
import appointmentTypes from '../../const/appointmentTypes'
import filterPhoneNumber from '../../filters/phoneNumber'
import IssueCard from '../appointmentManagement/IssueCard'
import firebaseCacheService from '../../infrastructure/FirebaseCacheService'
import priorities from '../../const/priorities'
import Subheading from '../../ui/typography/Subheading'

const fullWidth = true
let customerIdNameAddressDataSource = []

class ReviewAppointmentView extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      billName: 'name',
      billingAddress: 'address',
      customerNameAddress: 'nameAddress'
    }
    this.setAction = this.setAction.bind(this)
    this.changeBillInfo = this.changeBillInfo.bind(this)
    this.handleConfirm = this.handleConfirm.bind(this)
    this.onNewRequest = this.onNewRequest.bind(this)

    this.props.startListeningToClients()
  }

  componentWillMount() {
    if (this.getJobId()) {
      this.handleJobIdChange(null, null, this.getJobId())
      this.setState({
        action: 'update',
      })
    } else {
      this.setState({
        action: 'create',
      })
    }
  }

  componentWillUpdate() {
    const job = this.props.jobs[this.getJobId()]
    if (!job && this.getJobId()) {
      firebaseCacheService.prioritize(
        'jobs',
        this.getJobId()
      )
    }
    const appointment = this.props.appointments[this.getAppointmentId()]
    if (!appointment && this.getAppointmentId()) {
      firebaseCacheService.prioritize(
        'appointments',
        this.getAppointmentId(),
        'dispatcherApp/'
      )
    }
    if (this.getSiteId()) {
      const site = this.props.sites[this.getSiteId()]
      if (!site) {
        firebaseCacheService.prioritize(
          'sites',
          this.getSiteId()
        )
      }
    }
  }

  getJobId() {
    return this.props.routeParams.jobId
  }

  getSiteId() {
    return this.props.routeParams.siteId
  }

  getAppointmentId() {
    return this.props.routeParams.appointmentId
  }

  getNewAppointment() {
    return this.getAppointmentId() ?
      this.props.appointments[this.getAppointmentId()] || {} : {}
  }

  isAppointmentIncomplete() {
    const newAppointment = this.getNewAppointment()
    return (
      !(newAppointment.type || this.props.jobMeta.billTo) ||
      !newAppointment.priority ||
      !newAppointment.officeId ||
      (
        this.state.action === 'update' &&
        !newAppointment.jobId
      )
    )
  }

  onNewRequest(chosenRequest, index) {
    if (chosenRequest.text) {
      this.setState({customerNameAddress: chosenRequest.text})
    }
  }

  handleConfirm() {
    let customerNameAddress = this.state.customerNameAddress
    let clientId = ''
    let billType = 'client'
    let customerNameAddressArr = customerNameAddress.split('/')

    customerIdNameAddressDataSource.map((data, index) => {
      if (data.text === customerNameAddress) {
        clientId = data.clientId
      }
    })
    this.props.updateJobBillType(billType)
    this.props.updateJobBillTo(clientId)
    this.setState({billName: customerNameAddressArr[0]})
    this.setState({billingAddress: customerNameAddressArr[1]})
  }

  handleAppointmentTypeChange(event, index, value) {
    if (value !== 'TM') {
      this.setState({billName: 'name'})
      this.setState({billingAddress: 'address'})
    } else {
      let currentSite = this.props.sites[this.getSiteId()]
      let currentClientId = currentSite.clientId
      let currentClient = this.props.clients[currentClientId]

      let billName = currentClient ? currentClient.name : 'N/A'
      let billAddress = currentClient ? currentClient.address.street : 'N/A'

      this.setState({billName: billName})
      this.setState({billingAddress: billAddress})

      this.props.updateJobBillType('client')
      this.props.updateJobBillTo(currentClientId)
    }

    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        type: value,
      }
    )
  }

  handlePriorityChange(event, index, value) {
    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        priority: value,
      }
    )
  }

  handleOfficeChange(event, index, value) {
    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        officeId: value,
      }
    )
  }

  handleJobIdChange(event, index, value) {
    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        jobId: value,
      }
    )
    this.props.updateRouteParams({
      jobId: value,
    })
  }

  handleDetailsChange(event) {
    this.props.updateAppointmentAdditionalNotesField(event.target.value)
  }

  updateDetailsChange(event) {
    this.props.updateNewAppointment(
      this.getAppointmentId(),
      {
        serviceDescription: event.target.value,
      }
    )
  }

  handleCustomerPONumberChange(event) {
    this.props.updateCustomerPONumber(event.target.value)
  }

  handleQuotedAmountChange(event) {
    let onlynumber = event.target.value.replace(/[^0-9.]+/g, '')
    this.setState({quotedAmountValue: onlynumber})
    this.props.updateQuotedAmount(onlynumber)
  }

  handleNotToExceedAmountChange(event) {
    let onlynumber = event.target.value.replace(/[^0-9.]+/g, '')
    this.setState({notToExceedAmountValue: onlynumber})
    this.props.updateNotToExceedAmount(onlynumber)
  }

  setAction(value) {
    this.setState({ action: value })

    if (value === 'create') {
      this.props.updateRouteParams({
        jobId: null,
      })
      this.props.updateNewAppointment(
        this.getAppointmentId(),
        {
          jobId: null,
        }
      )
    }
  }

  changeBillInfo() {
    let clientsInfo = this.props.clients
    let clientKeysArr = Object.keys(clientsInfo)
    let customerNameAddressDataSource = []
    clientKeysArr.map((key, index) => {
      if (clientsInfo[key]['name'] && clientsInfo[key]['address']['street']) {
        customerNameAddressDataSource.push(
          {
            text: clientsInfo[key]['name'] + '/' + clientsInfo[key]['address']['street'],
            value: (
              <MenuItem
                primaryText={clientsInfo[key]['name']}
                secondaryText={clientsInfo[key]['address']['street']}
              />
            )
          }
        )
        customerIdNameAddressDataSource.push(
          {
            clientId: key,
            text: clientsInfo[key]['name'] + '/' + clientsInfo[key]['address']['street'],
          }
        )
      }
    })
    this.props.showDialog({
      title: 'What is the customer name/address?',
      acceptCaption: 'Confirm',
      acceptCallback: this.handleConfirm,
      autoComplete: {
        hintText: 'search by customer name/address',
        dataSource: customerNameAddressDataSource,
        onNewRequest: this.onNewRequest,
        fullWidth: fullWidth,
      }
    })
  }

  render() {
    const siteId = this.getSiteId()
    const site = this.props.sites[siteId]
    const client = site ? this.props.clients[site.clientId] : {}
    const address = site ? site.address : {}
    const { equipment, issues, parts, dispatchers, offices } = this.props
    const newAppointment = this.getNewAppointment()
    return (
      <div style={styles.wrapper}>
        <div style={styles.main}>
          <Subheading style={styles.title}>Review call summary</Subheading>
          <Paper style={styles.paper}>
            <TextField
              multiLine
              floatingLabelText="Customer PO Number"
              onChange={this.handleCustomerPONumberChange.bind(this)}
            /><br />
            <TextField
              style={styles.halfWidthTextField}
              underlineStyle={styles.underline}
              multiLine
              floatingLabelText="Quoted amount"
              value = {this.state.quotedAmountValue}
              onChange={this.handleQuotedAmountChange.bind(this)}
            />
            <TextField
              style={styles.halfWidthTextField}
              multiLine
              floatingLabelText="Not to exceed amount"
              value = {this.state.notToExceedAmountValue}
              onChange={this.handleNotToExceedAmountChange.bind(this)}
            />
            <TextField
              fullWidth
              multiLine
              floatingLabelText="Additional notes"
              onBlur = {this.updateDetailsChange.bind(this)}
              onChange={this.handleDetailsChange.bind(this)}
              value={this.props.appointmentTextFields.appointmentAdditionalNotesField ||
                newAppointment.serviceDescription}
            />
          </Paper>
          <br />
          <div style={styles.issues}>
          {
            Object.keys(issues).map((issueId) => {
              const issue = issues[issueId]
              let issueCard
              if (issue &&
                issue.appointmentId === this.getAppointmentId()) {
                issueCard = (
                  <IssueCard
                    key={issueId}
                    globalEquipment={equipment}
                    parts={parts}
                    dispatchers={dispatchers}
                    issue={issue}
                    issueId={issueId}
                  />
                )
              }
              return issueCard
            })
          }
          </div>
        </div>
        <div style={styles.sidebar}>
          <CardHeader
            style={styles.cardMainHeader}
            titleStyle={styles.cardMainHeaderTitle}
            textStyle={styles.cardHeaderMainText}
            title={site ? site.name : ''}
            subtitle={(
              <div style={styles.cardMainHeaderSubtitle}>
                {address ? address.street : ''}
                <br/>
                {address ? address.city + ', ' + address.state + ' ' + formatZipCode(address.zip) : ''}
              </div>
            )}
          />
          <CardHeader
            style={styles.cardTitleText}
            titleStyle={styles.callerTitle}
            textStyle={styles.cardHeaderText}
            title={'Caller'}
            subtitle={(
              <div style={styles.callerContext}>
                {newAppointment.callerName}
                <br/>
                {filterPhoneNumber.displayPhoneNumber(newAppointment.callerPhoneNumber)}
              </div>
            )}
          />
          <CardHeader
            style={styles.cardTitleText}
            titleStyle={styles.callerTitle}
            textStyle={styles.cardHeaderText}
            title={'Salesperson'}
            subtitle={(
              <div style={styles.callerContext}>
                <div>{client ? client.salesperson : 'N/A'}</div>
                <div>
                  {client ? client.number : 'N/A'}
                </div>
              </div>
            )}
          />
          <Subheading>
            Appointment type
          </Subheading>
          <Paper style={styles.sidePaper}>
            <p style={styles.sidePaperCaption}>{'Type'}</p>
            <SelectField
              style={styles.selectField}
              fullWidth
              hintText="unspecified"
              onChange={this.handleAppointmentTypeChange.bind(this)}
              value={newAppointment.type}
            >
            {
              appointmentTypes.map((appointmentType) => (
                <MenuItem
                  key={appointmentType.value}
                  style={styles.selectField}
                  value={appointmentType.value}
                  primaryText={appointmentType.text}
                />
              ))
            }
            </SelectField>
           <p style={styles.sidePaperCaption}>{'Bill Name'}</p>
          <CardHeader
            style={styles.cardTitleText}
            titleStyle={styles.callerTitle}
            textStyle={styles.cardHeaderText}
            subtitle={(
              <div style={styles.callerContext}>
                {this.state.billName === 'name' ? 'N/A' : this.state.billName}
              </div>
            )}
          />
            <p style={styles.sidePaperCaption}>{'Billing Address'}</p>
            <CardHeader
            style={styles.cardTitleText}
            titleStyle={styles.callerTitle}
            textStyle={styles.cardHeaderText}
            subtitle={(
              <div style={styles.callerContext}>
                {this.state.billingAddress === 'address' ? 'N/A' : this.state.billingAddress}
              </div>
            )}
          />
            <RaisedButton
              label="Change"
              secondary
              disabled={!(newAppointment.type === 'TM')}
              style={styles.changeButton}
              onClick={this.changeBillInfo} />
          </Paper>

          <Subheading>
            Priority
          </Subheading>
          <Paper style={styles.sidePaper}>
            <SelectField
              style={styles.selectField}
              fullWidth
              hintText="unspecified"
              onChange={this.handlePriorityChange.bind(this)}
              value={newAppointment.priority}
            >
            {
              Object.keys(priorities).map((priority) => (
                <MenuItem
                  key={priority}
                  style={styles.selectField}
                  value={priority}
                  primaryText={priorities[priority].text}
                />
              ))
            }
            </SelectField>
          </Paper>
          <Subheading>
            Branch
          </Subheading>
          <Paper style={styles.sidePaper}>
            <SelectField
              style={styles.selectField}
              fullWidth
              hintText="unspecified"
              onChange={this.handleOfficeChange.bind(this)}
              value={newAppointment.officeId}
            >
            {
              Object.keys(offices).map((officeId) => (
                <MenuItem
                  key={officeId}
                  style={styles.selectField}
                  value={officeId}
                  primaryText={offices[officeId].name}
                />
              ))
            }
            </SelectField>
          </Paper>
          <div style={styles.createForm}>
            <RaisedButton
              label="Create Appointment"
              primary
              onClick={this.props.createAppointment}
              disabled={this.isAppointmentIncomplete()}
            />
          </div>
        </div>
      </div>
    )
  }
}

const styles = {
  cardHeaderText: {
    padding: 0,
  },
  issues: {
    columnCount: 2,
    columnGap: '1em',
  },
  engineerText: {
    padding: 0,
    marginTop: 12,
    marginBottom: 12,
  },
  cardTitleText: {
    padding: 0,
  },
  createForm: {
    marginTop: 24,
  },
  main: {
    paddingTop: 32,
    width: 800,
  },
  sidebar: {
    marginLeft: 24,
    paddingTop: 93,
    width: 210,
  },
  paper: {
    marginTop: 20,
    padding: 16,
    paddingTop: 0,
  },
  selectField: {
    fontSize: 12,
    whiteSpace: 'nowrap',
  },
  buttonGroup: {
    marginBottom: 4,
  },
  nestedSidePaper: {
    marginTop: 4,
    marginBottom: 16,
    padding: 0,
    paddingLeft: 16,
    paddingRight: 16,
  },
  sidePaper: {
    marginTop: -12,
    padding: 0,
    paddingLeft: 16,
    paddingRight: 16,
  },
  title: {
    marginBottom: 24,
    textTransform: 'initial',
  },
  wrapper: {
    display: 'flex',
    flexDirection: 'row',
    position: 'relative',
    width: 1000,
    top: 40,
  },
  halfWidthTextField: {
    width: '50%',
  },
  underline: {
    width: '90%',
  },
  cardMainHeader: {
    padding: 0,
  },
  cardMainHeaderTitle: {
    fontSize: 20,
    width: 180,
    lineHeight: '26px',
    marginBottom: 14,
  },
  cardMainHeaderSubtitle: {
    color: '#555555',
    fontSize: 16,
    lineHeight: '26px',
    marginBottom: 14,
  },
  callerTitle: {
    color: '#999999',
    fontSize: 12,
  },
  callerContext: {
    color: '#555555',
    fontSize: 16,
    lineHeight: '26px',
    marginBottom: 14,
  },
  sidePaperCaption: {
    color: '#999999',
    marginBottom: -6,
    paddingTop: 10,
    marginLeft: -2,
  },
  sidePaperTextField: {
    width: '100%',
  },
  changeButton: {
    marginTop: 5,
    marginBottom: 10
  }
}

const mapStateToProps = (state) => {
  return {
    appointments: state.appointments,
    equipment: state.equipment,
    issues: state.issues,
    jobs: state.jobs,
    offices: state.offices,
    parts: state.parts,
    routeParams: state.routeParams,
    siteHistories: state.siteHistories,
    sites: state.sites,
    clients: state.clients,
    jobMeta: state.jobMeta,
    appointmentTextFields: state.appointmentTextFields
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    createAppointment: () => dispatch(actions.createAppointment()),
    createJob: () => dispatch(actions.createJob()),
    updateNewAppointment: (appointmentId, appointment) => dispatch(
      actions.updateNewAppointment(appointmentId, appointment)
    ),
    updateJob: (jobId, job) => dispatch(actions.updateJob(jobId, job)),
    updateRouteParams: (params) => dispatch(actions.updateRouteParams(params)),
    startListeningToClients: () => dispatch(actions.startListeningToClients()),
    showDialog: (dialog) => dispatch(actions.showDialog(dialog)),
    updateCustomerPONumber: (customerPONumber) => dispatch(actions.updateCustomerPONumber(customerPONumber)),
    updateQuotedAmount: (quotedAmount) => dispatch(actions.updateQuotedAmount(quotedAmount)),
    updateNotToExceedAmount: (notToExceedAmount) => dispatch(actions.updateNotToExceedAmount(notToExceedAmount)),
    updateJobBillType: (billType) => dispatch(actions.updateJobBillType(billType)),
    updateJobBillTo: (billTo) => dispatch(actions.updateJobBillTo(billTo)),
    updateAppointmentAdditionalNotesField: (notes) => dispatch(
      actions.updateAppointmentAdditionalNotesField(notes)
    ),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ReviewAppointmentView)
