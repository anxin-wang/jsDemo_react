import React, { Component, } from 'react'
import { connect, } from 'react-redux'
import UnderConstruction from '../../image/underConstruction.jpg'

class TechListView extends Component {
  constructor(props, context) {
    super(props, context)
  }

  render() {
    return (
      <div style={styles.outer}>
      </div>
    )
  }
}

const styles = {
  outer: {
    position: 'fixed',
    bottom: '0px',
    top: '42px',
    width: '100%',
    height: '100%',
    backgroundColor: 'white',
    backgroundImage: 'url(' + UnderConstruction + ')',
    backgroundPosition: '25% 40%',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'contain',
  }
}

const mapStateToProps = (state) => {
  return {
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(TechListView)
