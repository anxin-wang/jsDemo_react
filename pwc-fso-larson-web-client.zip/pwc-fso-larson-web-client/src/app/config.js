const Config = {
  BACKEND_SERVICE_BASE_URL: process.env.BACKEND_SERVICE_BASE_URL || null,
  EVENTS_CLOUD_FUNCTION_URL: process.env.EVENTS_CLOUD_FUNCTION_URL || null,
  PROJECT_ID: process.env.PROJECT_ID || null,
  API_KEY: process.env.API_KEY || null,
  GOOGLE_SCOPES: [ process.env.GOOGLE_SCOPES || null ],
  DEFAULT_SCOPE: process.env.DEFAULT_SCOPE || null,
  DEFAULT_CLIENT_ID: process.env.DEFAULT_CLIENT_ID || null,
  CUSTOM_AUTH_HEADER_NAME: process.env.CUSTOM_AUTH_HEADER_NAME || null,
  ELASTICSEARCH_INDEX: process.env.ELASTICSEARCH_INDEX || 'firebase-global',
  GOOGLE_GEOLOCATOR_URL: process.env.GOOGLE_GEOLOCATOR_URL || null,
  GOOGLE_DISTANCE_MATRIX_URL: process.env.GOOGLE_DISTANCE_MATRIX_URL || null,
  SLOWLOG_THRESHOLD_MILLIS: process.env.SLOWLOG_THRESHOLD_MILLIS || 5000
}

export default Config
