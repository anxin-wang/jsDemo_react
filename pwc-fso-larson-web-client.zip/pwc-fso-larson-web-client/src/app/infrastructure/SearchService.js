/**
 * Created by rob on 9/23/16.
 */

import Config from '../config'
import firebaseService from './FirebaseService'
import firebaseCacheService from '../infrastructure/FirebaseCacheService'
import firebase from 'firebase'

const DEFAULT_NAMESPACE = 'global/'
const db = () => firebase.database()
/**
 * Wrapper around elsatic search engine as wrapped by a home-rolled
 * firebase RPC mechanism
 */
/** TODO: Rob, as a team convention we don't comment code, whether auto or manually for other
    than temporary puroses. Please clean this class up! **/

class SearchService {

  /**
   * Main entrypoint into the class. returns entities and caches them
   * maybe thecaching is too much
   * @param searchText
   * @param type
   * @param esType The ES type is usually a non-plural version of the firebase type.
   * @returns {*}
   */
  searchES(
    searchText,
    type,
    esType
  ) {
    let esQuery = this.constructor.createESQuery(searchText, esType)
    return this.simpleRPC('search/request', 'search/response', esQuery, '')
      .then(results=> {
        let entities = this.constructor.extractEntities(results)
        this.cacheResults(type, entities)
        return entities
      })
  }
  /**
   *Cache all the returned entities
   * @param type
   * @param entityMap
   */
  cacheResults(
    type,
    entityMap
  ) {
    Object.keys(entityMap).forEach(key=>firebaseCacheService.cache(type, key))
  }

  /**
   * Takes a map of entities keyed by the FB id and returns a payload for
   * certain actions
   * @param entityMap
   * @returns {*}
   */
  static prepareActionPayload(
    entityMap
  ) {
    return Object.keys(entityMap).reduce((accumulator, key)=> {
      accumulator[key] = true
      return accumulator
    }, {})
  }
  /**
   *
   * @param searchTest
   * @param entity
   * @returns {{index: *, q: *, size: number, type: *}}
   */
  static createESQuery(
    searchTest,
    entity
  ) {
   /* eslint-disable camelcase */
    const entitySearches = {
      part: {
        query: {
          query_string: {
            query: `${searchTest}*`
          }
        }
      },
      equipment: {
        query: {
          query_string: {
            query: `${searchTest}*`
          }
        }
      },
      site: {
        query: {
          query_string: {
            query: `${searchTest}*`,
            fields: ['_all', 'name^4', '_source.address.*^3', 'contactName^2']
          }
        }
      }
    }
    /* eslint-enable camelcase */
    let queryDsl = entitySearches[entity]
    return {
      index: Config.ELASTICSEARCH_INDEX,
      queryDsl: JSON.stringify(queryDsl),
      size: 20,
      type: entity
    }
  }

  /**
   * Takes an ES search results and turns it into an object whose keys are
   * Firebase ids and whose values are the version of the entity stored in firebase
   *
   * For the moment we decorate the entity with the firebase key under "_id"
   * @param _in
   * @returns {*}
   */
  static extractEntities(_in) {
    try {
      return _in.hits.reduce((accumulator, source)=> {
        let entity = source._source
        entity._id = source._id
        accumulator[entity._id] = entity
        return accumulator
      }, {})
    } catch (err) {
      return {}
    }
  }

  /**
   * Wrapper around the CTP firebase RPC mechanism
   *
   * Leave a payload at one firebase location, pick up the results elsewhere. Currently only used for
   * search.
   *
   * @param path Where we put the RPC data
   * @param watchPath Where we wait for a response
   * @param value Item to put
   * @param namespace
   * @param timeOut  Length of time to wait for response before giving up. At the moment best guess is to
   *                  return an empty result.
   */
  simpleRPC(path,
            watchPath,
            value,
            namespace = DEFAULT_NAMESPACE,
            timeOut = 2000) {
    let startTime = new Date()
    let pk = firebaseService.add(path, value, namespace)
    return new Promise((resolve, reject)=> {  //We need to account for the firebase RPC not working
      setTimeout(()=> {
        resolve([])
      }, timeOut)
      db().ref(`${namespace}${watchPath}/${pk}`).on('value', (data)=> {
        if (!data.exists()) {
          return
        }
        let endTime = new Date()
        db().ref(`${namespace}${watchPath}/${pk}`).off()
        db().ref(`${namespace}${watchPath}/${pk}`).remove()
        resolve(data.val())

        // If query was slow, let's log it so we can later determine if there was an issue.
        this.addSlowlogEntry(startTime, endTime, pk)
      }, reject)
    })

  }

  addSlowlogEntry(startTime,
                  endTime,
                  requestId) {
    let duration = endTime.getTime() - startTime.getTime()
    if (duration > Config.SLOWLOG_THRESHOLD_MILLIS) {
      console.log('Search requestId=' + requestId + ' duration=' + duration)
      let slowlogEntry = {
        requestId: requestId,
        duration: duration
      }
      firebaseService.add('search/slowlog', slowlogEntry, '')
    }
  }
}

const searchService = new SearchService()
export default searchService
