const DEFAULT_NAMESPACE = 'global/'

class FirebaseService {
  initialize(firebaseReference) {
    this.database = firebaseReference.database()
    this.firebase = firebaseReference
  }

  subscribe(
    path,
    handler,
    namespace = DEFAULT_NAMESPACE
  ) {
    const ref = this.database.ref(namespace + path).orderByKey()
    ref.off()
    return ref.on('value', handler)
  }

  subscribeByLimitToFirst(
    limitToNumber,
    path,
    handler,
    namespace = DEFAULT_NAMESPACE
  ) {
    const ref = this.database.ref(namespace + path).orderByKey().limitToFirst(limitToNumber)
    ref.off()
    return ref.on('value', handler)
  }

  subscribeByChild(conditions) {
    let filterConditions = Object.assign({
      namespace: DEFAULT_NAMESPACE,
      path: null,
      // all values in:
      // https://firebase.google.com/docs/database/web/lists-of-data#sort_data
      orderField: null,
      equalTo: null,
      limitToFirst: 16,
      limitToLast: null,
      startAt: 0,
      // endAt: 16,
    }, conditions)
    if (!filterConditions.path) {
      console.error('path is null - subscribeByChild')
    }
    if (!filterConditions.orderField) {
      console.error('orderField is null - subscribeByChild')
    }
    let ref = this.database
      .ref(filterConditions.namespace + filterConditions.path)
      .orderByChild(filterConditions.orderField)
      // .startAt(filterConditions.startAt)
    ref = filterConditions.limitToLast ?
      ref.limitToLast(filterConditions.limitToLast)
      :
      filterConditions.limitToFirst ?
        ref.limitToFirst(filterConditions.limitToFirst)
        :
        ref
    return ref
  }

  add(
    path,
    newItem,
    namespace = DEFAULT_NAMESPACE
  ) {
    let itemToAdd = JSON.parse(JSON.stringify(newItem))
    itemToAdd.createdAt = this.firebase.database.ServerValue.TIMESTAMP
    itemToAdd.lastModifiedAt = this.firebase.database.ServerValue.TIMESTAMP
    return this.database.ref(namespace + path).push(itemToAdd).path.o.pop()
  }

  remove(
    path,
    namespace = DEFAULT_NAMESPACE
  ) {
    return this.database.ref(namespace + path).remove()
  }

  update(
    path,
    newState,
    handler,
    namespace = DEFAULT_NAMESPACE
  ) {
    newState.lastModifiedAt = this.firebase.database.ServerValue.TIMESTAMP
    return this.database.ref(namespace + path).update(newState, handler)
  }

  subscribeByValue(
    path,
    field,
    value,
    handler,
    namespace = DEFAULT_NAMESPACE
  ) {
    return this.database.ref(namespace + path).orderByChild(field).equalTo(value)
      .once('value', handler)
  }
}

const firebaseService = new FirebaseService()

export default firebaseService
