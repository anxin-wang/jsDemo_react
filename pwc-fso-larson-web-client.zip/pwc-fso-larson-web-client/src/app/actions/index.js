import appointmentActions from './appointment'
import appointmentsMetaActions from './appointmentsMeta'
import appointmentIndexesActions from './appointmentIndexes'
import appointmentTextFieldsActions from './appointmentTextFields'
import authActions from './auth'
import dialogActions from './dialog'
import dispatchersActions from './dispatchers'
import engineerActions from './engineer'
import engineerMetaActions from './engineerMeta'
import equipmentActions from './equipment'
import equipmentSearchActions from './equipmentSearch'
import issueActions from './issue'
import jobsActions from './jobs'
import mapActions from './map'
import notificationsActions from './notifications'
import officesActions from './offices'
import clientsActions from './clients'
import partSearchActions from './partSearch'
import routeParamsActions from './routeParams'
import searchActions from './search'
import snackbarActions from './snackbar'
import jobMetaActions from './jobMeta'

export default Object.assign(
  {},
  appointmentActions,
  appointmentsMetaActions,
  appointmentIndexesActions,
  authActions,
  dialogActions,
  dispatchersActions,
  engineerActions,
  engineerMetaActions,
  equipmentActions,
  equipmentSearchActions,
  issueActions,
  jobsActions,
  mapActions,
  notificationsActions,
  officesActions,
  clientsActions,
  partSearchActions,
  routeParamsActions,
  searchActions,
  engineerActions,
  snackbarActions,
  jobMetaActions,
  appointmentTextFieldsActions,
)
