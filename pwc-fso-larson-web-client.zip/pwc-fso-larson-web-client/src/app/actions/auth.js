import firebase from 'firebase'
import Config from '../config'
import A from '../const/actionTypes'
import actions from '.'
import store from '../store'

export default {
  startListeningToAuth: () => {
    return (dispatch, getState) => {
      firebase.auth().onAuthStateChanged((authData) => {
        const route = store.getState().routeParams.route
        if (authData) {
          dispatch({
            type: A.LOGIN,
            uid: authData.uid,
            username: authData.displayName, // authData.github.displayName || authData.github.username
          })
          dispatch(actions.syncDispatcher(authData))
          // TODO: notifications will need index generated before the client can read them
          // dispatch(actions.startListeningToNotifications(authData.uid))

          if (route === '') {
            dispatch(actions.routeTo('viewAppointments'))
          } else {
            dispatch(actions.routeTo(
              route,
              store.getState().routeParams
            ))
          }
        } else {
          if (route !== '') {
            dispatch(actions.routeTo(''))
          }
        }
      })
    }
  },
  attemptLogin: () => {
    return (dispatch, getState) => {
      dispatch({
        type: A.ATTEMPTING_LOGIN,
      })
      const provider = new firebase.auth.GoogleAuthProvider()
      Config.GOOGLE_SCOPES.map((scope) => provider.addScope(scope))
      firebase.auth().signInWithPopup(provider)
      .then((authResult) => {
        if (authResult && !authResult.error) {
        }
      })
      .catch(
        (error) => {
          dispatch({
            type: A.DISPLAY_ERROR,
            error: 'Login failed! ' + error,
          })
          dispatch({
            type: A.LOGOUT,
          })
        }
      )
    }
  },
  logout: () => {
    return (dispatch, getState) => {
      dispatch({
        type: A.LOGOUT,
      })
      firebase.auth().signOut()
    }
  },
}
