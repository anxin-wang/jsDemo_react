import A from '../const/actionTypes'
import appointmentStatus from '../const/appointmentStatus'
import actions from '.'

export default {
  calculateDistances: () => {
    return (dispatch, getState) => {
      const GMAP_MAX_DEST_PER_REQUEST = 25
      const GMAP_MAX_ELEMENTS_PER_SEC = 100
      const MAX_REQUESTS_PER_SEC = GMAP_MAX_ELEMENTS_PER_SEC / GMAP_MAX_DEST_PER_REQUEST
      const maps = getState().appointmentsMeta.maps
      const distanceMatrixService = new maps.DistanceMatrixService()
      let appointmentIndexes = getState().appointmentIndexes

      const allDestinations = []
      const appointmentIndexIds = []
      Object.keys(appointmentIndexes).map((appointmentIndexId) => {
        const appointmentIndex = appointmentIndexes[appointmentIndexId]
        const siteAddress = appointmentIndex.meta ? appointmentIndex.meta.siteAddress : null
        if (siteAddress) {
          allDestinations.push(siteAddress)
          appointmentIndexIds.push(appointmentIndexId)
        }
      })

      let requestTimes = Math.ceil(allDestinations.length / GMAP_MAX_ELEMENTS_PER_SEC)
      const originTimes = requestTimes
      let requestDistance = () => {
        let promiseArr = []
        for (let index = 0; index < MAX_REQUESTS_PER_SEC; index++) {
          let destinations = allDestinations.splice(0, GMAP_MAX_DEST_PER_REQUEST)
          if (destinations.length) {
            let options = {
              origins: [getState().appointmentsMeta.sortAddress],
              destinations,
              travelMode: 'DRIVING',
              unitSystem: maps.UnitSystem.IMPERIAL,
            }
            let promiseToGetDistance = new Promise((resolve, reject) => {
              distanceMatrixService.getDistanceMatrix(
                options,
                (response, status) => {
                  if (status === 'OK') {
                    resolve(response)
                  } else {
                    console.log(status)
                    reject(status)
                  }
                }
              )
            })
            promiseArr.push(promiseToGetDistance)
          }
        }

        Promise.all(promiseArr).then((mapResult) => {
          let elementsArr = []
          const pagination = (originTimes - requestTimes) * GMAP_MAX_ELEMENTS_PER_SEC
          mapResult.forEach((map) => {
            elementsArr = elementsArr.concat(map.rows[0].elements)
          })

          elementsArr.forEach((element, index) => {
            if (element.distance) {
              const appointmentIndexId = appointmentIndexIds[index + pagination]
              const meta = Object.assign(
                {},
                appointmentIndexes[appointmentIndexId].meta,
                {
                  distance: element.distance.text,
                  distanceValue: element.distance.value,
                }
              )

              dispatch({
                type: A.UPDATE_APPOINTMENT_INDEX,
                appointmentIndexId,
                appointmentIndex: {
                  meta,
                },
              })
            }
          })
          dispatch(actions.sortAppointments())
          dispatch(actions.pagingAppointments())

          requestTimes--
          if (requestTimes > 0) {
            setTimeout(requestDistance, 2000)
          } else {
            console.log('sort distances done')
          }
        })
      }

      requestDistance()
    }
  },
  clearRecentlyCreated: () => {
    return (dispatch, getState) => {
      dispatch({
        type: A.CLEAR_RECENTLY_CREATED,
      })
    }
  },
  registerMapsAPI: (maps) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.REGISTER_MAPS_API,
        maps,
      })
    }
  },
  setSortAddress: (address) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.SET_SORT_ADDRESS,
        address,
      })
    }
  },
  setSortMethod: (sortMethod) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.SET_SORT_METHOD,
        sortMethod,
      })
    }
  },
  setOrderMethod: (orderMethod) => {
    return (dispatch, getState) => {
      const meta = getState().appointmentsMeta
      let orderField
      if (orderMethod === 'priority') {
        orderField = 'meta/priority'
      }
      if (orderMethod === 'activity') {
        switch (meta.appointmentStatus) {
          case appointmentStatus.UNASSIGNED:
            orderField = 'meta/createdAt'
            break
          case appointmentStatus.ASSIGNED:
            orderField = 'meta/assignedAt'
            break
          case appointmentStatus.COMPLETED:
            orderField = 'meta/completedAt'
            break
        }
      }
      dispatch({
        type: A.SET_SORT_FIELD,
        orderField,
      })
    }
  },
  updateAppointmentMeta: (newMeta) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENT_META,
        newMeta,
      })
    }
  },
  updateToggleAppointmentDetail: () => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENT_DETAIL
      })
    }
  },
}
