import A from '../const/actionTypes'

const renderFakeCoordinate = () => {
  let increments = [
    0.01, -0.01, -0.02, 0.02, 0.03, -0.03, 0.04, -0.04, 0.05, -0.05,
    0.07, -0.07, 0.06, -0.06,
  ]
  return increments[Math.floor(Math.random() * increments.length)]
}

export default {
  centerMap: (lat, lng) => {
    return (dispatch, getState) => {
      const engineers = getState().engineers
      const map = {
        center: [lat, lng]
      }
      if (!getState().map.engineerLocations) {
        map.engineerLocations = {}
        Object.keys(engineers).map((engineerId) => {
          map.engineerLocations[engineerId] = [lat + renderFakeCoordinate(), lng + renderFakeCoordinate()]
        })
        dispatch({
          type: A.UPDATE_MAP,
          map,
        })
      }
    }
  },
}
