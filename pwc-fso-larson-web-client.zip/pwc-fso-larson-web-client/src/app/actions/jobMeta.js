import A from '../const/actionTypes'

export default {
  updateCustomerPONumber: (customerPONumber) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_CUSTOMERPONUMBER,
        customerPONumber,
      })
    }
  },
  updateQuotedAmount: (quotedAmount) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_QUOTEDAMOUNT,
        quotedAmount,
      })
    }
  },
  updateNotToExceedAmount: (notToExceedAmount) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_NOTTOEXCEEDAMOUNT,
        notToExceedAmount,
      })
    }
  },
  updateJobBillType: (billType) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_BILLTYPE,
        billType,
      })
    }
  },
  updateJobBillTo: (billTo) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_BILLTO,
        billTo,
      })
    }
  },
}
