import A from '../const/actionTypes'
import firebaseService from '../infrastructure/FirebaseService'

export default {
  startListeningToOffices: () => {
    return (dispatch, getState) => {
      firebaseService.subscribe(
        'offices/',
        (result) => {
          const offices = result.val() || {}

          dispatch({
            type: A.RECEIVE_OFFICES,
            offices
          })
        },
      )
    }
  },
}
