import actions from '.'
import A from '../const/actionTypes'
import firebaseService from '../infrastructure/FirebaseService'
import jobStatus from '../const/jobStatus'

export default {
  createJob: () => {
    return (dispatch, getState) => {
      let appointmentId = getState().routeParams.appointmentId
      let siteId = getState().routeParams.siteId
      const newAppointment = appointmentId ? getState().appointments[appointmentId] : {}
      const newJob = {
        issues: Object.assign({}, newAppointment.issues),
        siteId,
        status: jobStatus.OPEN,
        type: 'TIME & MATERIAL',
        purchaseOrder: getState().jobMeta.customerPONumber,
        quotedAmount: parseInt(getState().jobMeta.quotedAmount, 10),
        notToExceedAmount: parseInt(getState().jobMeta.notToExceedAmount, 10),
        billToType: getState().jobMeta.billType,
        billTo: getState().jobMeta.billTo,
      }
      const newJobId = firebaseService.add(
        'jobs',
        newJob
      )
      dispatch({
        type: A.CREATE_JOB,
        jobId: newJobId,
        job: newJob,
      })
      dispatch(actions.updateRouteParams({
        jobId: newJobId,
      }))
    }
  },
  updateJob: (jobId, job) => {
    return (dispatch, getState) => {
      if (jobId && job) {
        dispatch({
          type: A.UPDATE_JOB,
          jobId: jobId,
          job,
        })

        firebaseService.update(
          'jobs/' + jobId,
          job,
          (error) => {
            if (error) {
              console.log(error)
            }
          }
        )
      } else {
        job.status = jobStatus.OPEN
        const newJobId = firebaseService.add(
          'jobs',
          job
        )
        dispatch({
          type: A.SELECT_NEW_JOB,
          jobId: newJobId
        })
      }
    }
  },
  getJobsBySiteId: (siteId) => {
    return (dispatch, getState) => {
      firebaseService.subscribeByValue(
        'jobs',
        'siteId',
        siteId,
        (result) => {
          const jobs = result.val() || {}
          const appointmentIndexes = getState().appointmentIndexes
          Object.keys(jobs).forEach((jobId) => {
            let job = jobs[jobId]
            let shouldCacheData = false
            const appointments = job.appointments || {}
            // TODO: if job.status is COMPLETED, do not cache job
            shouldCacheData = Object.keys(appointments).some((appointmentId) => {
              return appointmentIndexes[appointmentId]
            })

            if (shouldCacheData) {
              dispatch({
                type: A.CACHE_JOBS,
                value: job,
                id: jobId,
              })

              appointments && Object.keys(appointments).map((appointmentId) => {
                firebaseService.subscribe(
                  'appointments/' + appointmentId,
                  (result) => {
                    const currentAppointment = result.val()
                    if (currentAppointment) {
                      dispatch({
                        type: A.CACHE_APPOINTMENTS,
                        value: currentAppointment,
                        id: appointmentId
                      })
                    } else {
                      delete appointments[appointmentId]
                      dispatch({
                        type: A.UPDATE_JOB,
                        job: job,
                        jobId
                      })
                    }
                  }
                )
              })
            }
          })
        }
      )
    }
  }
}
