import A from '../const/actionTypes'
import firebaseService from '../infrastructure/FirebaseService'
import searchService from '../infrastructure/SearchService'
import firebaseCacheService from '../infrastructure/FirebaseCacheService'

const SEARCH_BUFFER_DELAY = 480

export default {
  clearSearch: () => {
    return (dispatch) => {
      dispatch({
        type: A.CLEAR_SEARCH,
      })
    }
  },
  searchForTerm: (term) => {
    return (dispatch) => {
      dispatch({
        type: A.SEARCH_FOR_TERM,
        term,
      })

      if (firebaseService.searchTimeout) {
        clearTimeout(firebaseService.searchTimeout)
      }
      firebaseService.searchTimeout = setTimeout(
        () => {
          const results = term ? searchService.searchES(term, 'sites', 'site') : Promise.resolve({})
          results.then((results)=> {
            results = searchService.constructor.prepareActionPayload(results)
            results = {sites: results}
            if (Object.keys(results.sites).length === 0) {
              results.sites['-KRYIMRaSzauGQGxAnQr'] = true
              firebaseCacheService.cache(
                'sites',
                '-KRYIMRaSzauGQGxAnQr'
              )
            }
            dispatch({
              type: A.RECEIVE_SEARCH_RESULTS,
              results
            })
          })
        },
        SEARCH_BUFFER_DELAY
      )
    }
  },
}
