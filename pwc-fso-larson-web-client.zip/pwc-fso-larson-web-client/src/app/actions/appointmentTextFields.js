import A from '../const/actionTypes'

export default {
  updateAppointmentDescriptionField: (value) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENTDESCRIPTION_FIELD,
        description: value
      })
    }
  },
  updateAppointmentPhoneNumberField: (value) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENTPHONENUMBER_FIELD,
        phoneNumber: value
      })
    }
  },
  updateAppointmentCallerNameField: (value) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENTCALLERNAME_FIELD,
        callerName: value
      })
    }
  },
  updateAppointmentIssueDescriptionField: (value) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENTISSUEDESCRIPTION_FIELD,
        issueDescription: value
      })
    }
  },
  updateAppointmentAdditionalNotesField: (value) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_APPOINTMENTADDITIONALNOTES_FIELD,
        additionalNotes: value
      })
    }
  },
}
