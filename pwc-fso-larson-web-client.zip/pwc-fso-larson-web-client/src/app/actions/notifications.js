import A from '../const/actionTypes'
import actions from '.'
import firebaseService from '../infrastructure/FirebaseService'
import notificationStatus from '../const/notificationStatus'

export default {
  updateNotificationStatus: (notificationId, status) => {
    return (dispatch, getState) => {
      let currentNotification = getState().notifications[notificationId] || {}
      let notification = Object.assign(
        {},
        currentNotification,
        {
          status: status
        }
      )

      dispatch(actions.updateNotification(
        notificationId,
        notification
      ))
    }
  },
  dismissNotifications: () => {
    return (dispatch, getState) => {
      const notifications = getState().notifications
      if (Object.keys(notifications).length) {
        Object.keys(notifications).map((notificationId) => {
          if (notifications[notificationId].status === 'SENT') {
            dispatch(actions.updateNotificationStatus(notificationId, notificationStatus.SHOWN))
          }
        })
      }
    }
  },
  startListeningToNotifications: (recipientId) => {
    // TODO: notifications will need index generated before the client can read them
  },
  updateNotification: (
    notificationId,
    notification
  ) => {
    return (dispatch, getState) => {
      if (notificationId) {
        dispatch({
          type: A.UPDATE_NOTIFICATION,
          notificationId,
          notification,
        })

        firebaseService.update(
          'notifications/' + notificationId,
          notification,
          (error) => {
            if (error) {
              console.log(error)
            }
          },
        )
      }
    }
  },
}
