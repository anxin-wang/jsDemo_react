import A from '../const/actionTypes'

export default {
  updateEngineerMeta: (newMeta) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_ENGINEER_META,
        newMeta,
      })
    }
  },
}
