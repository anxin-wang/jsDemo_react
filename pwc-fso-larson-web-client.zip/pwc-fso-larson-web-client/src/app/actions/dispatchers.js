import A from '../const/actionTypes'
import firebaseService from '../infrastructure/FirebaseService'

export default {
  startListeningToDispatchers: () => {
    return (dispatch, getState) => {
      firebaseService.subscribe(
        'dispatchers/',
        (result) => {
          const dispatchers = result.val() || {}

          dispatch({
            type: A.RECEIVE_DISPATCHERS,
            dispatchers
          })
        },
        'dispatcherApp/'
      )
    }
  },
  syncDispatcher: (authData) => {
    return (dispatch, getState) => {
      const uid = authData.uid
      firebaseService.subscribe(
        'dispatchersLookup/' + uid,
        (result) => {
          const dispatchers = result.val() || {}
          const dispatcherId = !Object.keys(dispatchers).length ?
          firebaseService.add(
            'dispatchers',
            {
              userId: uid,
              name: authData.displayName,
            },
            'dispatcherApp/'
          ) : null
          if (dispatcherId) {
            let lookup = {}
            lookup[uid] = dispatcherId
            firebaseService.update(
              'dispatchersLookup',
              lookup,
              () => {},
              'dispatcherApp/'
            )
          }
        },
        'dispatcherApp/'
      )
    }
  },
}
