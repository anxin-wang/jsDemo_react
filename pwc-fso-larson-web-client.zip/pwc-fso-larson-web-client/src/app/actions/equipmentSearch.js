import A from '../const/actionTypes'
import searchService from '../infrastructure/SearchService'
import firebaseService from '../infrastructure/FirebaseService'

const SEARCH_BUFFER_DELAY = 480

export default {
  searchForEquipment: (term, issueId) => {
    return (dispatch) => {
      dispatch({
        type: A.SEARCH_FOR_EQUIPMENT,
        term,
        issueId
      })

      if (firebaseService.searchTimeout) {
        clearTimeout(firebaseService.searchTimeout)
      }
      firebaseService.searchTimeout = setTimeout(
        () => {
          const results = term ? searchService.searchES(term, 'equipment', 'equipment') : Promise.resolve({})
          results.then((results)=> {
            dispatch({
              type: A.RECEIVE_EQUIPMENT_RESULTS,
              results,
              issueId
            })
          })
        },
        SEARCH_BUFFER_DELAY
      )
    }
  },
}
