import A from '../const/actionTypes'
import firebaseService from '../infrastructure/FirebaseService'
import firebaseCacheService from '../infrastructure/FirebaseCacheService'
import actions from '.'

const getExistingOrNewAppointmentId = (dispatch, getState) => {
  if (!getState().routeParams.appointmentId) {
    dispatch(actions.addAppointment({}))
  }
  return getState().routeParams.appointmentId
}

export default {
  createNewIssue: (issue) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.SELECT_NEW_ISSUE,
        issueId: null,
      })
    }
  },
  toggleEquipment: (
    equipmentId,
    issue,
    issueId
  ) => {
    return (dispatch, getState) => {
      issue.equipment = issue.equipment || {}
      dispatch({
        type: A.TOGGLE_EQUIPMENT,
        equipmentId,
        issue,
        issueId,
      })

      let currentEquipment = getState().issues[issueId].equipment
      firebaseService.update(
        'issues/' + issueId,
        { equipment: currentEquipment },
        (error) => {
          if (error) {
            console.log(error)
          }
        },
        'dispatcherApp/'
      )
    }
  },
  togglePart: (
    partId,
    issueId
  ) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.TOGGLE_PART,
        partId,
        issueId
      })

      const updatedIssue = getState().issues[issueId]
      firebaseService.update(
        'issues/' + issueId,
        { selectedParts: updatedIssue.selectedParts },
        (error) => {
          if (error) {
            console.log(error)
          }
        },
        'dispatcherApp/'
      )
    }
  },
  updateNewIssue: (
    issueId,
    issue
  ) => {
    return (dispatch, getState) => {
      if (issueId) {
        dispatch({
          type: A.UPDATE_ISSUE,
          issueId: issueId,
          issue,
        })
        firebaseService.update(
          'issues/' + issueId,
          issue,
          (error) => {
            if (error) {
              console.log(error)
            }
          },
          'dispatcherApp/'
        )
      } else {
        const appointmentId = getExistingOrNewAppointmentId(dispatch, getState)
        issue.equipment = {}
        issue.appointmentId = appointmentId
        issue.siteId = getState().routeParams.siteId
        issue.clientId = getState().sites[issue.siteId] ? getState().sites[issue.siteId].clientId : null
        issueId = firebaseService.add(
          'issues',
          issue,
          'dispatcherApp/'
        )
        dispatch(actions.addIssueToAppointment(
          appointmentId,
          issueId
        ))
        const appointment = Object.assign({}, getState().appointments[appointmentId])
        let issues = Object.assign({}, appointment.issues)
        issues[issueId] = true
        appointment.issues = issues
        dispatch(actions.updateNewAppointment(
          appointmentId,
          appointment
        ))
        dispatch({
          type: A.SELECT_NEW_ISSUE,
          issueId,
        })
        firebaseCacheService.prioritize(
          'issues',
          issueId,
          'dispatcherApp/'
        )
      }
    }
  },
}
