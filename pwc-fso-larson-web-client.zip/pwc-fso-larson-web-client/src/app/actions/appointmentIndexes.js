import _ from 'lodash'
import A from '../const/actionTypes'
import actions from '.'
import appointmentStatus from '../const/appointmentStatus'
import firebaseService from '../infrastructure/FirebaseService'
import firebaseCacheService from '../infrastructure/FirebaseCacheService'

const sortByTimestamp = (timestampA, timestampB) => {
  let order = 0
  if (timestampA > timestampB) {
    order = -1
  } else {
    if (timestampA < timestampB) {
      order = 1
    } else {
      order = 0
    }
  }
  return order
}
const getRelevantTimestamp = (appointment) => {
  let timestamp = appointment.createdAt
  switch (appointment.status) {
    case appointmentStatus.UNASSIGNED:
      timestamp = appointment.createdAt
      break
    case appointmentStatus.ASSIGNED:
      timestamp = appointment.assignedAt
      break
    case appointmentStatus.APPROACHING:
      timestamp = appointment.departedAt
      break
    case appointmentStatus.ARRIVED:
      timestamp = appointment.arrivedAt
      break
    case appointmentStatus.COMPLETED:
      timestamp = appointment.completedAt
      break
  }
  return timestamp
}

export default {
  sortAppointments: () => {
    return (dispatch, getState) => {
      let existingIndexes = Object.assign({}, getState().appointmentIndexes)
      let sortedKeys = Object.keys(existingIndexes)
      sortedKeys.sort((indexIdA, indexIdB) => {
        let order = 0
        const sortMethod = getState().appointmentsMeta.sortMethod
        const indexA = existingIndexes[indexIdA]
        const indexB = existingIndexes[indexIdB]
        const appointmentAId = indexA.appointmentId
        const appointmentBId = indexB.appointmentId
        const priorityA = getState().appointments[appointmentAId] ? getState().appointments[appointmentAId].priority :
          indexA.meta ? indexA.meta.priority : ''
        const priorityB = getState().appointments[appointmentBId] ? getState().appointments[appointmentBId].priority :
          indexB.meta ? indexB.meta.priority : ''
        const timestampA = getState().appointments[appointmentAId] ?
          getRelevantTimestamp(getState().appointments[appointmentAId]) : indexA.meta ?
            getRelevantTimestamp(indexA.meta) : 0
        const timestampB = getState().appointments[appointmentBId] ?
          getRelevantTimestamp(getState().appointments[appointmentBId]) : indexB.meta ?
            getRelevantTimestamp(indexB.meta) : 0
        if (sortMethod === 'priority') {
          if (priorityA > priorityB) {
            order = 1
          } else {
            if (priorityA < priorityB) {
              order = -1
            } else {
              order = sortByTimestamp(timestampA, timestampB)
            }
          }
        }
        if (sortMethod === 'activity') {
          order = sortByTimestamp(timestampA, timestampB)
        }
        if (sortMethod === 'distance') {
          const distanceA = indexA.meta && (indexA.meta.distanceValue ||
            indexA.meta.distanceValue === 0) ? indexA.meta.distanceValue : 9999999999999
          const distanceB = indexB.meta && (indexB.meta.distanceValue ||
            indexB.meta.distanceValue === 0) ? indexB.meta.distanceValue : 9999999999999
          order = distanceA > distanceB ? 1 : -1
        }
        return order
      })
      let sortedIndexes = {}
      sortedKeys.map((sortedKey) => {
        sortedIndexes[sortedKey] = existingIndexes[sortedKey]
      })
      dispatch({
        type: A.SORT_APPOINTMENT_INDEXES,
        appointmentIndexes: sortedIndexes,
      })
    }
  },
  startListeningToAppointments: () => {
    return (dispatch, getState) => {
      const QUERY = 'appointmentList/'
      firebaseService.subscribe(
        QUERY + 'appointmentIndexes/',
        (result) => {
          const appointmentIndexes = result.val() || {}
          dispatch({
            type: A.RECEIVE_APPOINTMENT_INDEXES,
            appointmentIndexes,
          })
          dispatch(actions.sortAppointments())
          _.reverse(Object.keys(appointmentIndexes)).map((appointmentIndexId) => {
            firebaseCacheService.cache(
              'appointments',
              appointmentIndexes[appointmentIndexId].appointmentId,
              'global/',
              0,
              actions.sortAppointments()
            )
          })
        },
        'dispatcherApp/'
      )
    }
  },
  clearCachedAppintmentIndexes: () => {
    return (dispatch, getState) => {
      dispatch({
        type: A.CLEAR_APPINTMENT_INDEXES,
      })
    }
  },
  cacheReviewedAppointmentIndexes: () => {
    return (dispatch, getState) => {
      dispatch(actions.updateAppointmentMeta({
        loading: true,
      }))
      const meta = getState().appointmentsMeta
      const indexPromises = Object.keys(meta.appointmentType)
      .filter((type) => {
        return meta.appointmentType[type]
      })
      .map((type) => {
        return new Promise((resolve) => {
          // TODO filter different type
          firebaseService.subscribeByChild({
            namespace: 'dispatcherApp/',
            path: 'appointmentList/' + meta.appointmentStatus + '_' + type,
            orderField: meta.orderField,
            limitToLast: meta.pageSize,
          })
          .on('value', (snapshot) => {
            // TODO: dispatch if value changes
            dispatch({
              type: A.RECEIVE_APPOINTMENT_INDEXES,
              appointmentIndexes: snapshot.val(),
            })
            resolve()
          })
        })
      })
      Promise.all(indexPromises)
        .then(() => {
          // TODO: off all listeners
          dispatch(actions.updateAppointmentMeta({
            loading: false,
          }))
          dispatch(actions.indexAppointmentIndexes())
        })
    }
  },
  indexAppointmentIndexes: () => {
    return (dispatch, getState) => {
      const appointmentIndexes = getState().appointmentIndexes
      const {appointmentStatus, sortMethod, orderField, appointmentType} = getState().appointmentsMeta
      const originAppointmentIndexes = appointmentIndexes ? appointmentIndexes : getState().appointmentIndexes
      let flatAppointmentIndexes = Object.keys(originAppointmentIndexes)
        .map((id) => {
          return Object.assign({id}, originAppointmentIndexes[id])
        })
      const filteredResult = _.filter(flatAppointmentIndexes, (appointmentIndex, key) => {
        return appointmentIndex.meta.status === appointmentStatus &&
          // isTypeMatched
          appointmentType[appointmentIndex.meta.type]
      })
      let convertedResult
      if (sortMethod === 'distance') {
        // TODO call joey's distance method
        convertedResult = filteredResult.reduce((results, currentAppointment) => {
          results[currentAppointment.id] = currentAppointment
          return results
        }, {})
        dispatch({
          type: A.INDEX_APPOINTMENT,
          appointmentIndexes: convertedResult,
        })
        dispatch(actions.calculateDistances())
      } else {
        const field = orderField.split('/')[1]
        let sortedResult = _.orderBy(filteredResult, (result) => {
          return result.meta[field]
        }, sortMethod === 'priority' ? 'asc' : 'desc')
        convertedResult = sortedResult.reduce((results, currentAppointment) => {
          results[currentAppointment.id] = currentAppointment
          return results
        }, {})
        dispatch({
          type: A.INDEX_APPOINTMENT,
          appointmentIndexes: convertedResult,
        })
        dispatch(actions.pagingAppointments())
      }
    }
  },
  pagingAppointments: () => {
    return (dispatch, getState) => {
      const {pageSize} = getState().appointmentsMeta
      let appointmentIndexes = getState().appointmentIndexes
      let flatAppointmentIndexes = Object.keys(appointmentIndexes)
        .map((id) => {
          return Object.assign({id}, appointmentIndexes[id])
        })
      const pagingResult = pageSize < flatAppointmentIndexes.length ?
        _.slice(flatAppointmentIndexes, 0, pageSize) : flatAppointmentIndexes
      let convertedResult = pagingResult.reduce((results, currentAppointment) => {
        results[currentAppointment.id] = currentAppointment
        return results
      }, {})
      dispatch({
        type: A.INDEX_APPOINTMENT,
        appointmentIndexes: convertedResult,
      })
      dispatch(actions.updateAppointmentMeta({
        loading: false,
      }))
    }
  },
}
