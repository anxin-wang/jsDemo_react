import A from '../const/actionTypes'
import actions from '.'
import appointmentStatus from '../const/appointmentStatus'
import firebase from 'firebase'
import firebaseService from '../infrastructure/FirebaseService'
import firebaseCacheService from '../infrastructure/FirebaseCacheService'

export default {
  addIssueToAppointment: (
    appointmentId,
    issueId,
  ) => {
    return (dispatch, getState) => {
      let issues = getState().appointments[appointmentId] ?
        getState().appointments[appointmentId].issues || {} : {}
      issues[issueId] = true
      dispatch(actions.updateNewAppointment(
        appointmentId,
        {
          issues
        }
      ))
    }
  },
  addEngineerToAppointment: (
    appointmentId,
    engineerId,
  ) => {
    return (dispatch, getState) => {
      const timestamp = firebase.database.ServerValue.TIMESTAMP
      dispatch(actions.updateAppointment(
        appointmentId,
        {
          assignedAt: timestamp,
          assignedEngineer: engineerId,
          status: appointmentStatus.ACKNOWLEDG,
        },
      ))
    }
  },
  cacheAppointment: (appointmentId) => {
    return (dispatch, getState) => {
      firebaseCacheService.cache(
        'appointments',
        appointmentId
      )
    }
  },
  removeEngineerFromAppointment: (
    appointmentId,
  ) => {
    return (dispatch, getState) => {
      dispatch(actions.updateAppointment(
        appointmentId,
        {
          assignedAt: null,
          assignedEngineer: null,
          status: appointmentStatus.UNASSIGNED
        }
      ))
    }
  },
  addAppointment: (appointment) => {
    return (dispatch, getState) => {
      appointment.equipment = []
      appointment.status = appointmentStatus.NEW
      appointment.createdBy = getState().auth.uid
      const newAppointmentId = firebaseService.add(
        'appointments',
        appointment,
        'dispatcherApp/'
      )
      dispatch(actions.updateRouteParams({
        appointmentId: newAppointmentId
      }))
    }
  },
  createAppointment: () => {
    return (dispatch, getState) => {
      const appointmentId = getState().routeParams.appointmentId
      let appointment = getState().appointments[appointmentId]
      const newIssues = appointment.issues
      getState().routeParams.jobId || dispatch(actions.createJob())
      const jobId = getState().routeParams.jobId
      appointment.status = appointmentStatus.UNASSIGNED
      appointment.jobId = jobId
      appointment.issues = {}
      const newAppointmentId = firebaseService.add(
        'appointments',
        appointment
      )
      const job = getState().jobs[jobId]
      let appointments = Object.assign(
        {},
        job && job.appointments
      )
      appointments[newAppointmentId] = true
      firebaseService.update(
        'jobs/' + jobId,
        {
          appointments,
        },
        (error) => {
          if (error) {
            console.log(error)
          }
        },
      )
      let appointmentIssues = {}
      Object.keys(newIssues).map((issueId) => {
        const newIssue = getState().issues[issueId]
        newIssue.appointmentId = newAppointmentId
        newIssue.jobId = jobId
        delete newIssue.siteId
        delete newIssue.clientId
        const newIssueId = firebaseService.add(
          'issues',
          newIssue
        )
        let appointment = getState().appointments[newAppointmentId]
        Object.assign(
          appointmentIssues,
          appointment && appointment.issues
        )
        appointmentIssues[newIssueId] = true
        firebaseService.update(
          'appointments/' + newAppointmentId,
          {
            issues: appointmentIssues,
          },
          (error) => {
            if (error) {
              console.log(error)
            }
          },
        )
        let jobIssues = Object.assign(
          {},
          job && job.issues
        )
        jobIssues[newIssueId] = true
        firebaseService.update(
          'jobs/' + jobId,
          {
            issues: jobIssues,
          },
          (error) => {
            if (error) {
              console.log(error)
            }
          },
        )
        firebaseService.remove(
          'issues/' + issueId,
          'dispatcherApp/'
        )
      })
      firebaseService.remove(
        'appointments/' + appointmentId,
        'dispatcherApp/'
      )
      dispatch({
        type: A.UNCACHE_APPOINTMENT,
        appointmentId,
      })
      dispatch({
        type: A.RECEIVE_ISSUES,
        issues: {},
      })
      dispatch({
        type: A.SELECT_NEW_ISSUE,
        issueId: null,
      })
      dispatch(actions.routeTo('viewAppointments'))
    }
  },
  reviewAppointment: () => {
    return (dispatch, getState) => {
      let params = getState().routeParams
      delete params.route
      dispatch(actions.routeTo(
        'reviewAppointment',
        params
      ))
    }
  },
  updateAppointment: (
    appointmentId,
    appointmentUpdates
  ) => {
    return (dispatch, getState) => {
      if (appointmentId) {
        let appointment = getState().appointments[appointmentId] || {}
        let updatedAppointment = Object.assign({}, appointment, appointmentUpdates)

        dispatch({
          type: A.UPDATE_APPOINTMENT,
          appointmentId,
          updatedAppointment,
        })

        firebaseService.update(
          'appointments/' + appointmentId,
          updatedAppointment,
          (error) => {
            if (error) {
              console.log(error)
            }
          },
        )
      }
    }
  },
  updateNewAppointment: (
    appointmentId,
    appointment,
    namespace = 'dispatcherApp/'
  ) => {
    return (dispatch, getState) => {
      if (appointmentId) {
        dispatch({
          type: A.UPDATE_APPOINTMENT,
          appointmentId,
          appointment,
        })

        firebaseService.update(
          'appointments/' + appointmentId,
          appointment,
          (error) => {
            if (error) {
              console.log(error)
            }
          },
          namespace
        )
      } else {
        dispatch(actions.addAppointment(appointment))
      }
    }
  },
}
