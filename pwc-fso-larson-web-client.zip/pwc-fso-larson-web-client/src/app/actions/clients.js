import A from '../const/actionTypes'
import firebaseService from '../infrastructure/FirebaseService'

export default {
  startListeningToClients: () => {
    return (dispatch, getState) => {
      firebaseService.subscribeByLimitToFirst(
        100,
        'clients/',
        (result) => {
          const clients = result.val() || {}
          dispatch({
            type: A.RECEIVE_CLIENTS,
            clients
          })
        },
      )
    }
  },
}
