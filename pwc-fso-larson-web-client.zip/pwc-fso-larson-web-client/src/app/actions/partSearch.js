import A from '../const/actionTypes'
import searchService from '../infrastructure/SearchService'
import firebaseService from '../infrastructure/FirebaseService'

const SEARCH_BUFFER_DELAY = 480

export default {
  searchForPart: (term, issueId) => {
    return (dispatch) => {
      dispatch({
        type: A.SEARCH_FOR_PART,
        term,
        issueId,
      })
      if (firebaseService.searchTimeout) {
        clearTimeout(firebaseService.searchTimeout)
      }
      firebaseService.searchTimeout = setTimeout(
        () => {
          const results = term ? searchService.searchES(term, 'parts', 'part') : Promise.resolve({})
          results.then((results)=> {
            dispatch({
              type: A.RECEIVE_PART_RESULTS,
              results
            })
          })
        },
        SEARCH_BUFFER_DELAY
      )
    }
  }
}
