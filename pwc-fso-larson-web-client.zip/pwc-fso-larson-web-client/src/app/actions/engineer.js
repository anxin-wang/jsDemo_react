import A from '../const/actionTypes'
import actions from '.'
import firebaseService from '../infrastructure/FirebaseService'
import firebaseCacheService from '../infrastructure/FirebaseCacheService'

export default {
  addAppointmentToEngineer: (
    appointmentId,
    engineerId,
  ) => {
    return (dispatch, getState) => {
      let currentAppointments = getState().engineers[engineerId] ?
        getState().engineers[engineerId].assignedAppointments || {} : {}
      let assignedAppointments = Object.assign({}, currentAppointments)
      assignedAppointments[appointmentId] = true
      dispatch(actions.updateEngineer(
        engineerId,
        {
          assignedAppointments
        }
      ))
    }
  },
  cacheEngineer: (
    engineerId
  ) => {
    return (dispatch, getState) => {
      firebaseCacheService.cache(
        'engineers',
        engineerId
      )
    }
  },
  removeAppointmentFromEngineer: (
    appointmentId,
    engineerId,
  ) => {
    return (dispatch, getState) => {
      let currentAppointments = getState().engineers[engineerId] ?
        getState().engineers[engineerId].assignedAppointments || {} : {}
      let assignedAppointments = Object.assign({}, currentAppointments)
      delete assignedAppointments[appointmentId]
      dispatch(actions.updateEngineer(
        engineerId,
        {
          assignedAppointments
        }
      ))
    }
  },
  startListeningToEngineers: () => {
    return (dispatch, getState) => {
      firebaseService.subscribe(
        'engineers/',
        (result) => {
          const engineers = result.val() || {}
          dispatch({
            type: A.RECEIVE_ENGINEERS,
            engineers
          })
        }
      )
    }
  },
  updateEngineer: (
    engineerId,
    updatedEngineer
  ) => {
    return (dispatch, getState) => {
      dispatch({
        type: A.UPDATE_ENGINEER,
        engineerId,
        updatedEngineer,
      })
      firebaseService.update(
        'engineers/' + engineerId,
        updatedEngineer,
        (error) => {
          if (error) {
            console.log(error)
          }
        },
      )
    }
  },
}
