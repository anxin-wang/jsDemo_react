import React from 'react'
import { Route, IndexRoute, } from 'react-router'
import { StyleRoot, } from 'radium'
import AppointmentListView from './view/appointmentManagement/AppointmentListView'
import AppointmentView from './view/appointmentManagement/AppointmentView'
import AppWrapper from './ui/global/AppWrapper'
import EnterAppointmentView from './view/callManagement/EnterAppointmentView'
import LoginView from './view/onboarding/LoginView'
import LogoutView from './view/onboarding/LogoutView'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider'
import ReviewAppointmentView from './view/callManagement/ReviewAppointmentView'
import SearchView from './view/appointmentManagement/SearchView'
import SiteView from './view/clientManagement/SiteView'
import MapView from './view/appointmentManagement/MapView'
import AssignTechView from './view/appointmentManagement/AssignTechView'
import MapListView from './view/mapManagement/MapListView'
import SiteListView from './view/siteManagement/SiteListView'
import TechListView from './view/techManagement/TechListView'

/**
 * Routes: https://github.com/rackt/react-router/blob/master/docs/api/components/Route.md
 *
 * Routes are used to declare your view hierarchy.
 *
 * Say you go to http://material-ui.com/#/components/paper
 * The react router will search for a route named 'paper' and will recursively render its
 * handler and its parent handler like so: Paper > Components > AppWrapper
 */
const Routes = (
  <MuiThemeProvider>
    <StyleRoot>
      <Route path="/" component={AppWrapper}>
        <IndexRoute component={LoginView}/>
        <Route path="/enterAppointment/:params" component={EnterAppointmentView}
          params="s=siteId&j=jobId&a=appointmentId"/>
        <Route path="/reviewAppointment/:params" component={ReviewAppointmentView}
          params="s=siteId&j=jobId&a=appointmentId"/>
        <Route path="/site/:params" component={SiteView} params="s=siteId"/>
        <Route path="/viewAppointments/:params" component={AppointmentListView} params="r=refresh"/>
        <Route path="/viewAppointments" component={AppointmentListView}/>
        <Route path="/search" component={SearchView}/>
        <Route path="/appointment/:params" component={AppointmentView} params="a=appointmentId"/>
        <Route path="/mapView/:params" component={MapView} params="a=appointmentId"/>
        <Route path="/assignTechView/:params" component={AssignTechView}
          params="a=appointmentId&e=engineerId"/>
        <Route path="/logout" component={LogoutView}/>
        <Route path="/viewMap" component={MapListView}/>
        <Route path="/viewTechs" component={TechListView}/>
        <Route path="/viewSites" component={SiteListView}/>
      </Route>
    </StyleRoot>
  </MuiThemeProvider>
)

export default Routes
