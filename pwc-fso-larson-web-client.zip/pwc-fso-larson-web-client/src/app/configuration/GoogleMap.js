import Config from '../config'

export default {
  KEYS: {
    bootstrapURLKeys: Config.API_KEY,
    language: 'en',
  },
  center: {
    'lat': 44.4847356,
    'lng': -73.1163624,
  },
  zoom: 12,
  zoomOnEngineer: 15,
  zoomOnJob: 15,
}
