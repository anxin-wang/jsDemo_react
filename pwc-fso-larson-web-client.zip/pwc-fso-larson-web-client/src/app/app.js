import 'react-mdl/extra/material.css'
import 'react-mdl/extra/material.js'
import React from 'react'
import firebase from 'firebase'
import { render, } from 'react-dom'
import {
  Router,
  browserHistory,
} from 'react-router'
import injectTapEventPlugin from 'react-tap-event-plugin'
import Routes from './Routes'
import Config from './config'
import actions from './actions'
import store from './store'
import firebaseService from './infrastructure/FirebaseService'
import { Provider, } from 'react-redux'
import { syncHistoryWithStore, } from 'react-router-redux'

// Firebase config.
const config = {
  apiKey: Config.API_KEY,
  authDomain: Config.PROJECT_ID + '.firebaseapp.com',
  databaseURL: 'https://' + Config.PROJECT_ID + '.firebaseio.com',
  storageBucket: Config.PROJECT_ID + '.appspot.com',
}

// Instantiates the Firebase instance.
firebase.initializeApp(config)
firebaseService.initialize(firebase)

// Note:  This method may only be here temporarily.  This part is work in progress.
function initApp() {
  store.dispatch(actions.startListeningToAuth())
}

window.onload = function () {
  initApp()
}

// Needed for onTouchTap
// http://stackoverflow.com/a/34015469/988941
injectTapEventPlugin()

/**
 * Render the main app component. You can read more about the react-router here:
 * https://github.com/rackt/react-router/blob/master/docs/guides/overview.md
 */
const history = syncHistoryWithStore(browserHistory, store)

render(
  <Provider store={store}>
    <Router onUpdate={() => window.scrollTo(0, 0)} history={history}>
      {Routes}
    </Router>
  </Provider>
  , document.getElementById('app'))
