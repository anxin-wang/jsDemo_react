import React from 'react'
import Body from '../typography/Body'
import Caption from '../typography/Caption'

const SiteDetailsItem = (props) => (
  <div>
    <Caption style={styles.caption}>{props.secondaryText}</Caption>
    <Body style={styles.body}>{props.primaryText}</Body>
  </div>
)

let styles = {
  body: {
    marginTop: 0,
  },
  caption: {
    marginBottom: 0,
  }
}

export default SiteDetailsItem
