import React from 'react'
import { ListItem } from 'material-ui'

const StaticListItem = (props) => (
  <ListItem
    {...props}
    disabled
  />
)

export default StaticListItem
