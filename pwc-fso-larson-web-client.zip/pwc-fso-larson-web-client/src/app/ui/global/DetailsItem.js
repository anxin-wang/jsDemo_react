import React from 'react'
import Body from '../typography/Body'
import Caption from '../typography/Caption'

const DetailsItem = (props) => (
  <div>
    <Body style={styles.body}>{props.primaryText}</Body>
    <Caption style={styles.caption}>{props.secondaryText}</Caption>
  </div>
)

let styles = {
  body: {
    marginBottom: 0,
  },
  caption: {
    marginTop: 0,
  }
}

export default DetailsItem
