import React, { Component, PropTypes, } from 'react'
import { connect, } from 'react-redux'
import Snackbar from 'material-ui/Snackbar'
import { Dialog, FlatButton, } from 'material-ui'
import ActionAccountCirle from 'material-ui/svg-icons/action/account-circle'
import actions from '../../actions'
import AppBar from 'material-ui/AppBar'
import AppNavMenu from './AppNavMenu'
import Drawer from 'material-ui/Drawer'
import getMuiTheme from 'material-ui/styles/getMuiTheme'
import moment from 'moment'
import NavigationArrowBack from 'material-ui/svg-icons/navigation/arrow-back'
import NavigationClose from 'material-ui/svg-icons/navigation/close'
import NotificationIcon from '../button/NotificationIcon'
import notificationStatus from '../../const/notificationStatus'
import SearchField from './SearchField'
import store from '../../store'
import Title from '../../ui/typography/Title'
import Caption from '../../ui/typography/Caption'
import Body from '../../ui/typography/Body'
import Theme from '../../theme/Theme.js'
import Truncate from 'react-truncate'
import { List, ListItem } from 'material-ui/List'
import { palette } from '../../theme/Theme.js'
import AutoComplete from 'material-ui/AutoComplete'

const fullWidth = true

class AppWrapper extends Component {
  constructor() {
    super()
    this.handleClickBack = this.handleClickBack.bind(this)
    this.changeDrawerState = this.changeDrawerState.bind(this)
  }

  static propTypes = {
    children: PropTypes.node,
  }

  static contextTypes = {
    router: PropTypes.object.isRequired,
  }

  static childContextTypes = {
    muiTheme: PropTypes.object,
  }

  getChildContext() {
    return {
      muiTheme: this.state.muiTheme,
    }
  }

  changeDrawerState() {
    this.setState({
      notificationsOpen: !this.state.notificationsOpen
    })
    if (!this.state.notificationsOpen) {
      this.props.dismissNotifications()
    }
  }

  componentWillMount() {
    this.setState({
      muiTheme: getMuiTheme(),
      notificationsOpen: false,
    })
  }

  componentWillReceiveProps(nextProps, nextContext) {
    const newMuiTheme = nextContext.muiTheme ? nextContext.muiTheme : this.state.muiTheme
    this.setState({
      muiTheme: newMuiTheme,
    })
  }

  goToNotification(notificationId, notification) {
    this.props.updateNotificationStatus(notificationId, notificationStatus.ACKNOWLEDGED)
    // TODO refactor to handle all notifications
    if (notification.type === 'PART_NOTED' && notification.meta) {
      this.props.cacheAppointment(notification.meta.appointmentId)
      store.dispatch(actions.routeTo(
        'appointment',
        {
          appointmentId: notification.meta.appointmentId,
        },
      ))
    } else if (notification.type === 'APPOINTMENT_CREATED') {
      this.props.cacheAppointment(notification.subjectId)
      store.dispatch(actions.routeTo(
        'appointment',
        {
          appointmentId: notification.subjectId,
        },
      ))
    }

  }

  handleSignOut = (event, value) => {
    this.context.router.push(value)
  }

  handleClickBack(event) {
    this.context.router.goBack()
    this.props.searchForTerm('')
  }

  handleChangeMuiTheme = (muiTheme) => {
    this.setState({
      muiTheme: muiTheme,
    })
  }

  handleChangeList = (event, value) => {
    this.props.routeTo(value)
  }

  filterNames = (searchText, key) => {
    let response = false
    if (searchText !== '' && key.indexOf(searchText) !== -1) {
      response = true
    }
    return response
  }

  render() {
    const {
      auth, children, location, notifications,
      search, searchForTerm, sites,
    } = this.props

    const appointment = {} // TODO: logic to be refactored
    const appointmentNumber = appointment && appointment.legacyId
    const route = store.getState().routeParams.route
    let showBackButton = route === '/search'
    let unreadNotification = Object.keys(notifications).find(notificationId => {
      return notifications[notificationId] && notifications[notificationId].status === 'SENT'
    })
    let notificationCount = Object.keys(notifications).length

    const title = route === '/site' ?
      'Pending...' :
      route === '/appointment' ?
        appointmentNumber || 'Pending...' :
        this.props.appBar.title

    const snackbar = this.props.snackbar
    const dialog = this.props.dialog

    return (
      <div>
        <AppBar
          title={title}
          showMenuIconButton={false}
          style={styles.appBar}
        >
          {
            showBackButton ? (
              <FlatButton
                icon={<NavigationArrowBack />}
                onClick={this.handleClickBack}
                primary
                style={styles.back}
              />
            ) : null
          }
          {
            auth.uid ? (
              <SearchField
                searchForTerm={searchForTerm}
                search={search}
                sites={sites}
              />
            ) : null
          }
          {
            auth.uid ? (
              <NotificationIcon
                color={notificationCount ? Theme.palette.alternateTextColor : Theme.palette.textColorLight}
                notificationCount={notificationCount}
                onClick={this.changeDrawerState.bind(this)}
                style={styles.alertIconNavBar}
                unreadNotification={unreadNotification}
              />
            ) : null
          }
        </AppBar>
        { location.pathname === '/mapView' || location.pathname === '/assignTechView' ?
          null :
          <AppNavMenu
            location={location}
            onRequestChangeNavMenu={(value) => {}}
            onChangeList={this.handleChangeList}
          />
        }
        <Drawer
          width={350}
          openSecondary
          open={this.state.notificationsOpen}
          style={styles.notificationDrawer}
        >
          <AppBar
            showMenuIconButton={false}
            title={
              <Title style={styles.titleNav} color={Theme.palette.textColorLight}>
                Notifications Today
              </Title>
            }
            iconElementRight={
              <NavigationClose
                style={styles.closeNotificationDrawer}
                onTouchTap={this.changeDrawerState}
              />
            }
            onTitleTouchTap={this.changeDrawerState}
          />
          {
            Object.keys(notifications).length > 0 ?
              <div>
                <List>
                  {
                    Object.keys(notifications).map(notificationId => {
                      let notification = notifications[notificationId]
                      return (
                        <ListItem
                          key={notificationId}
                          onClick={() => { this.goToNotification(notificationId, notification) }}
                          style={notification.status === 'ACKNOWLEDGED' ?
                            styles.notificationClicked :
                            styles.notification
                          }
                        >
                          <div>
                            <ActionAccountCirle style={styles.notificationAvatar}/>
                            <Body style={styles.notificationContent}>
                              <Truncate lines={2} ellipsis={'...'}>
                                {notification.content}
                              </Truncate>
                            </Body>
                            <Caption style={styles.notificationTimestamp}>
                              {moment(notification.createdAt).fromNow(true)}
                            </Caption>
                          </div>
                        </ListItem>
                      )
                    })
                  }
                </List>
              </div> :
              <div style={styles.noAlerts}> No alerts yet!</div>
          }
        </Drawer>
        <div style={styles.mainContainer}>
          {React.cloneElement(children, {
            onChangeMuiTheme: this.handleChangeMuiTheme,
          })}
        </div>
        <Snackbar
          bodyStyle={styles.snackbarBody}
          open={snackbar.open || false}
          message={snackbar.message || ' '}
          action={snackbar.action || ' '}
          onActionTouchTap={() => {
            this.props.hideSnackbar()
            if (snackbar.onActionTouchTap) {
              snackbar.onActionTouchTap()
            }
          }}
          autoHideDuration={snackbar.autoHideDuration}
          onRequestClose={snackbar.sticky ? (() => {}) : this.props.hideSnackbar}
        />
        <Dialog
          title={dialog.title}
          actions={[
            <FlatButton
              label={dialog.rejectCaption || ' '}
              primary
              onTouchTap={() => {
                this.props.hideDialog()
                if (dialog.rejectCallback) {
                  dialog.rejectCallback()
                }
              }}
            />,
            <FlatButton
              label={dialog.acceptCaption || ' '}
              primary
              keyboardFocused
              onTouchTap={() => {
                this.props.hideDialog()
                if (dialog.acceptCallback) {
                  dialog.acceptCallback()
                }
              }}
            />,
          ]}
          open={dialog.open || false}
          onRequestClose={this.props.hideDialog}
        >
        { dialog.content }
        {
          dialog.autoComplete ?
            <AutoComplete
              hintText={dialog.autoComplete.hintText}
              dataSource={dialog.autoComplete.dataSource}
              filter={this.filterNames}
              onNewRequest={dialog.autoComplete.onNewRequest}
              fullWidth={fullWidth}
            /> :
            null
        }
        </Dialog>
      </div>
    )
  }
}

const styles = {
  appBar: {
    position: 'fixed',
    top: 0,
  },
  alertIconNavBar: {
    marginTop: 20,
  },
  alertIconNavDrawer: {
    marginLeft: 6,
    marginRight: 6,
    marginTop: 20,
  },
  back: {
    color: Theme.palette.canvasColor,
    marginTop: 12,
    marginLeft: -16,
    position: 'absolute',
  },
  closeNotificationDrawer: {
    color: Theme.palette.textColorLight,
    cursor: 'pointer',
    marginTop: 12,
  },
  mainContainer: {
    marginLeft: '23%',
  },
  noAlerts: {
    marginBottom: '50%',
    marginLeft: '35%',
    marginRight: '35%',
    marginTop: '50%',
  },
  notificationDrawer: {
    zDepth: 2,
    zIndex: 9999,
  },
  notification: {
    borderBottom: '0.5px solid ' + palette.borderColor,
    position: 'relative'
  },
  notificationClicked: {
    borderBottom: '0.5px solid ' + palette.borderColor,
    position: 'relative',
    opacity: 0.54
  },
  notificationAvatar: {
    display: 'inline-block',
    marginRight: 16,
    opacity: 0.54,
    width: 20,
    verticalAlign: 'middle'
  },
  notificationContent: {
    display: 'inline-block',
    marginRight: 16,
    marginTop: 0,
    marginBottom: 0,
    width: 206,
    verticalAlign: 'middle'
  },
  notificationTimestamp: {
    display: 'inline-block',
    maxWidth: 48,
    verticalAlign: 'middle',
    float: 'right'
  },
  snackbarBody: {
  },
  titleNav: {
    marginTop: 20,
  },
}

const mapStateToProps = (state) => {
  return {
    appBar: state.appBar,
    appointments: state.appointments,
    auth: state.auth,
    dialog: state.dialog,
    notifications: state.notifications,
    search: state.search,
    sites: state.sites,
    snackbar: state.snackbar,
    dispatchers: state.dispatchers
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    cacheAppointment: (appointmentId) => dispatch(actions.cacheAppointment(appointmentId)),
    dismissNotifications: () => dispatch(actions.dismissNotifications()),
    hideSnackbar: () => dispatch(actions.hideSnackbar()),
    hideDialog: () => dispatch(actions.hideDialog()),
    routeTo: (route, params) => dispatch(actions.routeTo(route, params)),
    searchForTerm: (term) => dispatch(actions.searchForTerm(term)),
    updateNotificationStatus: (notificationId, status) => dispatch(
      actions.updateNotificationStatus(notificationId, status)
    ),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AppWrapper)
