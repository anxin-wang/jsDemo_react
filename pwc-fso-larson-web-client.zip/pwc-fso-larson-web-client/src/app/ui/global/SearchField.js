import React, { Component, } from 'react'
import { connect, } from 'react-redux'
import { Paper, AutoComplete, } from 'material-ui'
import ActionSearch from 'material-ui/svg-icons/action/search'
import actions from '../../actions'
import store from '../../store'

class SearchField extends Component {
  constructor() {
    super()
    this.state = {
      searchText: '',
    }
    this.handleFocus = this.handleFocus.bind(this)
    this.handleBlur = this.handleBlur.bind(this)
    this.narrowSearch = this.narrowSearch.bind(this)
  }

  renderSuggestions() {
    const sites = this.props.sites
    const siteIDs = Object.keys(this.props.search.results.sites)
    return siteIDs.map((siteID) => sites[siteID] ? sites[siteID].name + ', ' + sites[siteID].address.street : null)
  }

  renderPreviousSearches() {
    return this.props.search.previousSearches ?
      Object.keys(this.props.search.previousSearches) : []
  }

  renderDataSource() {
    return this.state.focused ?
      (
        this.props.search.results && this.props.search.results.sites ?
          this.renderSuggestions() : this.renderPreviousSearches()
      ) : []
  }

  handleFocus() {
    this.setState({
      focused: true,
    })
    store.dispatch(actions.routeTo('search'))
  }

  handleBlur() {
    this.setState({
      focused: false,
    })
  }

  narrowSearch(searchText) {
    const segments = searchText.split(',')
    const segment = segments[segments.length - 1]
    const newSearchText = (
      segment &&
      segment !== searchText
    ) ? '"' + segment + '"' : searchText
    this.props.searchForTerm(newSearchText)
    this.props.search.term = searchText
  }

  render() {
    let dataSource = [] // this.renderDataSource()

    return (
      <Paper style={styles.paper}>
        <ActionSearch style={styles.actionSearch}/>
        <AutoComplete
          onKeyPress={(event) => {
            if (event.charCode === 13) {
              this.props.searchForTerm(this.state.searchText)
            }
          }}
          searchText={this.props.search.term}
          openOnFocus
          filter={AutoComplete.noFilter}
          dataSource={dataSource}
          hintText="Search"
          style={styles.textField}
          underlineShow={false}
          onUpdateInput={(searchText) => {
            this.setState({searchText: searchText})
          }}
          onFocus={this.handleFocus}
          onBlur={this.handleBlur}
          fullWidth
        />
      </Paper>
    )
  }
}

const styles = {
  actionSearch: {
    margin: 8,
    opacity: 0.3,
  },
  paper: {
    display: 'flex',
    height: 40,
    marginLeft: '25%',
    marginTop: 12,
    position: 'absolute',
    width: '47%',
  },
  textField: {
    flex: 1,
    fontSize: '20px',
    marginTop: -4,
  },
}

const mapStateToProps = (state) => {
  return {}
}

const mapDispatchToProps = (dispatch) => {
  return {
    clearSearch: () => dispatch(actions.clearSearch()),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchField)
