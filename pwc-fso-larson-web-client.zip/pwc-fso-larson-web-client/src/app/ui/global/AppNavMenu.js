import React, { Component, PropTypes, } from 'react'
import { List, ListItem, MakeSelectable, } from 'material-ui/List'
import { spacing, typography, } from 'material-ui/styles'
import { cyan500, lightBlack } from 'material-ui/styles/colors'
import { connect, } from 'react-redux'
import ActionList from 'material-ui/svg-icons/action/list'
import MapsLocalGasStation from 'material-ui/svg-icons/maps/local-gas-station'
import ActionExitToApp from 'material-ui/svg-icons/action/exit-to-app'
import LocalShipping from 'material-ui/svg-icons/maps/local-shipping'
import Place from 'material-ui/svg-icons/maps/place'

const SelectableList = MakeSelectable(List)

const styles = {
  logo: {
    cursor: 'pointer',
    fontSize: 24,
    color: typography.textFullWhite,
    lineHeight: `${spacing.desktopKeylineIncrement}px`,
    fontWeight: typography.fontWeightLight,
    backgroundColor: cyan500,
    paddingLeft: spacing.desktopGutter,
    marginBottom: 8,
  },
  version: {
    paddingLeft: spacing.desktopGutterLess,
    fontSize: 16,
  },
  navBar: {
    paddingTop: 60,
    paddingBottom: 45,
    marginRight: 30,
    marginTop: 30,
    height: '100%',
    position: 'fixed',
  },
  navItem: {
    fontWeight: 500,
    color: typography.iconColor,
    paddingLeft: 15,
    paddingRight: 35,
  }
}

class AppNavMenu extends Component {
  static propTypes = {
    location: PropTypes.object.isRequired,
    onChangeList: PropTypes.func.isRequired,
  }

  static contextTypes = {
    muiTheme: PropTypes.object.isRequired,
    router: PropTypes.object.isRequired,
  }

  state = {
    muiVersions: [],
  }

  componentDidMount() {
    // removed
  }

  firstNonPreReleaseVersion() {
    let version
    for (let i = 0; i < this.state.muiVersions.length; i++) {
      version = this.state.muiVersions[i]
      // If the version doesn't contain '-' and isn't 'HEAD'
      if (!/-/.test(version) && version !== 'HEAD') {
        break
      }
    }
    return version
  }

  handleVersionChange = (event, index, value) => {
    if (value === this.firstNonPreReleaseVersion()) {
      window.location = 'http://www.material-ui.com/'
    } else {
      window.location = `http://www.material-ui.com/${value}`
    }
  }

  currentVersion() {
    if (window.location.hostname === 'localhost') return this.state.muiVersions[0]
    let version = window.location.pathname.replace(/\//g, '')
    if (window.location.pathname === '/') {
      version = this.firstNonPreReleaseVersion()
    }
    return version
  }

  handleRequestChangeLink = (event, value) => {
    window.location = value
  }

  render() {
    const {
      location,
      onChangeList,
      } = this.props

    return this.props.auth.uid ? (
      <SelectableList value={location.pathname} onChange={onChangeList} style={styles.navBar}>
        <ListItem
          style={styles.navItem}
          primaryText="Appointments"
          leftIcon={<ActionList color={lightBlack}/>}
          value="viewAppointments"
        />
        <ListItem
          style={styles.navItem}
          primaryText="Sites"
          leftIcon={<MapsLocalGasStation color={lightBlack}/>}
          value="viewSites"
        />
        <ListItem
          style={styles.navItem}
          primaryText="Techs"
          leftIcon={<LocalShipping color={lightBlack}/>}
          value="viewTechs"
        />
        <ListItem
          style={styles.navItem}
          primaryText="Map"
          leftIcon={<Place color={lightBlack}/>}
          value="viewMap"
        />
        <ListItem
          style={styles.navItem}
          primaryText="Sign Out"
          leftIcon={<ActionExitToApp color={lightBlack}/>}
          value="logout"
        />
      </SelectableList>
    ) : null
  }
}

const mapStateToProps = (state) => {
  return { auth: state.auth, }
}

export default connect(mapStateToProps)(AppNavMenu)
