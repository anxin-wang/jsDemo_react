import React, { Component } from 'react'
import Caption from '../typography/Caption'
import DropDownMenu from 'material-ui/DropDownMenu'
import MenuItem from 'material-ui/MenuItem'

const items = []
const newItems = []
items.push(
  <MenuItem value={'TM – Time & Material'} key={'TM – Time & Material'}
   primaryText={'TM – Time & Material'} />
)
items.push(
  <MenuItem value={'COD – Cash on Delivery'} key={'COD – Cash on Delivery'}
    primaryText={'COD – Cash on Delivery'} />
)
items.push(
  <MenuItem value={'MC – Fixed cost contract'} key={'MC – Fixed cost contract'}
    primaryText={'MC - Fixed cost contract'} />
)
items.push(
  <MenuItem value={'CJ – Cost to job'} key={'CJ – Cost to job'}
    primaryText={'CJ – Cost to job'} />
)

class SiteDetailsBillItem extends Component {
  constructor(props) {
    super(props)
    this.state = {value: this.props.appointmentType}

    newItems.length = 0

    items.map((item, index) => {
      if (item.key !== this.props.appointmentType) {
        newItems.push(item)
      }
    })
    newItems.push(
      <MenuItem
        value={this.props.appointmentType}
        key={this.props.appointmentType}
        primaryText={this.props.appointmentType}
      />
    )
  }

  handleChange = (event, index, value) => {
    this.setState({value})
    this.props.selectBillingType(value)
  }

  render() {
    return (
      <div>
        <Caption style={styles.caption}>{this.props.secondaryText}</Caption>
        <DropDownMenu
          labelStyle={styles.labelStyle}
          underlineStyle={styles.underlineStyle}
          iconStyle={styles.iconStyle}
          style={styles.rootStyle}
          autoWidth={false}
          maxHeight={300} value={this.state.value} onChange={this.handleChange}>
          {newItems}
        </DropDownMenu>
      </div>
    )
  }
}

let styles = {
  menuItemStyle: {
    width: '196px',
  },
  rootStyle: {
    width: '100%',
    position: 'relative'
  },
  caption: {
    marginBottom: 0,
    fontWeight: 500
  },
  labelStyle: {
    paddingLeft: 0,
    paddingRight: 40
  },
  underlineStyle: {
    borderTop: 'none'
  },
  iconStyle: {
    fill: 'rgba(90, 90, 90, 1)'
  }
}

export default SiteDetailsBillItem

