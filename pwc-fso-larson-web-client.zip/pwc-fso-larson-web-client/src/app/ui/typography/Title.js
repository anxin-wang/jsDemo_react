import React from 'react'
import Radium from 'radium'
import { palette } from '../../theme/Theme.js'

const defaultTextColor = palette.textColor

const Title = ({ children, style, color = defaultTextColor }) => (
  <div style={[defaultStyles, style, { color: color }]}>
    {children}
  </div>
)

let defaultStyles = {
  fontSize: 20,
  lineHeight: '28px',
  fontWeight: 500,
  marginTop: 16,
  marginBottom: 16,
}

export default Radium(Title)
