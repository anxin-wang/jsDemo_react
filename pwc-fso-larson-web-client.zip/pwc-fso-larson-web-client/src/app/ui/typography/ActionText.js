import React from 'react'
import Radium from 'radium'
import { palette } from '../../theme/Theme.js'

const defaultTextColor = palette.textColor

const ActionText = ({ children, style, color = defaultTextColor }) => (
  <div style={[defaultStyles, style, { color: color }]}>
    {children}
  </div>
)

let defaultStyles = {
  fontWeight: 500,
  fontSize: 14,
  lineHeight: '20px',
  textTransform: 'uppercase',
}

export default Radium(ActionText)
