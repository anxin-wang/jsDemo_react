import React from 'react'
import Radium from 'radium'
import { palette } from '../../theme/Theme.js'

const defaultTextColor = palette.captionColor

const Caption = ({ children, style, color = defaultTextColor }) => (
  <div style={[defaultStyles, style, { color: color }]}>
    {children}
  </div>
)

let defaultStyles = {
  fontSize: 12,
  marginTop: 8,
  marginBottom: 8,
}

export default Radium(Caption)
