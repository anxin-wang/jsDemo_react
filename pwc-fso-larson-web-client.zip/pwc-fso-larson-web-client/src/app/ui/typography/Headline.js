import React from 'react'
import Radium from 'radium'
import { palette } from '../../theme/Theme.js'

const defaultTextColor = palette.textColor

const Headline = ({ children, style, color = defaultTextColor }) => (
  <div style={[defaultStyles, style, { color: color }]}>
    {children}
  </div>
)

let defaultStyles = {
  fontWeight: 500,
  fontSize: 26,
  lineHeight: '28px',
  marginTop: 12,
}

export default Radium(Headline)
