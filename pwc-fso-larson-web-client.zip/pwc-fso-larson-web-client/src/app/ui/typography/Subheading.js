import React from 'react'
import Radium from 'radium'
import { palette, } from '../../theme/Theme.js'

const defaultTextColor = palette.textColor

let defaultStyles = {
  fontSize: 16,
  fontWeight: 400,
  lineHeight: '24px',
  marginTop: 16,
  marginBottom: 16,
}

const Subheading = ({ children, style, color = defaultTextColor, }) => (
  <div style={[defaultStyles, style, { color: color, }]}>
    {children}
  </div>
)

export default Radium(Subheading)
