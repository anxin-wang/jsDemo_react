import React from 'react'
import Radium from 'radium'
import { palette } from '../../theme/Theme.js'

const defaultTextColor = palette.textColor

let Body = ({ children, style, color = defaultTextColor }) => (
  <div style={[defaultStyles, style, { color: color }]}>
    {children}
  </div>
)

let defaultStyles = {
  fontSize: 15,
  lineHeight: '26px',
  marginTop: 16,
  marginBottom: 16,
}

export default Radium(Body)
