import { palette } from '../../theme/Theme.js'
import Radium from 'radium'
import React from 'react'
import SocialNotifications from 'material-ui/svg-icons/social/notifications'
import SocialNotificationsActive from 'material-ui/svg-icons/social/notifications-active'
import SocialNotificationsNone from 'material-ui/svg-icons/social/notifications-none'

const defaultTextColor = palette.textColorLight

const NotificationIcon = ({ notificationCount, unreadNotification, onClick, style, color = defaultTextColor }) => (
  notificationCount > 0 ?
    unreadNotification ?
    <div>
      <SocialNotificationsActive
        onClick={onClick}
        style={Object.assign(defaultStyles, style, { color: color })}
      />
      <div style={styles.notificationIndicator}>&#9679;</div>
    </div> :
    <SocialNotifications
      onClick={onClick}
      style={Object.assign(defaultStyles, style, { color: color })}
    /> :
    <SocialNotificationsNone
      onClick={onClick}
      style={Object.assign(defaultStyles, style, { color: color })}
    />
)

let defaultStyles = {
  cursor: 'pointer',
}

let styles = {
  notificationIndicator: {
    color: palette.negativeColor,
    float: 'right',
    fontSize: 20,
    marginBottom: -7,
    marginLeft: -5,
    marginTop: 3,
    zindex: 99999,
  },
}

export default Radium(NotificationIcon)
