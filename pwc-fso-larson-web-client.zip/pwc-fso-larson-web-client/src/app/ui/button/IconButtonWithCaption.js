import React from 'react'
import { Component } from 'react'
import Radium from 'radium'
import IconButton from 'material-ui/IconButton'

class IconButtonWithCaption extends Component {
  render() {
    return (
      <div style={styles.wrapper}>
        <IconButton
          iconStyle={styles.mediumIcon}
          style={styles.medium}
        >
          {this.props.children}
        </IconButton>
        <div>
          {this.props.caption}
        </div>
      </div>
    )
  }
}

const styles = {
  wrapper: {
    padding: 12,
  },
  mediumIcon: {
    width: 32,
    height: 32,
  },
}

export default Radium(IconButtonWithCaption)
