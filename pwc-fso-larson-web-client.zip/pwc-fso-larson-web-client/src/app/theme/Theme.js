import * as Colors from 'material-ui/styles/colors'

const Theme = {
  fontFamily: 'Roboto, sans-serif !important',
  palette: {
    primary1Color: Colors.cyan600,
    primary2Color: Colors.blue700,
    primary3Color: Colors.lightBlack,
    accent1Color: Colors.pink500,
    accent2Color: Colors.grey200,
    accent3Color: Colors.grey500,
    textColor: Colors.darkBlack,
    textColorSoft: Colors.lightBlack,
    textColorLight: Colors.darkWhite,
    captionColor: Colors.grey600,
    alternateTextColor: Colors.white,
    iconColor: Colors.grey600,
    canvasColor: Colors.white,
    backgroundColor: Colors.grey300,
    borderColor: Colors.grey300,
    pickerHeaderColor: Colors.cyan500,
    positiveColor: Colors.green500,
    negativeColor: Colors.red700,
    warningColor: Colors.orange600,
    supervisorColor: Colors.cyan500,
    fieldEngineerColor: Colors.lightGreenA700,
    dispatcherColor: Colors.purpleA700,
    onboardHeroBackground: Colors.lightGreen500,
    sidebarBackground: Colors.grey100,
    partCommentBackground: Colors.red50,
  },
}

exports.palette = Theme.palette
exports.fontFamily = Theme.fontFamily
exports.default = Theme
