# firebase-react-example

This is a project that uses [React](https://facebook.github.io/react/), [Firebase](https://firebase.google.com/), and [Material-UI](http://callemall.github.io/material-ui/) with [Webpack](http://webpack.github.io/docs/).


## how to setup config.env

An example config.env is like the following

```
PROJECT_ID=project-7192975833413718180
API_KEY=AIzaSyDnd8XluxO7F5ca9n34uZKnFULdVUZfFXg
GOOGLE_SCOPES=https://www.googleapis.com/auth/drive.metadata.readonly
DEFAULT_SCOPE=https://www.googleapis.com/auth/plus.login
DEFAULT_CLIENT_ID=688585241582-fl6juuqe7udmj0f7c8m30ih0vknjseog.apps.googleusercontent.com
CUSTOM_AUTH_HEADER_NAME=X-My-Custom-Header
GOOGLE_MAP_API_KEY=AIzaSyDnd8XluxO7F5ca9n34uZKnFULdVUZfFXg
GOOGLE_GEOLOCATOR_URL=https://maps.googleapis.com/maps/api/geocode/json?address=
```

- PROJECT_ID is your google project id
- API_KEY go to [google cloud project](https://console.cloud.google.com/apis/credentials?project=project--7192975833413718180), change to the project you are using, then use the key for Browser key (auto created by Google Service)
- GOOGLE_SCOPES=https://www.googleapis.com/auth/drive.metadata.readonly
- DEFAULT_SCOPE=https://www.googleapis.com/auth/plus.login
- DEFAULT_CLIENT_ID go to [google cloud Api manager/credentials](https://console.cloud.google.com/apis/credentials?project=project--7192975833413718180), change to the project your are using, then use the api key from Web client (auto created by Google Service)
- CUSTOM_AUTH_HEADER_NAME=X-My-Custom-Header
- GOOGLE_MAP_API_KEY go to [get-api-key](https://developers.google.com/maps/documentation/javascript/get-api-key), then choose your project
- GOOGLE_GEOLOCATOR_URL=https://maps.googleapis.com/maps/api/geocode/json?address=

## Installation

#### After cloning the repository, install dependencies:
```sh
cd pwc-fso-larson-web-client
npm install
```

#### Now you can run your local server:
```sh
npm start
```
Server is located at http://localhost:3000

#### Package for production:
```sh
npm run build
```

* Note: To allow external viewing of the demo, change the following value in `webpack-dev-server.config.js`

```
host: 'localhost'  //Change to '0.0.0.0' for external facing server
```

## Project Directory Tree

This is a high-level overview of the project directory structure to assist contributors.

```sh
$ tree -I 'test*|docs|bin|lib|build|node_modules|*.*|font*'
```
```
.
└── src
    ├── app
    │   ├── components
    │   │   └── pages
    │   └── services
    └── www
        └── css
```


## Description of [Webpack](http://webpack.github.io/docs/)

Webpack is a module bundler that we are using to run our documentation site.
This is a quick overview of how the configuration file works.

### Webpack Configuration:

#### Entry

Webpack creates entry points for the application to know where it starts.

#### Output

This is where the bundled project will go to and any other files necessary for it to run.

#### Plugins

These are plugins Webpack uses for more functionality.
The HTML Webpack Plugin, for example, will add the index.html to your build folder.

#### Modules

Modules and other things that are required will usually need to be loaded and interpreted by Webpack when bundling, and this is where Webpack looks for the different loaders.
*Loading .js files in es6 and es7 will require a loader like babel-loader to interpret the files into es5.

#### Note
If running this app locally, you can also run the /examples/firebase-appengine-nodejs-example/backend NodeJS app locally, and repoint the BACKEND_SERVICE_BASE_URL of this application to point to http://localhost:8080.  Interactions with this other app occur from the "Firebase" and "Back End Auth" pages.

